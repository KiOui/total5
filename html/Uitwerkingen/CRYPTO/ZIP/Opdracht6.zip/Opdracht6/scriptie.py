FIELD = 13

def execute_left(y):
    return y**2

def execute_right(x):
    return x**3+7*x+1

amount = 0

for x in range (0, FIELD):
    for y in range (0, FIELD):
        if (execute_left(y)%FIELD == execute_right(x)%FIELD):
            print(str(x) + ", " + str(y))
            amount += 1

print("Amount of points: " + str(amount))
