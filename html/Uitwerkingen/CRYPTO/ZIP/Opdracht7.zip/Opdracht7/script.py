def point_add(field: int, x1: int, y1: int, x2: int, y2: int):
    lambd = lambda_add(field, x1, y1, x2, y2)
    x3 = calc_x3(field, lambd, x1, x2)
    return x3, calc_y3(field, lambd, x1, x3, y1)


def point_double(field: int, x1: int, y1: int):
    lambd = lambda_double(field, x1, y1, 11)
    x3 = calc_x3(field, lambd, x1, x1)
    return x3, calc_y3(field, lambd, x1, x3, y1)


def lambda_double(field: int, x1: int, y1: int, a: int):
    upper = (3 * x1 ^ 2 + a) % field
    lower = (2 * y1) % field
    inverse = 0
    for i in range(field):
        if (i * lower) % field == 1:
            inverse = i
    return upper * inverse % field


def lambda_add(field: int, x1: int, y1: int, x2: int, y2: int):
    upper = (y1 - y2) % field
    lower = (x1 - x2) % field
    inverse = 0
    for i in range(field):
        if (i * lower) % field == 1:
            inverse = i
    if inverse == 0:
        print("nee")
        print(lower)
    return upper * inverse % field


def calc_x3(field: int, lambd: int, x1: int, x2: int):
    return (lambd ^ 2 - x1 - x2) % field


def calc_y3(field: int, lambd: int, x1: int, x3: int, y1: int):
    return (lambd * (x1 - x3) - y1) % field

'''
m = []
l = []

print("m & g^m & g^{-m}")
for i in range(0, 11):
    b = 48 ** i % 101
    for a in range(102):
        if (b * a % 101) == 1:
            print(str(i) + " & " + str(b) + " & " + str(a))
            m.append(b)
            l.append(a)
            break
print("")
for i in range(11):
    for a in l:
        mult = 7 * a ** i % 101
        if mult in m:
            print(str(a) + ", " + str(i) + ", " + str(mult))

'''

px = 12
py = 34
qx = 49
qy = 18
f = 101

multp = []
multp.append((px, py))
multp_inv = []
multp_inv.append((px, -py%101))
for i in range(0, 11):
    x3 = 0
    y3 = 0
    if i == 0:
        x3, y3 = point_double(101, px, py)
    else:
        x3, y3 = point_add(101, px, py, multp[i][0], multp[i][1])
    multp.append((x3, y3))
    multp_inv.append((x3, -y3%101))

print(multp)
print(multp_inv)

an = [multp[len(multp)-1]]

for j in range(0, 11):
    px, py = an[len(an)-1]
    x3, y3 = point_add(101, px, -py%101, qx, qy)
    print(str(x3) + " " + str(y3))
    if j != 0:
        an.append(point_add(101, px, py, an[0][0], an[0][1]))
    else:
        an.append(point_double(101, px, py))
    if (x3, y3) in multp:
        print("JOEHOE")

