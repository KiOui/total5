#!/usr/bin/env python3

import random
import pprint

############################################################
#
#       Utility functions for differential cryptanalysis
#
############################################################

# pretty printing
def pp(num):
        if num < 10 :
                return " " + str(num)
        return str(num)

# pretty printing with cutting above a value
def ppd(num,cut):
        if num <= cut:
                return "  "
        if num < 10 :
                return " " + str(num)
        return str(num)

# given a 2 dimension table, pretty print it
def print_table(table,cut):
        print("   X  | " + "  ".join([bin(x)[2:].zfill(4) for x in range(len(table[0]))]))
        print("------+-" + "-".join(["-----" for x in range(len(table[0]))]))
        for j in range(len(table)):
                print(" " + bin(j)[2:].zfill(4) + " |  " + "    ".join([ppd(x,cut) for x in table[j]]))

# given a 2 dimension table, print the list of differentials sorted by probability
def print_list(table,cut):
        prob_diff = {}
        for diff_out in range(len(table)):
                for diff_in in range(len(table[0])):
                        p = table[diff_out][diff_in]
                        d = bin(diff_in)[2:].zfill(4) + " => " + bin(diff_out)[2:].zfill(4)
                        if p > cut:
                                if p in prob_diff:
                                        prob_diff[p].append(d)
                                else:
                                        prob_diff[p] = [d]
        for p in sorted(prob_diff.keys(),reverse=True):
                for d in prob_diff[p]:
                        print(d + " : " + pp(p))

# given a 2 dimension table, print the list of differentials sorted by input value
def print_list2(table,cut):
        for diff_in in range(len(table)):
                for diff_out in range(len(table)):
                        d = bin(diff_in)[2:].zfill(4) + " => " + bin(diff_out)[2:].zfill(4)
                        if table[diff_out][diff_in] > cut:
                                print(d + " : " + pp(table[diff_out][diff_in]))





############################################################
#
#                       Utility functions for block cipher
#
############################################################


# rotate left by n bits (over a 32 bit number)
def rot(x: int, n: int):
    # Bitwise rotation (to the left) of n bits considering the
    # string of bits is 32 bits long
    x %= 1 << 32
    n %= 32
    return (x >> (32 - n)) | (x << n) % (1 << 32)





############################################################
#
#                       Utility functions for parsing strings
#
############################################################


# convert a string into a list of int32.
def convert_string_2_int32(message_string):
        string_int32 = []
        # padd the message with to a multiple of 32 bits.
        if len(message_string) % 4 != 0:
                for i in range(4 - len(message_string) % 4):
                        message_string += "."
        # cut the message in block of 32 bits
        for i in range(len(message_string)//4):
                int32 = 0
                int32 = int32 << 8 | ord(message_string[4*i])
                int32 = int32 << 8 | ord(message_string[4*i+1])
                int32 = int32 << 8 | ord(message_string[4*i+2])
                int32 = int32 << 8 | ord(message_string[4*i+3])
                string_int32.append(int32)
        return string_int32

# convert a list of int32 into a string.
def convert_int32_2_string(string_int32):
        message_string = ""
        # repack the bytes into a string
        for i in range(len(string_int32)):
                message_string += chr((string_int32[i] >> 24) % (1 << 8))
                message_string += chr((string_int32[i] >> 16) % (1 << 8))
                message_string += chr((string_int32[i] >> 8) % (1 << 8))
                message_string += chr(string_int32[i] % (1 << 8))
        return message_string

# convert a key to 64 bits
def convert_string_2_int64(key_string):
        # pad the key to 64 bits
        if len(key_string) != 8:
                for i in range(8 - len(key_string) % 8):
                        key_string += "."
        # prepare the key as a 64 bit number
        key64 = 0
        for i in range(8):
                key64 = key64 << 8 | ord(key_string[i])
        return key64








############################################################
#
#                                       CLONE BLOCK CIPHER
#
############################################################


# CLONE Sbox
Sbox = [0xb, 0xe, 0x1, 0xa, 0x9, 0xc, 0x6, 0xf, 0x3, 0x5, 0x0, 0x4, 0x8, 0xd, 0x2, 0x7]

# to complete
inv_Sbox = [10, 2, 14, 8, 11, 9, 6, 15, 12, 4, 3, 0, 5, 13, 1, 7]

def roundf(value,key):
        value_s = append_len(value, 32)[2:]
        indices = [int("0b" + value_s[i:i+4], 2) for i in range(0, len(value_s), 4)]
        box_map = ""
        for index in indices:
                box_map = box_map + append_len(Sbox[index], 4)[2:]
        i_box = int(box_map, 2)
        rotated = rot(i_box, 2)
        return (rotated ^ key)

def inv_roundf(value,key):
        returned = value ^ key
        rotated = rot(returned, 30)
        box_map = append_len(rotated, 32)[2:]
        values = [int("0b" + box_map[i:i+4], 2) for i in range(0, len(box_map), 4)]
        box_map = ""
        for value in values:
                box_map = box_map + append_len(inv_Sbox[value], 4)[2:]               
        return int(box_map, 2)


def key_schedule(key):
        binKey = append_len(key, 64)[2:]
        while(len(binKey) < 64):
                binKey = "0" + binKey
        key_current = int(binKey[:32], 2)
        K1 = int("0b" + binKey[32:], 2)
        key_list = []
        for i in range (0, 4):
                key_list.append(key_current)
                key_current = next_key(key_current, K1)
        return key_list

def next_key(key : int, k1: int):
        return (key ^ rot(key, 8) ^ rot(key, 24) ^ k1)

def clone_encrypt(value,key):
        key_list = key_schedule(key)
        next_round = value ^ key_list[0]
        for i in range (1, len(key_list)):
                next_round = roundf(next_round, key_list[i])
        return next_round

input_difference = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]

def test_difference():
        ret = []
        for difference in input_difference:
                tofill = new_empty(16)
                next_list = create_bijection(difference, input_difference)
                for i in range (0,16):
                        tofill[Sbox[i] ^ Sbox[next_list[i]]] += 1       
                ret.append(tofill)
        return ret

def print_right(list_):
        for i in range(0,16):
                for next_list in list_:
                        print(str(next_list[i]) + " ", end="")
                print()
                
                
def create_bijection(difference, inputs):
        ret = []
        for item in inputs:
                ret.append(item ^ difference)
        return ret

def new_empty(length : int):
        ret = []
        for i in range (0, length):
                ret.append(0)
        return ret

def clone_decrypt(value,key):
        key_list = key_schedule(key)
        i = 3
        next_round = value
        while (i > 0):
                next_round = inv_roundf(next_round, key_list[i])
                i -= 1
        next_round = next_round ^ key_list[0]
        return next_round

def append_len(value : int, length : int):
        binary = bin(value)[2:]
        while (len(binary) < length):
                binary = "0" + binary
        return "0b" + binary

def test():
        test_value = random.randint(0,1 << 31)
        key_value = random.randint(0,1 << 63)

        test_encrypted = clone_encrypt(test_value,key_value)
        test_decrypted = clone_decrypt(test_encrypted,key_value)

        print("test value:\t\t" + hex(test_value)[2:].zfill(8))
        print("key value: \t\t" + hex(key_value)[2:].zfill(16))
        print("encrypted value: \t" + hex(test_encrypted)[2:].zfill(8))
        print("decrypted value: \t" + hex(test_decrypted)[2:].zfill(8))

        if(test_encrypted == test_value):
                print("\nMaybe encryption should provide another value...")
        elif (test_decrypted == test_value):
                print("\nTest passed")
        else:
                print("\nTest failed")



############################################################
#
#                       CLONE BLOCK CIPHER APPLIED WITH ECB
#
############################################################


# intermediates functions: takes list of int32 and key as a long long, return a list of int32
def encrypt(string_int32,key_int64):
        ciphertext_int32 = []
        # ECB encryption (totally not secure)
        for i in range(len(string_int32)):
                ciphertext_int32.append(clone_encrypt(string_int32[i],key_int64))
        return ciphertext_int32

def decrypt(string_int32,key_int64):
        plaintext_int32 = []
        # ECB decryption (totally not secure)
        for i in range(len(string_int32)):
                plaintext_int32.append(clone_decrypt(string_int32[i],key_int64))
        return plaintext_int32

def encrypt_this(message,key):
        message_32 = convert_string_2_int32(message)
        key_64 = convert_string_2_int64(key)
        return encrypt(message_32,key_64)

def decrypt_this(cipher,key):
        key_64 = convert_string_2_int64(key)
        decrypted = decrypt(cipher,key_64)
        return convert_int32_2_string(decrypted)

def test_encrypt():
        print("\nEncryption test, the following two lines should be identical : \n\
['0xa1cac9fc', '0x860043c8', '0x172775e0', '0x917e7ae4', '0x652bbcb5', '0x8d6cbda4', '0x99d605cd', '0x5fb4d9d7', '0x9487520', '0x188fbca5']\
        ")
        message = "I find your lack of faith disturbing.   "
        key = "D4RKV4DR"
        print([hex(x) for x in encrypt_this(message,key)])

def test_decrypt():
        print("\nDecryption test, the following line should be readable !")
        cipher_int32 = [0x6f13c169, 0xef26884f, 0xdd6092a5, 0xabfe90b9]
        key = "P4LP4T1N"
        print(decrypt_this(cipher_int32, key))


############################################################
#
#                                       TEST CASES
#
############################################################

test()
test_encrypt()
test_decrypt()
