initial = [1, 0, 1, 0, 1, 1, 0]

def equals (one, two):
    if (len(one) == len(two)):
        for i in range (0, len(one)):
            if (one[i] != two[i]):
                return False
        return True
    else:
        return False

def XOR(one, two):
    if (one == 1 and two == 1):
        return 0
    elif (one == 0 and two == 0):
        return 0
    else:
        return 1

def iteration(start):
    z = start[6]
    retvalue = []
    retvalue.append(z)
    retvalue.append(start[0])
    retvalue.append(XOR(start[1], z))
    retvalue.append(XOR(start[2], z))
    retvalue.append(XOR(start[3], z))
    retvalue.append(start[4])
    retvalue.append(start[5])
    return retvalue

nextIteration = iteration(initial)
i = 0
print(initial)

while (not equals(initial, nextIteration)):
    print(nextIteration)
    nextIteration = iteration(nextIteration)
    i = i + 1

print(i)
    
