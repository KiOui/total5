#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# MIT LICENCE
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
# WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
# IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

def lxor(a, b):
    if a == '0' and b == '0': return '0'
    if a == '1' and b == '0': return '1'
    if a == '0' and b == '1': return '1'
    if a == '1' and b == '1': return '0'
    return '?'

def bit_to_num(a):
    if a == '0': return 0
    if a == '1': return 1
    if a == '?': raise ValueError('Error: Converting unknown value to number')

def gen_bit(a):
    if a == 1: return '1'
    return '0'


def init():
    return ['?' for x in range(30)]

def getbit(state, index):
    return state[index]

def setbit(state, index, value):
    state[index] = value

def print_state(state):
    print(''.join(state))


def multiplexer(state):
    getindex = bit_to_num(state[28])
    getindex += 2 * bit_to_num(state[25])
    getindex += 4 * bit_to_num(state[22])
    getindex += 8 * bit_to_num(state[19])
    return getindex + 1

def iterate(state):
    bit = state.pop()
    # x^30 + x^17 + x^16 + x^13 + x^11 + x^7 + x^5 + x^3 + x^2 + x + 1
    indexes = [1, 2, 3, 5, 7, 11, 13, 16, 17]
    for i in indexes:
        b = getbit(state, i)
        setbit(state, i, lxor(bit, b))
    state.insert(0, bit)
    return state

def roundf(state):
    state = iterate(state)
    index_to_return = multiplexer(state)
    return getbit(state, index_to_return)


def init_search_state(index_search):
    if (index_search < 0 or index_search > 1023):
        raise ValueError('Error: Value too low or too high')
    state = init()[:20]
    binary_index = bin(index_search)[2:]
    while (len(binary_index) < 10):
        binary_index = '0' + binary_index
    state = state + list(binary_index)
    return state

def target_output(state):
    output = []
    for i in range (0, 20):
        output.append(roundf(state))
    return(output)

def compatible(state,expected,index):
    # Comment: expected contains the list of outputs that will need to match
    # Comment: index is the current index in this list that we are checking
    if index == len(expected): # we have checked all the expected bits
        print("Found!")
        print("Target output: ")
        print_state(target_output(state))
        return 1
    else:
        if getbit(state, 19) is not '?' : # the 19th bit of the state is set (not a '?')
            # what is the index of the bit that would be returned (call it fetched)
            fetched_index = multiplexer(state)
            if getbit(state, fetched_index) is not '?' : # the fetched bit is set
                if getbit(state, fetched_index) is getbit(expected, index): # does it match with expected[index] ?
                    # iterate the state
                    state = iterate(state)
                    # increment the index
                    index += 1
                    return compatible(state,expected,index)
                else:
                    # Comment: it is a contradiction!
                    return 0
            else:
                # set the fetched bit to the expected value
                setbit(state, fetched_index, getbit(expected, index))
                # iterate the state
                state = iterate(state)
                # increment the index
                index += 1
                return compatible(state,expected,index)
        else:
            # make a copy of the state: l0 = list(l)
            copy0 = list(state)
            # set the 19th bit to 0
            setbit(copy0, 19, '0')
            if compatible(copy0, expected, index) == 1: # compatible(state_0,expected,index) returns 1
                return 1 # Comment: we have a solution!
            # make a copy of the state: l1 = list(l)
            copy1 = list(state)
            # set the 19th bit to 1
            setbit(copy1, 19, '1')
            if compatible(copy1, expected, index) == 1: # compatible(state_1,expected,index) returns 1
                return 1 # Comment: we have a solution!
            return 0 # Comment: we do not have a solution :(


def search():
    expected_values = list('111110001001001110111101011000001000100100001010101010101101')
    for i in range(1024):
        search_state_init = init_search_state(i)
        print_state(search_state_init)
        backup = list(search_state_init)
        if compatible(search_state_init, expected_values, 0) == 1: 
            return 1
    print("not found :(")

# uncomment this line to do the search
search()
