
#Square and multiply function
def square_and_multiply(g,x,n):
    total = 1
    tosquare = g
    list = to_array(g)
    for i in range(0, len(list)):
        if (list[i] != 0):
            total = (total * tosquare) % n
        tosquare = tosquare * tosquare

    return total

#Convertion to binary
def to_array(g):
    next = bin(g)[2:]
    list = []
    while next != '':
        list.append(ord(next[:1])-48)
        next = next[1:]

    return list



print("This will efficiently compute g^x mod n")
print("Please enter a value for g:")
g = int(input())
print("Please enter a value for x:")
x = int(input())
print("Please enter a value for n:")
n = int(input())
print(square_and_multiply(g, x, n))
