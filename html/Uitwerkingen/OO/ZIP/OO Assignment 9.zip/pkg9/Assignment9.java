/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.pkg9;

public class Assignment9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println(new Slagroom(new Slagroom(new VanilleIjs())).geefBeschrijving());
        System.out.println(new Slagroom(new Slagroom(new Chocodip(new YoghurtIjs()))).prijs());
        System.out.println(new Slagroom(new Slagroom(new Chocodip(new YoghurtIjs()))).geefBeschrijving());
    }
    
}
