/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.pkg9;

public class VanilleIjs extends Ijsje{
    
    public VanilleIjs() {
        beschrijving = "Vanille ijs";
    }
    
    @Override
    public int prijs() {
        return 150;
    }
    
    @Override
    public String geefBeschrijving() {
        return beschrijving;
    }
    
    
}
