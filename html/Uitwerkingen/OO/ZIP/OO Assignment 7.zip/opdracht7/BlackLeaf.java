
package qtrees;

import java.io.IOException;
import java.io.Writer;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BlackLeaf implements QTNode {
    
    public BlackLeaf() {
        
    }
    
    /**
     * Vult een bitmap met false over bepaalde coordinaten
     * @param x de beginnende x coordinaat van deze BlackLeaf
     * @param y de beginnende y coordinaat van deze BlackLeaf
     * @param width de breedte van het te vullen blok
     * @param bitmap de bitmap waarnaartoe geschreven wordt
     */
    @Override
    public void fillBitmap(int x, int y, int width, Bitmap bitmap) {
        bitmap.fillArea(x, y, width, false);
    }
    
    /**
     * Schrijft de String "00" naar de Writer
     * @param out de Writer waarnaartoe geschreven wordt
     */
    @Override
    public void writeNode(Writer out) {
        try {
            out.write("00");
        } catch (IOException ex) {
            Logger.getLogger(BlackLeaf.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
