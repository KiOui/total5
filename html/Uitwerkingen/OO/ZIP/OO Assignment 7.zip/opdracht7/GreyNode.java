
package qtrees;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GreyNode implements QTNode{
    
    private QTNode[] Childs;
    
    /**
     * Maakt een GreyNode aan met een Reader als input
     * @param input een Reader met gecodeerde gegevens over de te maken Childs van deze GreyNode
     */
    public GreyNode(Reader input) {
        Childs = new QTNode[4];
        for (int i = 0; i < 4; i++) {
            int nextInt = 2;
            try {
                nextInt = input.read();
            } catch (IOException ex) {
                Logger.getLogger(GreyNode.class.getName()).log(Level.SEVERE, null, ex);
            }
            if(nextInt == 49) {
                //1
                Childs[i] = new GreyNode(input);
            }
            else if (nextInt == 48) {
                try { 
                    nextInt = input.read();
                } catch (IOException ex) {
                    Logger.getLogger(GreyNode.class.getName()).log(Level.SEVERE, null, ex);
                }
                if (nextInt == 49) {
                    //1
                    Childs[i] = new WhiteLeaf();
                }
                else if (nextInt == 48) {
                    //0
                    Childs[i] = new BlackLeaf();
                }
            }
        }
    }
    
    /**
     * Maakt een GreyNode aan met een bitmap als input
     * @param x de beginnende x coordinaat van deze GreyNode
     * @param y de beginnende y coordinaat van deze GreyNode
     * @param width de breedte van de blokjes die onder deze GreyNode vallen
     * @param bitmap een bitmap met gecodeerde gegevens over de te maken Childs van deze GreyNode
     */
    public GreyNode(int x, int y, int width, Bitmap bitmap) {
        Childs = new QTNode[4];
        for (int o = 0; o < 4; o++) {
            int black = 0;
            int white = 0;

            for (int i = x; i < x + width; i++) {
                for (int j = y; j < y + width; j++) {
                    if (bitmap.getBit(i, j)) {
                        //white
                        white++;
                    }
                    else {
                        black++;
                    }
                }
            }
            
            if (black == 0) {
                Childs[o] = new WhiteLeaf();
            }
            else if (white == 0) {
                Childs[o] = new BlackLeaf();
            }
            else {
                Childs[o] = new GreyNode(x, y, width/2, bitmap);
            }
            
            switch (o) {
                case 0:
                    x += width;
                    break;
                case 1:
                    y += width;
                    break;
                case 2:
                    x -= width;
                    break;
                default:
                    break;
            }
         }
    }
    
    /**
     * Vult een bitmap met de data uit deze GreyNode
     * @param x de beginnende x coordinaat van deze GreyNode
     * @param y de beginnende y coordinaat van deze GreyNode
     * @param width de breedte van de blokjes die onder deze GreyNode vallen
     * @param bitmap de bitmap waarnaartoe geschreven wordt
     */
    @Override
    public void fillBitmap(int x, int y, int width, Bitmap bitmap) {
        Childs[0].fillBitmap(x, y, width/2, bitmap);
        Childs[1].fillBitmap(x + width/2, y, width/2, bitmap);
        Childs[2].fillBitmap(x + width/2, y + width/2, width/2, bitmap);
        Childs[3].fillBitmap(x, y + width/2, width/2, bitmap);
    }
    
    /**
     * Schrijft de gegevens van deze GreyNode naar een Writer
     * @param out de Writer waarnaartoe geschreven wordt
     */
    @Override
    public void writeNode(Writer out) {
        try {
            out.write("1");
        } catch (IOException ex) {
            Logger.getLogger(GreyNode.class.getName()).log(Level.SEVERE, null, ex);
        }
        for (int i = 0; i < 4; i++ ) {
            Childs[i].writeNode(out);
        }
    }
    
}
