package qtrees;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.logging.Level;
import java.util.logging.Logger;

public class QTree {
    QTNode root;
    
    /**
     * Maakt een nieuwe QTree aan met een Reader als input
     * @param input de reader met de gecodeerde gegevens voor een QTree
     */
    public QTree( Reader input ) {
        root = readQTree( input );
    }
    
    /**
     * Maakt een nieuwe QTree aan met een bitmap als input
     * @param bitmap de bitmap met de gecodeerde gegevens voor een QTree
     */
    public QTree( Bitmap bitmap ) {
        root = bitmap2QTree( 0, 0,  bitmap.getWidth(), bitmap );
    }
    
    /**
     * Maakt een bitmap aan met de QTree als basis
     * @param bitmap de bitmap waarin de QTree wordt geschreven
     */
    public void fillBitmap ( Bitmap bitmap ) {
        root.fillBitmap(0, 0, bitmap.getWidth(), bitmap);
    }
    
    /**
     * Maakt een Writer aan met de QTree als basis
     * @param sb de Writer waarin de QTree wordt geschreven
     */
    public void writeQTree( Writer sb ) {
        root.writeNode( sb );
    }
    
    /**
     * Maakt van een gecodeerde input (Reader) een QTree
     * @param input de reader met de gecodeerde gegevens voor een QTree
     * @return de bovenste Node van de QTree die gemaakt is
     */
    private static QTNode readQTree( Reader input ) {
        int nextInt = 2;
        
        try {
            nextInt = input.read();
        } catch (IOException ex) {
            Logger.getLogger(QTree.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        if (nextInt == 49) {
            return new GreyNode(input);
        }
        else if (nextInt == 48) {
                try { 
                    nextInt = input.read();
                } catch (IOException ex) {
                    Logger.getLogger(GreyNode.class.getName()).log(Level.SEVERE, null, ex);
                }
                if (nextInt == 49) {
                    //1
                    return new WhiteLeaf();
                }
                else if (nextInt == 48) {
                    //0
                    return new BlackLeaf();
                }
            }
        
        return null;
    }
    
    /**
     * Maakt van een bitmap een QTree
     * @param x coordinaat voor de xAs
     * @param y coordinaat voor de yAs
     * @param width de breedte van de bitmap
     * @param bitmap de bitmap waaruit de gegevens worden gehaald
     * @return de bovenste Node van de QTree die gemaakt is
     */
    public static QTNode bitmap2QTree( int x, int y, int width, Bitmap bitmap ) {
        int black = 0;
        int white = 0;
        
        for (int i = 0; i < width; i++) {
            for (int j = 0; j < width; j++) {
                if (bitmap.getBit(i, j)) {
                    //white
                    white++;
                }
                else {
                    black++;
                }
            }
        }
        if (black == 0) {
            return new WhiteLeaf();
        }
        else if (white == 0) {
            return new BlackLeaf();
        }
        else {
            return new GreyNode(x, y, width/2, bitmap);
        }
    }

}
