package qtrees;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Qtrees {

    public static void main(String[] args) {
        String test_tekst = "10011010001010010001010101100011000101000000";
        StringReader input = new StringReader(test_tekst);
        QTree qt = new QTree( input );
        Bitmap bitmap = new Bitmap(8, 8);
        qt.fillBitmap( bitmap );
        System.out.println(bitmap);
        QTree bitmapQT = new QTree(bitmap);
        StringWriter tekst = new StringWriter();
        bitmapQT.writeQTree(tekst);
        System.out.println(tekst);
        
        
    }

}
