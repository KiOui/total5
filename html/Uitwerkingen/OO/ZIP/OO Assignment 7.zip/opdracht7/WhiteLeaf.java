
package qtrees;

import java.io.IOException;
import java.io.Writer;
import java.util.logging.Level;
import java.util.logging.Logger;

public class WhiteLeaf implements QTNode{
    
    public WhiteLeaf() {
        
    }
    
    /**
     * Vult een bitmap met true over bepaalde coordinaten
     * @param x de beginnende x coordinaat van deze WhiteLeaf
     * @param y de beginnende y coordinaat van deze WhiteLeaf
     * @param width de breedte van het te vullen blok
     * @param bitmap de bitmap waarnaartoe geschreven wordt
     */
    @Override
    public void fillBitmap(int x, int y, int width, Bitmap bitmap) {
        bitmap.fillArea(x, y, width, true);
    }

    /**
     * Schrijft de String "01" naar de Writer
     * @param out de Writer waarnaartoe geschreven wordt
     */
    @Override
    public void writeNode(Writer out) {
        try {
            out.write("01");
        } catch (IOException ex) {
            Logger.getLogger(WhiteLeaf.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
