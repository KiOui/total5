package mandelfx;


import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import mandelmodel.AreaFiller;
import mandelmodel.ColorMap;
import mandelmodel.filler;

public class MandelFX extends Application {

    public static final int GRID_WIDTH = 650, GRID_HEIGHT = 650;    
    private Canvas canvas;
    private int maxIterations = 100;
    private double startFactor = 100;
    private double startX = 0.;
    private double startY = 0.;
    private Label labelX = new Label();
    private Label labelY = new Label();
    private Label labelF = new Label();
    private Label labelI = new Label();
    private TextField xAs = new TextField();
    private TextField yAs = new TextField();
    private TextField factor = new TextField();
    private TextField iteration = new TextField();
    private Rectangle rect;
    
    
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Mandelbrot");
        primaryStage.setScene( makeScene() );
        primaryStage.show();
    }

    private Scene makeScene() {
        canvas = new Canvas(GRID_WIDTH, GRID_HEIGHT);
        filler areaFiller = new filler(canvas);
        

        areaFiller.colorSetter(startX, startY, startFactor, maxIterations);
        Group root = new Group( canvas );
        GridPane grid = new GridPane();
        Button button = new Button();
        button.setOnAction((ActionEvent event) -> {
            applyButton(areaFiller);
        });
        
        //canvas.setOnMouseClicked(e->mouseEvent(e,areaFiller));
        canvas.setOnMouseDragged(e->mouseDragged(e));
        canvas.setOnMousePressed(e->mousePressed(e, root));
        canvas.setOnMouseReleased(e->mouseReleased(e, root, areaFiller));
        
        button.setText("Apply");
        xAs.setText(startX + "");
        yAs.setText(startY + "");
        factor.setText(startFactor + "");
        iteration.setText(maxIterations + "");
        labelX.setText("X-As");
        labelY.setText("Y-As");
        labelF.setText("Factor");
        labelI.setText("Iterations");
        
        grid.add(root, 0, 0, 5, 1);
        grid.add(button, 0, 2);
        grid.add(xAs, 1, 2);
        grid.add(yAs, 2, 2);
        grid.add(factor, 3, 2);
        grid.add(labelX,1,1);
        grid.add(labelY,2,1);
        grid.add(labelF,3,1);
        grid.add(labelI,4,1);
        grid.add(iteration,4,2);
        
        Scene scene = new Scene(grid);
        return scene;
    }
    
    private void applyButton(filler areaFiller) {
        double factorI = Double.parseDouble(factor.getText());
        double x = Double.parseDouble(xAs.getText());
        double y = Double.parseDouble(yAs.getText());
        int nextIterations = (int) Double.parseDouble(iteration.getText());
        System.out.println(nextIterations);
        
        fieldUpdater(x, y, factorI, nextIterations);
        
        areaFiller.colorSetter(x, y, factorI, nextIterations);
    }
    
    public static void main(String[] args) {
        launch(args);
    }

    private void mouseEvent(MouseEvent e, filler areaFiller) {
        
        double xPressed = this.startX - (3.25/(this.startFactor/100)-e.getX()/this.startFactor);
        double yPressed = this.startY + (3.25/(this.startFactor/100)-e.getY()/this.startFactor);
        double nextFactor = 0;
        
        if (e.isShiftDown()) {
            nextFactor = startFactor/2;
        }
        else {
            nextFactor = startFactor*2;
        }
        
        fieldUpdater(xPressed, yPressed, nextFactor, this.maxIterations);

        areaFiller.colorSetter(xPressed, yPressed, nextFactor, maxIterations);
        
        
    }
    
    private void fieldUpdater(double x, double y, double nextFactor, int nextIterations) {
        this.startX = x;
        this.startY = y;
        this.startFactor = nextFactor;
        this.maxIterations = nextIterations;
        
        xAs.setText(startX + "");
        yAs.setText(startY + "");
        factor.setText(startFactor + "");
        iteration.setText(maxIterations + "");
    }
    
    private void mouseDragged(MouseEvent e) {
        rect.setWidth(e.getX() - rect.getX());
        rect.setHeight(e.getY() - rect.getY());
        
    }

    private void mousePressed(MouseEvent e, Group root) {
        double x = e.getX();
        double y = e.getY();
        ColorMap cm = new ColorMap(256);
        
        rect = new Rectangle(x, y, 0, 0);
        rect.setFill(cm.getColor(1));
        root.getChildren().add(rect);
    }

    private void mouseReleased(MouseEvent e, Group root, filler areaFiller) {
        root.getChildren().remove(rect);
        if (rect.getHeight() < 5 && rect.getWidth() < 5) {
            mouseEvent(e, areaFiller);
        }
        else {
            double height = rect.getHeight();
            double width = rect.getWidth();
            double maxSize = 0;
            
            if (height >= width) {
                maxSize = height;
            }
            else {
                maxSize = width;
            }
            
            double x = rect.getX() + (width/2);
            double y = rect.getY() + (height/2);
            
            double xPressed = this.startX - (3.25/(this.startFactor/100)-x/this.startFactor);
            double yPressed = this.startY + (3.25/(this.startFactor/100)-y/this.startFactor);
            
            double newFactor = (1/(maxSize/((GRID_WIDTH+GRID_HEIGHT)/2)))*this.startFactor;
            
            fieldUpdater(xPressed, yPressed, newFactor, this.maxIterations);

            areaFiller.colorSetter(xPressed, yPressed, newFactor, maxIterations);
        }
    }
   
}
