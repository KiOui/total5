/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mandelmodel;

import javafx.scene.canvas.Canvas;
import javafx.scene.image.PixelWriter;

public class filler {
    
    private final Canvas c;
    private final PixelWriter writer;
    private final ColorMap map;
    
    public filler (Canvas canvas) {
        this.c = canvas;
        this.writer = canvas.getGraphicsContext2D().getPixelWriter();
        map = new ColorMap(256);
    }
    
    public void colorSetter(double x, double y, double zoomFactor, int maxIterations) {
        
        double schermGrootte = c.getHeight();
        double schermBreedte = c.getWidth();
        
        double mandelGrootte = schermGrootte/zoomFactor;
        double mandelBreedte = schermBreedte/zoomFactor;
        
        double linksBovenX = x-mandelGrootte/2;
        double linksBovenY = y+mandelBreedte/2;
        
        double factor = 1/zoomFactor;
        
        x = linksBovenX;
        y = linksBovenY;
        
        for (int a = 0; a < schermGrootte; a++) {
            for (int b = 0; b < schermBreedte; b++) {
                
                int iter = calculation(x, y, maxIterations);
                writer.setColor(b, a, map.getColor(iter));
                x = x+factor;
               
            }
            y = y-factor;
            x = linksBovenX;
        }
        
        
        
    }
    
    private int calculation(double x, double y, int iterations) {
        
        double a = 0;
        double b = 0;
        
        double tempA = 0;
        
        int returnValue = 0;
        
        while (Math.sqrt(a*a+b*b) < 2 && returnValue < iterations) {
            
            a = (tempA * tempA) - (b * b) + x;
            b = 2 * tempA * b + y;
            
            tempA = a;
            returnValue++;
        }
        
        return returnValue;
    }
    
    
}
