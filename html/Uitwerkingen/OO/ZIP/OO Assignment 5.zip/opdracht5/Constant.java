/*
 * Een constante is een expressie met een waarde
 */
package opdracht5;

import java.util.Map;
public class Constant extends withoutArgument{
    
    private final double value;
    
    /**
     * Maakt een constante aan met een bepaalde waarde
     * @param value de waarde die de constante moet krijgen
     */
    public Constant(double value) {
        this.value = value;
    }
    
    /**
     * Geeft de waarde van de constante
     * @return de waarde van deze constante als een double
     */
    @Override
    public double getValue() {
        return value;
    }
    
    /**
     * Geeft de constante waarde als een string
     * @return de waarde van deze constante als een string
     */
    @Override
    public String toString() {
        return "" + value;
    }
    
    /**
     * Geeft de waarde van deze constante als een double
     * @param map de map waarin alle variabelen met hun waarden staan opgeslagen
     * @return de waarde van deze constante als een double
     */
    @Override
    public double eval(Map<String, Double> map) {
        return value;
    }
    
    /**
     * Optimaliseerd deze constante
     * @return deze constante
     */
    @Override
    public Expression optimize() {
        return this;
    }
    
    /**
     * 
     * @return true
     */
    @Override
    public boolean isConstant() {
        return true;
    }
}
