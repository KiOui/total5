/*
 * Een expressie met een wiskundig teken ervoor (zoals een wortel of een negatie)
 */
package opdracht5;

import java.util.Map;
public abstract class singleArgument implements Expression{
    
    private final Expression exp;
    
    /**
     * Maakt een singleArgument expressie aan met een andere expressie
     * @param exp de expressie van deze singleArgument expressie
     */
    public singleArgument(Expression exp) {
        this.exp = exp;
    }
    
    /**
     * Geeft deze expressie als een string
     * @return deze expressie als een string met haakjes, in de vorm: ([expressie])
     */
    @Override
    public String toString() {
        return "(" + exp.toString() + ")";
    }
    
    /**
     * Evalueerd deze expressie
     * @param map de map waarin alle variabelen met hun waarden staan opgeslagen
     * @return de evaluatiefunctie over this.exp
     */
    @Override
    public double eval(Map<String, Double> map) {
        return exp.eval(map);
    }
    
    /**
     * Verteld of deze expressie een constante is
     * @return of de expressie this.exp een constante is
     */
    @Override
    public boolean isConstant() {
        return exp.isConstant();
    }
    
    /**
     * Geeft de waarde van deze Expressie
     * @return de waarde van this.exp als een double
     */
    @Override
    public double getValue() {
        return exp.getValue();
    }
    
    /**
     * Optimaliseerd deze expressie
     * @return een geoptimaliseerde expressie, als dit niet kan wordt deze expressie teruggegeven
     */
    @Override
    public Expression optimize() {
        if (this.exp.optimize().isConstant()) {
            return new Constant(exp.optimize().getValue());
        }
        else {
            return this.exp.optimize();
        }
    }

}
