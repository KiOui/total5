/*
 * Interface van elke expressie
 */
package opdracht5;

import java.util.Map;

public interface Expression {
    
    /**
     * Maakt een String aan met de expressie
     * @return string met expressie (meestal tussen haakjes)
     */
    @Override
    public String toString();
    
    /**
     * Evalueert de expressie (kan er een double uit de expressie worden berekend?)
     * @param map de map waarin alle variabelen met waarden zijn opgeslagen
     * @return de uitkomst van de expressie als een double
     */
    public double eval(Map<String, Double> map);
    
    /**
     * Optimalizeerd een expressie naar een kleinere vorm (als dat mogelijk is)
     * @return een kleinere of dezelfde expressie
     */
    public Expression optimize();
    
    /**
     * 
     * @return true als de expressie een constante is
     */
    public boolean isConstant();
    
    /**
     * Geeft de waarde van een expressie (als het een constante is)
     * @return de waarde van een expressie of -1 als de expressie geen constante is
     */
    public double getValue();
}
