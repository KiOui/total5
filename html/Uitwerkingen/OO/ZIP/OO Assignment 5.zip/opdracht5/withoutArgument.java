/*
 * Deze abstracte klasse heeft alle expressies met maar 1 argument onder zich
 */
package opdracht5;

public abstract class withoutArgument implements Expression{
    
}
