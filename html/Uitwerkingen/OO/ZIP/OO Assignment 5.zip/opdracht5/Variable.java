/*
 * Een variabele is een Expressie zonder argumenten en zonder vaste waarde
 */
package opdracht5;

import java.util.Map;
public class Variable extends withoutArgument{
    
    private final String name;
    
    /**
     * Maake een variabele aan met een bepaalde naam
     * @param name de naam van deze variabele
     */
    public Variable(String name) {
        this.name = name;
    }
    
    /**
     * Geeft de naam van deze variabele
     * @return de naam van deze variabele als een string
     */
    @Override
    public String toString() {
        return name;
    }
    
    /**
     * Evalueert deze variabele
     * @param map de map waarin alle variabelen met hun waarden staan opgeslagen
     * @return de waarde van deze variabele gevonden in de map
     */
    @Override
    public double eval(Map<String, Double> map) {
        return  map.get(name);
    }
    
    /**
     * Optimaliseerd deze variabele
     * @return deze variabele
     */
    @Override
    public Expression optimize() {
        return this;
    }
    
    /**
     * 
     * @return -1
     */
    @Override
    public double getValue() {
        return -1.;
    }
    
    /**
     * 
     * @return false
     */
    @Override
    public boolean isConstant() {
        return false;
    }
}
