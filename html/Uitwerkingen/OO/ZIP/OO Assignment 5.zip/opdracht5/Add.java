/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opdracht5;

import java.util.Map;

public class Add extends doubleArgument{
    
    /**
     * Maakt een Add expression aan met twee andere expressies
     * @param x de eerste expressie van deze Add expressie
     * @param y de tweede expressie van deze Add expressie
     */
    public Add(Expression x, Expression y) {
        super(x, y);
    }

    /**
     * Geeft deze expressie als een string
     * @return deze expressie als een string met haakjes en een plus teken, in de vorm: ([x] + [y])
     */
    @Override
    public String toString() {
        return "(" + super.xToString() + " + " + super.yToString() + ")";
    }

    /**
     * Evalueerd deze expressie
     * @param map de map waarin alle variabelen met hun waarden staan opgeslagen
     * @return de evaluatiefunctie over x+y
     */
    @Override
    public double eval(Map<String, Double> map) {
        return super.getX(map) + super.getY(map);
    }
    
    /**
     * Optimaliseerd deze expressie
     * @return een geoptimaliseerde Add expressie, als dit niet kan wordt de gewone expressie teruggegeven
     */
    @Override
    public Expression optimize() {
        if (super.optimizeX().isConstant() && super.optimizeY().isConstant()) {
            return new Constant(super.optimizeX().getValue() + super.optimizeY().getValue());
        }
        else if (super.optimizeX().getValue() == 0) {
            return super.optimizeY();
        }
        else if (super.optimizeY().getValue() == 0) {
            return super.optimizeX();
        }
        else {
            return new Add(this.optimizeX(), this.optimizeY());
        }
    }    

    /**
     * De functie geeft aan of de expressie constant is of niet
     * @return false omdat een Add nooit constant zal zijn
     */
    @Override
    public boolean isConstant() {
        return false;
    }

    /**
     * Geeft de waarde van de expressie (als het een constante is)
     * @return -1 omdat de expressie geen constante is
     */
    @Override
    public double getValue() {
        return -1;
    }
}
