/*
 * Hoofdklasse van dit project
 */
package opdracht5;

import java.util.HashMap;
import java.util.Map;
import static opdracht5.ExpressionFactory.*;

public class Opdracht5 {


    public static void main(String[] args) {
        Map<String, Double> map = new HashMap<>();
        map.put("pi", 3.1415);
        map.put("a", 42.);
        map.put("x", 15.);
        
        Expression e1 = add(mul(con(2.), con(3.)), var("x"));
        Expression e2 = mul(con(3.), var("a"));
        Expression e3 = sqr(add(con(7.), neg(con(5.))));
        System.out.println("E1: " + e1.toString() + " - Result: " + e1.eval(map) + " - Optimized: " + e1.optimize().toString());
        System.out.println("E2: " + e2.toString() + " - Result: " + e2.eval(map) + " - Optimized: " + e2.optimize().toString());
        System.out.println("E3: " + e3.toString() + " - Result: " + e3.eval(map) + " - Optimized: " + e3.optimize().toString());
    }
    
}
