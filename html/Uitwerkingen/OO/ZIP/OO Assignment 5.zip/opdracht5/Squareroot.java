/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opdracht5;

import static java.lang.StrictMath.sqrt;
import java.util.Map;

public class Squareroot extends singleArgument{
    
    /**
     * Maakt een Squareroot expressie aan met een andere expressie
     * @param exp de expressie van deze Squareroot expressie
     */
    public Squareroot(Expression exp) {
        super(exp);
    }
    
    /**
     * Geeft deze expressie als een string
     * @return deze expressie als een string met squareroot ervoor, in de vorm: squareroot[expressie]
     */
    @Override
    public String toString() {
        return "squareroot" + super.toString();
    }
    
    /**
     * Evalueerd deze expressie
     * @param map de map waarin alle variabelen met hun waarden staan opgeslagen
     * @return de evaluatiefunctie over de square root of this.exp
     */
    @Override
    public double eval(Map<String, Double> map) {
        return sqrt(super.eval(map));
    }
    
    /**
     * Optimaliseerd deze expressie
     * @return een geoptimaliseerde Squareroot expressie, als dit niet kan wordt de gewone expressie teruggegeven
     */
    @Override
    public Expression optimize() {
        if (super.optimize().isConstant()) {
            return new Constant(sqrt(super.optimize().getValue())); 
        }
        else {
            return new Squareroot(super.optimize());
        }
    }
}
