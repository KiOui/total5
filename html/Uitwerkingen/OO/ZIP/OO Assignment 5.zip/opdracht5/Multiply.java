/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opdracht5;

import java.util.Map;

public class Multiply extends doubleArgument{
    
    /**
     * Maakt een Multiply expression aan met twee andere expressies
     * @param x de eerste expressie van deze Multiply expressie
     * @param y de tweede expressie van deze Multiply expressie
     */
    public Multiply(Expression x, Expression y) {
        super(x, y);
    }

    /**
     * Geeft deze expressie als een string
     * @return deze expressie als een string met haakjes en een keer teken, in de vorm: ([x] * [y])
     */
    @Override
    public String toString() {
        return "(" + super.xToString() + " * " + super.yToString() + ")";
    }

    /**
     * Evalueerd deze expressie
     * @param map de map waarin alle variabelen met hun waarden staan opgeslagen
     * @return de evaluatiefunctie over x*y
     */
    @Override
    public double eval(Map<String, Double> map) {
        return getX(map) * getY(map);
    }
    
    /**
     * Optimaliseerd deze expressie
     * @return een geoptimaliseerde Multiply expressie, als dit niet kan wordt de gewone expressie teruggegeven
     */
    @Override
    public Expression optimize() {
        if (super.optimizeX().isConstant() && super.optimizeY().isConstant()) {
            return new Constant(super.optimizeX().getValue() * super.optimizeY().getValue());
        }
        else if (super.optimizeX().getValue() == 0 || super.optimizeY().getValue() == 0) {
            return new Constant(0);
        }
        else if (super.optimizeX().getValue() == 1) {
            return super.optimizeY();
        }
        else if (super.optimizeY().getValue() == 1) {
            return super.optimizeX();
        }
        else {
            return new Multiply(this.optimizeX(), this.optimizeY());
        }
    }

    /**
     * De functie geeft aan of de expressie constant is of niet
     * @return false omdat een Multiply nooit constant zal zijn
     */
    @Override
    public boolean isConstant() {
        return false;
    }

    /**
     * Geeft de waarde van de expressie (als het een constante is)
     * @return -1 omdat de expressie geen constante is
     */
    @Override
    public double getValue() {
        return -1;
    }
}
