/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opdracht5;

import java.util.Map;

public class Negate extends singleArgument{
    
    /**
     * Maakt een Negate expressie aan met een andere expressie
     * @param exp de expressie van deze Negate expressie
     */
    public Negate(Expression exp) {
        super(exp);
    }
    
    /**
     * Geeft deze expressie als een string
     * @return deze expressie als een string met een min, in de vorm: -[expressie]
     */
    @Override
    public String toString() {
        return "-" + super.toString();
    }

    /**
     * Evalueerd deze expressie
     * @param map de map waarin alle variabelen met hun waarden staan opgeslagen
     * @return de evaluatiefunctie over this.exp * -1
     */
    @Override
    public double eval(Map<String, Double> map) {
        return super.eval(map) * -1;
    }
    
   /**
     * Optimaliseerd deze expressie
     * @return een geoptimaliseerde Negate expressie, als dit niet kan wordt de gewone expressie teruggegeven
     */
    @Override
    public Expression optimize() {
        if (super.optimize().isConstant()) {
            return new Constant(super.optimize().getValue() * -1); 
        }
        else {
            return new Negate(super.optimize());
        }
    }
    
}
