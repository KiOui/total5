/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opdracht5;

public class ExpressionFactory {
    
    /**
     * Maakt een Add expression aan met twee andere expressies
     * @param x de eerste expressie van deze Add expressie
     * @param y de tweede expressie van deze Add expressie
     * @return de Add expressie die is aangemaakt
     */
    public static Expression add(Expression x, Expression y) {
        return new Add(x, y);
    }
    
    /**
     * Maakt een Multiply expression aan met twee andere expressies
     * @param x de eerste expressie van deze Multiply expressie
     * @param y de tweede expressie van deze Multiply expressie
     * @return de Multiply expressie die is aangemaakt
     */
    public static Expression mul(Expression x, Expression y) {
        return new Multiply(x, y);
    }
    
    /**
     * Maakt een Squareroot expressie aan met een andere expressie
     * @param x de expressie van deze Squareroot expressie
     * @return de Squareroot expressie die is aangemaakt
     */
    public static Expression sqr(Expression x) {
        return new Squareroot(x);
    }
    
    /**
     * Maakt een Negate expressie aan met een andere expressie
     * @param x de expressie van deze Negate expressie
     * @return de Negate expressie die is aangemaakt
     */
    public static Expression neg(Expression x) {
        return new Negate(x);
    }
    
    /**
     * Maake een variabele aan met een bepaalde naam
     * @param name de naam van deze variabele
     * @return de Variable die is aangemaakt
     */
    public static Expression var(String name) {
        return new Variable(name);
    }
    
    /**
     * Maakt een constante aan met een bepaalde waarde
     * @param value de waarde die de constante moet krijgen
     * @return de Constant die is aangemaakt
     */
    public static Expression con(double value) {
        return new Constant(value);
    }
}
