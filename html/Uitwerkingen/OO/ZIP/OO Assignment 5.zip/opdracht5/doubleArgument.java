/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opdracht5;

import java.util.Map;

public abstract class doubleArgument implements Expression{
    
    private final Expression x;
    private final Expression y;
    
    /**
     * Maakt een doubleArgument expressie aan met twee andere expressies
     * @param x de eerste expressie van deze doubleArgument expressie
     * @param y de tweede expressie van deze doubleArgument expressie
     */
    public doubleArgument(Expression x, Expression y) {
        this.x = x;
        this.y = y;
    }
    
    /**
     * Geeft de waarde van de variabele x uit deze expressie
     * @param map de map waarin alle variabelen met hun waarden staan opgeslagen
     * @return de waarde variabele x gevonden in de map
     */
    public double getX(Map<String, Double> map) {
        return x.eval(map);
    }
    
    /**
     * Geeft de waarde van de variabele y uit deze expressie
     * @param map de map waarin alle variabelen met hun waarden staan opgeslagen
     * @return de waarde variabele y gevonden in de map
     */
    public double getY(Map<String, Double> map) {
        return y.eval(map);
    }
    
    /**
     * Geeft de x waarde van deze expressie als een string
     * @return de x waarde van deze expressie als een string
     */
    public String xToString() {
        return x.toString();
    }
    
    /**
     * Geeft de x waarde van deze expressie als een string
     * @return dex waarde van deze expressie als een string
     */
    public String yToString() {
        return y.toString();
    }
    
    /**
     * Optimaliseerd de x waarde van deze expressie
     * @return een geoptimaliseerde x waarde van deze expressie, als dit niet kan wordt de x waarde van deze expressie teruggegeven
     */
    public Expression optimizeX() {
        return this.x.optimize();
    }
    
    /**
     * Optimaliseerd de y waarde van deze expressie
     * @return een geoptimaliseerde y waarde van deze expressie, als dit niet kan wordt de y waarde van deze expressie teruggegeven
     */
    public Expression optimizeY() {
        return this.y.optimize();
    }
}
