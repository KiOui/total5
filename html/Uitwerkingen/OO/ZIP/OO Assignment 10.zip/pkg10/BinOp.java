/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opgave.pkg10;

import java.util.function.BinaryOperator;

public enum BinOp implements BinaryOperator<Boolean>{
    
    
    AndOp ( "/\\"){
        /**
         * Berekend de waarde van de BinOp.
         * @param Left de waarde links van de binaire operator.
         * @param Right de waarde rechts van de binaire operator.
         * @return de waarde van de binaire AND operator.
         */
        @Override
        public Boolean apply (Boolean Left, Boolean Right){
            return Left && Right;
        }
    },
    OrOp ("\\/"){
        /**
         * Berekend de waarde van de BinOp.
         * @param Left de waarde links van de binaire operator.
         * @param Right de waarde rechts van de binaire operator.
         * @return de waarde van de binaire OR operator.
         */
        @Override
        public Boolean apply (Boolean Left, Boolean Right){
            return Left || Right;
        }
    },
    ImpliesOp ("=>"){
        /**
         * Berekend de waarde van de BinOp.
         * @param Left de waarde links van de binaire operator.
         * @param Right de waarde rechts van de binaire operator.
         * @return de waarde van de binaire IMPLICATIE operator.
         */
        @Override
        public Boolean apply (Boolean Left, Boolean Right){
            return !Left || Right;
        }
    };
    
    private String string;
    
    /**
     * Maakt een sting aan voor de binaire operator.
     * @param string de meegegeven sting die aangemaakt moet worden voor de binaire operator.
     */
    private BinOp(String string) {
        this.string = string;
    }
    
    /**
     * Vraagt de sting van de binaire operator op.
     * @return de sting van de binaire operator.
     */
    public String getOperator() {
        return string;
    }
}
