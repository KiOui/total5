/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opgave.pkg10;

public interface FormVisitor <R>{
    
    
    /**
     * Voor constantes
     * @param form 
     * @return  
     */
    public R visit(ConstantForm form);
    
    /**
     * Voor binaire operatoren
     * @param form 
     * @return  
     */
    public R visit(BinOpForm form);
    
    /**
     * Voor een not-operator
     * @param form 
     * @return  
     */
    public R visit(NotForm form);
    
}
