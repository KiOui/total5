/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opgave.pkg10;

import java.util.HashMap;
import java.util.Map;

public class Opgave10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Map<String,Boolean> map = new HashMap();
        BinOpForm formule1 = new BinOpForm (BinOp.AndOp, ConstantForm.TrueForm, ConstantForm.TrueForm);
        BinOpForm formule2 = new BinOpForm (BinOp.ImpliesOp, ConstantForm.TrueForm, new BinOpForm(BinOp.AndOp, ConstantForm.TrueForm, ConstantForm.FalseForm));
        BinOpForm formule3 = new BinOpForm (BinOp.OrOp, ConstantForm.TrueForm, ConstantForm.FalseForm);
        BinOpForm formule4 = new BinOpForm (BinOp.AndOp, formule1, formule2);
        BinOpForm formule5 = new BinOpForm (BinOp.ImpliesOp, formule3, formule4);
        
        formule1.accept(new PrintFormVisitor());
        System.out.print (" is " + formule1.accept (new EvalFormVisitor(map)) + "\n");
        formule2.accept(new PrintFormVisitor());
        System.out.print (" is " + formule2.accept (new EvalFormVisitor(map)) + "\n");
        formule3.accept(new PrintFormVisitor());
        System.out.print (" is " + formule3.accept (new EvalFormVisitor(map)) + "\n");
        formule4.accept(new PrintFormVisitor());
        System.out.print (" is " + formule4.accept (new EvalFormVisitor(map)) + "\n");
        formule5.accept(new PrintFormVisitor());
        System.out.print (" is " + formule5.accept (new EvalFormVisitor(map)) + "\n");
    }
    
}
