/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opgave.pkg10;


public class PrintFormVisitor implements FormVisitor  {

    /**
     * Print een ConstantForm.
     * @param form de ConstantFrom die geprint moet worden.
     * @return null als er iets mis is (return normaal gesproken niks).
     */
    @Override
    public Void visit(ConstantForm form) {
        if (form == ConstantForm.TrueForm) {
            System.out.print("True");
        }
        else if (form == ConstantForm.FalseForm) {
            System.out.print("False");
        }
        return null;
    }

    /**
     * Print een BinOpForm.
     * @param form de BinOpForm die geprint moet worden.
     * @return null als er iets mis is (return normaal gesproken niks).
     */
    @Override
    public Void visit(BinOpForm form) {
        if (form.getLeft().getClass() == ConstantForm.TrueForm.getClass() || form.getLeft().getClass() == ConstantForm.FalseForm.getClass()) {
            form.getLeft().accept(this);
        }
        else if (form.getLeft().getClass() == BinOpForm.class){
            System.out.print("(");
            form.getLeft().accept(this);
            System.out.print(")");
        }
        else if (form.getLeft().getClass() == NotForm.class) {
            form.getLeft().accept(this);
        }
        else {
            System.out.print("?");
        }

        System.out.print(form.getOperator().getOperator());

        if (form.getRight().getClass() == ConstantForm.TrueForm.getClass() || form.getRight().getClass() == ConstantForm.FalseForm.getClass()) {
            form.getRight().accept(this);
        }
        else if (form.getRight().getClass() == BinOpForm.class){
            System.out.print("(");
            form.getRight().accept(this);
            System.out.print(")");
        }
        else if (form.getRight().getClass() == NotForm.class) {
            form.getRight().accept(this);
        }
        else {
            System.out.println("?");
        }
        return null;
    }

    /**
     * Print een NotForm.
     * @param form de NotForm die geprint moet worden.
     * @return null als er iets mis is (return normaal gesproken niks).
     */
    @Override
    public Void visit(NotForm form) {
        System.out.print("~");
        if (form.getOperand().getClass() == ConstantForm.class) {
            form.getOperand().accept(this);
        }
        else if (form.getOperand().getClass() == BinOpForm.class){
            System.out.print("(");
            form.getOperand().accept(this);
            System.out.print(")");
        }
        else if (form.getOperand().getClass() == NotForm.class) {
            form.getOperand().accept(this);
        }
        else {
            System.out.print("?");
        }
        return null;
    }

    
    
}
