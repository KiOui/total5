/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opgave.pkg10;

public enum ConstantForm implements Form {
    
    TrueForm {@Override
        /**
         * 
         */
        public <R> R accept(FormVisitor<R> v) {
            return v.visit(this);
        }
    },
    FalseForm {@Override
        /**
         * 
         */
        public <R> R accept(FormVisitor<R> v) {
            return v.visit(this);
        }
    };
    
}
