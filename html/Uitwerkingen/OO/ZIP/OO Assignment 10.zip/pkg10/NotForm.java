/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opgave.pkg10;

public class NotForm implements Form{
    
    private Form operand;
    
    /**
     * Maakt een NotForm aan.
     * @param oper de NotForm die is aangemaakt.
     */
    public NotForm(Form oper) {
        this.operand = oper;
    }
    
    /**
     * 
     * @return 
     */
    public Form getOperand() {
        return operand;
    }
    
    /**
     * 
     * @param <R>
     * @param v
     * @return 
     */
    @Override
    public <R> R accept(FormVisitor<R> v) {
        return v.visit(this);
    }
}
