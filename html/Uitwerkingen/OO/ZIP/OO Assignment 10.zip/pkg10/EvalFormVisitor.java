/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opgave.pkg10;

import java.util.Map;

public class EvalFormVisitor implements FormVisitor<Boolean>{
    public Map<String, Boolean> formule;
    
    /**
     * Maakt de EvalFormVisitor aan.
     * @param formule de formule waar een EvalFormVisitor voor aangemaakt wordt.
     */
    public EvalFormVisitor (Map<String, Boolean> formule){
        this.formule = formule;
    }
    
    /**
     * Kijkt of de waarde van de ConstantForm true of false is.
     * @param form de form waar de waarde voor gechecked moet worden.
     * @return de waarde van de ConstantForm form.
     */
    @Override
    public Boolean visit (ConstantForm form){
        if(form == ConstantForm.FalseForm)
            return false;
        if(form == ConstantForm.TrueForm)
            return true;
        else
            return null;
    }
    
    /**
     * Kijkt of de waarde van de BinOpForm true of false is.
     * @param form de form waar de waarde voor gechecked moet worden.
     * @return de waarde van de BinOpForm form.
     */
    @Override
    public Boolean visit (BinOpForm form){
        return form.getOperator().apply(form.getLeft().accept(this), form.getRight().accept(this));
    }
    
    /**
     * Kijkt of de waarde van de NotForm true of false is.
     * @param form de form waar de waarde voor gechecked moet worden.
     * @return de waarde van de NotForm form.
     */
    @Override
    public Boolean visit (NotForm form){
        return !form.getOperand().accept(this);
    }   
    
}
