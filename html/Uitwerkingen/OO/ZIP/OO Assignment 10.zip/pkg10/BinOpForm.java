/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opgave.pkg10;

public class BinOpForm implements Form {
    
    private BinOp op;
    private Form leftOp;
    private Form rightOp;
    
    /**
     * Maakt een binaire formule aan met een binaire operator en een waarde links en rechts van deze operator.
     * @param op de operator zelf.
     * @param left de waarde links van de operator.
     * @param right de waarde rechts van de operator.
     */
    public BinOpForm(BinOp op, Form left, Form right) {
        this.op = op;
        this.leftOp = left;
        this.rightOp= right;
    }
    
    /**
     * Geeft de waarde van wat links staat van de binaire operator.
     * @return de waarde links van de binaire operator.
     */
    public Form getLeft() {
        return leftOp;
    }
    
    /**
     * Geeft de waarde van wat rechts staat van de binaire operator.
     * @return de waarde rechts van de binaire operator.
     */
    public Form getRight() {
        return rightOp;
    }
    
    /**
     * Geeft de waarde van de binaire operator.
     * @return de waarde van de binaire operator.
     */
    public BinOp getOperator() {
        return op;
    }

    /**
     * 
     * @param <R>
     * @param v
     * @return 
     */
    @Override
    public <R> R accept(FormVisitor<R> v) {
        return v.visit(this);
    }
}
