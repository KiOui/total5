
import java.util.*;

/**
 * A class that implements a breadth-first search algorithm
 * for finding the Configurations for which the isSolution predicate holds
 * @author Pieter Koopman, Sjaak Smetsers
 * @version 1.5
 * @date 25-02-2017
 */
public class Solver
{
   // A queue for maintaining graphs that are not visited yet.
    PriorityQueue<Configuration> toExamine;

    /**
     * This creates a solver
     * @param g is the starting configuration of the puzzle
     */
    public Solver( Configuration g ) {
        toExamine = new PriorityQueue<>();
        toExamine.add(g);
    }

    /**
     * A skeleton implementation of the solver
     *
     * @return Succes if the puzzle has been solved, returns Failure otherwise
     */
    public String solve() {
        List<Configuration> bestSolution;
        HashSet data = new HashSet<>();
        while ( ! toExamine.isEmpty() ) {
            Configuration next = toExamine.remove();
            
            
            data.add(next);
            
            if ( next.isSolution() ) {
                bestSolution = next.pathFromRoot();
                for (Configuration dummy : bestSolution) {
                    System.out.println(dummy);
                }
                return "Success!";
            } 
            
            else {
                for ( Configuration succ : next.successors() ) {
                    if (!(data.contains(succ))) {
                        toExamine.add(succ);
                    }
                }
            }

        }
        return "Failure!";
    }
    
}
