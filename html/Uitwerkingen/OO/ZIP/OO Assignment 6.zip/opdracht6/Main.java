
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;


/**
 *
 * @author Sjaak Smetsers
 */
public class Main
{
    public static void main(String[] args) {
        //1,2,3,5,6,7,9,10
        int [] game = {4,3,5,8,1,9,6,2,7};

        SlidingGame s = new SlidingGame (game);
        System.out.println(s);
        Solver solver = new Solver(s);
        System.out.println(solver.solve());
        
        
    }
}
