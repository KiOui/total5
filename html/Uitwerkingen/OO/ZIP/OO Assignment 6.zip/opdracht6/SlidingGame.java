import static java.lang.Math.abs;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;


/**
 * @author Pieter Koopman, Sjaak Smetsers
 * @version 1.3
 * @date 07-03-2016
 * A template implementation of a sliding game 
 * implementing the Graph interface
 */
public class SlidingGame implements Configuration {

    public static final int N = 3, SIZE = N * N, HOLE = SIZE;
    /**
     * The board is represented by a 2-dimensional array; the position of the
     * hole is kept in 2 variables holeX and holeY
     */
    private final int[][] board;
    private int holeX, holeY;
    private final Configuration parent;
    private final int manhattan;
    

    /**
     * A constructor that initializes the board with the specified array
     *
     * @param start: a one dimensional array containing the initial board. The
     * elements of start are stored row-wise.
     * @param parent Previous configuration.
     */
    public SlidingGame(int[] start, Configuration parent) {
        this.parent = parent;

        
        board = new int[N][N];

        assert start.length == N * N : "Length of specified board incorrect";

        for (int p = 0; p < start.length; p++) {
            board[p % N][p / N] = start[p];
            
            if (start[p] == HOLE) {
                holeX = p % N;
                holeY = p / N;
            }
        }
        int manhattanDummy = 0;
        for (int i = 0; i < N; i++) {
            for (int o = 0; o < N; o++) {
                int xA = board[o][i] % N;
                int yA = board[o][i] / N;
                manhattanDummy += abs(o-xA) + abs(i-yA);
            }
        }
        this.manhattan = manhattanDummy;
    }
    
    /**
     * A constructor that initializes the board without the specified array
     * @param start: a one dimensional array containing the initial board. The elements of start are stored row-wise.
     */
    public SlidingGame(int[] start) {

        
        board = new int[N][N];

        assert start.length == N * N : "Length of specified board incorrect";

        for (int p = 0; p < start.length; p++) {
            board[p % N][p / N] = start[p];
            if (start[p] == HOLE) {
                holeX = p % N;
                holeY = p / N;
            }
        }
        this.parent = this;
        int manhattanDummy = 0;
        for (int i = 1; i < N*N; i++) {
            int x = 0;
            int y = 0;
            int xA = i % N;
            int yA = i/N;
            for (int o = 0; o < N; o++) {
                for (int r = 0; r < N; r++) {
                    if (board[r][o] == i) {
                        x = r;
                        y = o;
                    }
                }
            }
            manhattanDummy += abs(x-xA) + abs(y-yA);
        }
        this.manhattan = manhattanDummy;
    }

    /**
     * Converts a board into a printable representation. The hole is displayed
     * as a space
     *
     * @return the string representation
     */
    @Override
    public String toString() {
        StringBuilder buf = new StringBuilder();
        for (int row = 0; row < N; row++) {
            for (int col = 0; col < N; col++) {
                int puzzel = board[col][row];
                buf.append(puzzel == HOLE ? "  " : puzzel + " ");
            }
            buf.append("\n");
        }
        return buf.toString();
    }

    /**
     * This function checks if two states of the puzzle are the same.
     * @param g this is the given state of the puzzle that needs to be compared.
     * @return true if the object is equal to this object
     */
    @Override
    public boolean equals(Object g) {
        assert(g.getClass() == SlidingGame.class);
        
        SlidingGame compare = (SlidingGame) g;
        for(int i = 0; i < N; i++) {
            for (int o = 0; o < N; o++) {
                if (!(this.board[i][o] == compare.getBoard()[i][o])) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * The function checks if a certain state of the puzzle is a solution.
     * @return true if the certain state is a solution and false if its not a solution.
     */
    @Override
    public boolean isSolution() {
        int counter = 1;
        for (int i = 0; i < N; i++) {
            for (int o = 0; o < N;o++) {
                if ((!(board[o][i] == counter)) && counter != HOLE) {
                    return false;
                }
                counter++;
            }
        }
        return true;
    }

    /**
     * This function calculates the successors of the current state of the puzzle.
     * @return a list of successors of the current state of the puzzle.
     */
    @Override
    public Collection<Configuration> successors() {
        List<Configuration> nextGen = new LinkedList<>();
        
        if(holeX != 0) {
            nextGen.add(new SlidingGame(getArray(Direction.WEST),this));
        }
        if(holeX != N-1) {
            nextGen.add(new SlidingGame(getArray(Direction.EAST),this));
        }
        if(holeY != 0) {
            nextGen.add(new SlidingGame(getArray(Direction.NORTH),this));
        }
        if(holeY != N-1) {
            nextGen.add(new SlidingGame(getArray(Direction.SOUTH),this));
        }
        
        return nextGen;
    }

    /**
     * This function compares a given state of the puzzle 
     * @param g this is the given state of the puzzle that needs to be compared
     * @return the difference between the manhattan distances
     */
    @Override
    public int compareTo(Configuration g) {
        return this.manhattan-g.getManhattan();
    }
 
    /**
     * This function returns the parent of the current board.
     * @return the parent of the current board.
     */
    @Override
    public Configuration parent() {
        return parent;
    }
    
    /**
     * This will make a new array for creating a new slidingpuzzle (with a given direction)
     * @param dir the direction in witch the hole must move
     * @return the array for creating a new slidingpuzzle with the given direction
     */
    private int[] getArray(Direction dir) {
        int[][] newBoard = new int[N][N];
        int[] newArray = new int[N*N];
        
        //copy board to newBoard
        for(int i = 0;i < N;i++) {
            for(int o = 0;o < N; o++) {
                newBoard[o][i] = board[o][i];
            }
        }

        //configure new board
        int dummy = newBoard[holeX+dir.GetDX()][holeY+dir.GetDY()];
        newBoard[holeX][holeY] = dummy;
        newBoard[holeX+dir.GetDX()][holeY+dir.GetDY()] = HOLE;
        
        //copy new board to array
        int counter = 0;
        for (int i = 0; i < N; i++) {
            for (int o = 0; o < N; o++) {
                newArray[counter] = newBoard[o][i];
                counter++;
            }
        }
        return newArray;
    }
    
    /**
     * This function returns the current board.
     * @return the current board
     */
    public int[][] getBoard() {
        return board;
    }
    
    /**
     * this function returns a hashcode for this puzzle
     * @return a hashcode
     */
    @Override
    public int hashCode() {
        int hashwaarde = 0;
        
        for (int y = 0; y < N; y++) {
            for (int x = 0; x < N; x++) {
                hashwaarde += board[x][y] * (31 ^ (x+(y*N)));
            }
        }
        return hashwaarde;
    }
    
    /**
     * this function returns the manhattan distance for this puzzle
     * @return manhattan
     */
    public int getManhattan() {
        return manhattan;
    }
}
