/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oo17taxi;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ThreadSimulation {
    
    private final int MAX_TRAIN_RIDES = 10;
    private final int MIN_TAXI_SPACE = 4;
    private final int MAX_TAXI_SPACE = 7;
    private final int AMOUNT_OF_TAXIS = 4;
    
    //Transport time in milliseconds
    private final int MIN_TRANSPORT_TIME = 1000;
    private final int MAX_TRANSPORT_TIME = 3000;
    
    public static final int MIN_TRAIN_SIZE = 60;
    public static final int MAX_TRAIN_SIZE = 80;
    
    //Sleeptime in milliseconds
    public static final int SLEEPTIME = 2000;
    
    private final Station station;
    private final Taxi[] taxis;
    private final Train train;
    
    /**
     * Creates a new Simulation with multithreading
     */
    public ThreadSimulation() {
        System.out.println("Starting simulation...");
        this.station = new Station();
        this.train = new Train(this.station, MAX_TRAIN_RIDES);
        this.taxis = new Taxi[AMOUNT_OF_TAXIS];
        for (int i = 0; i < AMOUNT_OF_TAXIS; i++) {
            this.taxis[i] = new Taxi(i+1, Util.getRandomNumber(MIN_TAXI_SPACE, MAX_TAXI_SPACE), Util.getRandomNumber(MIN_TRANSPORT_TIME, MAX_TRANSPORT_TIME), this.station);
        }
        System.out.println("Simulation created with " + AMOUNT_OF_TAXIS + " taxis.");
    }
    
    /**
     * Runs the simulation by making an ExecutorService and
     * firstly putting in a TrainRunner, after the TrainRunner
     * it executes a TaxiRunner for all created taxis. It then checks 
     * wheter the station is closed with a sleep time between those checks
     * of SLEEPTIME. After the execution this function will call
     * showStatistics for showing the statistics about this run.
     */
    public void run() {
        systemInfo();
        
        long startTime = System.currentTimeMillis();
        ExecutorService execute = Executors.newCachedThreadPool();
        
        execute.execute(new TrainRunner(train));
        for (int i = 0; i < AMOUNT_OF_TAXIS; i++) {
            execute.execute(new TaxiRunner(taxis[i], this));
        }
        
        while (!(station.isClosed())) {
            try {
                TimeUnit.MILLISECONDS.sleep(SLEEPTIME);
            } catch (InterruptedException ex) {
                System.out.println("Failed to sleep 2 seconds!");
            }
        }
        
        execute.shutdown();
        System.out.println("Simulation stopped!");
        long stopTime = System.currentTimeMillis();
        showStatistics(startTime, stopTime);
        
    }
    
    /**
     * This function makes sure that only one taxi takes passengers from the station at a time
     * @param taxi the current taxi
     */
    public synchronized void executeOneRun(Taxi taxi) {
        taxi.takePassengers();
    }
    
    /**
     * Shows statistics about this run
     * @param startTime the start time of the simulation (in millis)
     * @param stopTime the stop time of the simulation (in millis)
     */
    private void showStatistics(long startTime, long stopTime) {
        System.out.println("All persons have been transported");
        System.out.println("Total transport time in this simulation: " + calcTotalTime(taxis) + " (+/-" + calcTotalTime(taxis)/1000 + " seconds)");
        System.out.println("Total number of train travelers: " + station.getTotalNrOfPassengers());
        System.out.println("Total number of persons transported in this simulation: " + calcTotalNrOfPassengers(taxis));
        System.out.println("REAL TIME: This simulation took: +/-" + (stopTime-startTime)/1000 + " seconds.");
    }
    
    /**
     * Shows the amount of cores that this system is using
     */
    private void systemInfo() {
        System.out.println("This system uses: " + Runtime.getRuntime().availableProcessors() + "cores.");
    }

    /**
     * Calculates the total time of the simulation by looping over all taxis
     *
     * @param taxis
     * @return total time
     */
    private static int calcTotalTime(Taxi[] taxis) {
        int time = 0;
        for (Taxi taxi : taxis) {
          time += taxi.calcTotalTime();
        }
        return time;
      }
  
    /**
     * Calculates the total number of passengers that has been transported by
     * looping over all taxis
     *
     * @param taxis
     * @return total number of passengers
     */
    private static int calcTotalNrOfPassengers(Taxi[] taxis) {
      int total = 0;
      for (Taxi taxi : taxis) {
        total += taxi.getTotalNrOfPassengers();
      }
      return total;
    }
}
