/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oo17taxi;

import java.util.concurrent.TimeUnit;

public class TrainRunner implements Runnable {
    private final Train train;
    
    /**
     * Creates a new TrainRunner
     * @param train Train
     */
    public TrainRunner(Train train) {
        this.train = train;
    }
    
    /**
     * Runs this TrainRunner by checking wether the station is closed
     * or the station is empty and responding.
     */
    @Override
    public void run() {
        while (!(train.getStation().isClosed())) {
            try {
                if (train.getStation().waitingPassengers() == 0) {
                    if (train.getNrOfTrips() == train.getMaxNumberOfTrips()) {
                        train.getStation().close();
                    }
                    else {
                        train.loadPassengers(Util.getRandomNumber(ThreadSimulation.MIN_TRAIN_SIZE, ThreadSimulation.MAX_TRAIN_SIZE));
                        train.unloadPassengers();
                    }
                }
                
                TimeUnit.MILLISECONDS.sleep(ThreadSimulation.SLEEPTIME);
            } catch (InterruptedException ex) {
                System.out.println("Failed to sleep 2 seconds!");
            }
        }
    }
}
