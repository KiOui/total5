
package oo17taxi;

public class OO17Taxi {

  public static void main(String[] args) {
    ThreadSimulation sim = new ThreadSimulation();
    sim.run();
    System.out.println("Program stopped.");
  }
}
