/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oo17taxi;

public class TaxiRunner implements Runnable {
    private final Taxi taxi;
    private final ThreadSimulation threadHost;
    
    /**
     * Creates a new TaxiRunner
     * @param taxi Taxi
     * @param threadHost The ThreadSimulation that is running this taxi 
     */
    public TaxiRunner(Taxi taxi, ThreadSimulation threadHost) {
        this.threadHost = threadHost;
        this.taxi = taxi;
    }
    
    /**
     * Runs the taxi
     */
    @Override
    public void run() {
        while (!(taxi.getStation().isClosed())) {
            threadHost.executeOneRun(this.taxi);
            taxi.bringPassengers();
        }
    }
    
}
