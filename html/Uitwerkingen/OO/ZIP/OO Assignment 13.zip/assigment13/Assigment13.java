/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assigment13;

import java.io.IOException;
//import java.util.Arrays;
import java.util.Random;

public class Assigment13 {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        
        Random rand = new Random();
        
        FileFinderSeq file = new FileFinderSeq("C:\\");
        file.findFile("autoweg.png");
        
        int intArray[] = new int[10000000];
        for (int i = 0; i < intArray.length; i++) {
            intArray[i] = rand.nextInt(10000000);
        }
        
        /**
        int [] firstHalf = Arrays.copyOf(intArray, intArray.length / 2);
        int [] secondHalf = Arrays.copyOfRange(intArray, intArray.length / 2, intArray.length);

        ThreadSort sort1 = new ThreadSort(firstHalf);
        ThreadSort sort2 = new ThreadSort(secondHalf);
        
        Thread thread1 = new Thread(sort1);
        Thread thread2 = new Thread(sort2);
        
        */
        System.out.println("Starting sort algorithm with " + Runtime.getRuntime().availableProcessors() + " cores.");
        long startTime = System.currentTimeMillis();
        /**
        thread1.start();
        thread2.start();
        try {
            thread1.join();
            thread2.join();
        }
        catch (InterruptedException ex) {
        }
        
        MergeSort.merge(firstHalf, secondHalf, intArray);
        */
        MergeSort.sort(intArray);
        long stopTime = System.currentTimeMillis();
        System.out.println("Stopping algorithm at: " + (stopTime-startTime));
        System.out.println(MergeSort.isSorted(intArray));
        
        //Voor multithreading:
        //Gemiddeld: 2000 ms
        //Cores: 2
        
        //Na multithreading:
        //Gemiddeld: 5000 ms
        //Cores: 2
        
        /**
         * We vinden het raar dat de snelheid bij het multithreading afneemt, we hebben echter alles geprobeerd om de multithreading sneller te maken,
         * nu staat er in de MergeSort een check of het aantal actieve threads hoger is dan het aantal cores want dan is het toch nutteloos om een nieuwe thread
         * aan te maken.
         * 
         * Na een test met een grotere array blijkt de multithreading variant wel sneller.
         */
        
        /*
        for (int i = 0; i < intArray.length; i++) {
            System.out.println(intArray[i]);
        }
        */
        
    }
    
}
