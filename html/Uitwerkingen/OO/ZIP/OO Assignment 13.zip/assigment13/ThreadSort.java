/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assigment13;

public class ThreadSort implements Runnable{
    
    private final int array[];
    
    public ThreadSort(int array[]) {
        this.array = array;
    }
    
    @Override
    public void run() {
        MergeSort.sort(array);
    }
    
}
