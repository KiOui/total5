/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assigment13;


import java.io.File;
import java.io.IOException;

public class FileFinderSeq {
    private final File rootDir;
    
    public FileFinderSeq(String root) throws IOException {
        rootDir = new File(root);
        if (!(rootDir.exists() && rootDir.isDirectory())) {
            throw new IOException(root + " is not a directory");
        }
    }
    
    public FileFinderSeq(File rootDir) {
        this.rootDir = rootDir;
    }
    
    public void findFile(String file) {
        find(rootDir, file);
    }
    
    private void find (File rootDir, String fileName) {
        File [] files = rootDir.listFiles();
        if (files != null) {
            for (File file: files) {
                if (file.getName().equals(fileName)) {
                    System.out.println("Found at: " + file.getAbsolutePath());
                } 
                else if (file.isDirectory()) {
                    //System.out.println("Thread for file: " + file);
                    FileFinderSeq newFileFinder = new FileFinderSeq(file);
                    ThreadStart newThread = new ThreadStart(newFileFinder, fileName);
                    Thread thread = new Thread(newThread);
                    thread.start();
                }
            }
        }
    }
    
    @Override
    public String toString() {
        return rootDir + "";
    }
}
