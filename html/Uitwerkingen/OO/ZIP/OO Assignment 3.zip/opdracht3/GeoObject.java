/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opdracht3;

interface GeoObject {
    
    /*
    * @return x positie van de linker zijkant
    */
    public double leftBorder();
    
    
    /*
    * @return x positie van de rechter zijkant
    */
    public double rightBorder();
    
    /*
    * @return y positie van de bovenkant
    */
    public double topBorder();
    
    /*
    * @return y positie van de onderkant
    */
    public double bottomBorder();
    
    /*
    * @return oppervlakte van het object
    */
    public double area();
    
    /*
    * Verplaatst het object dx op de x-as en dy op de y-as
    * @param dx = hoeveelheid verplaatsing x-as, dy = hoeveelheid verplaatsing y-as
    */
    public void move(double dx, double dy);
    
    /*
    * @return x positie van het object
    */
    public double xAs();
    
    /*
    * @return y positie van het object
    */
    public double yAs();
    
    /*
    * @return de variabelen van dit object in een String
    */
    @Override
    public String toString();
    
    /*
    * @param object om mee te vergelijken
    * @return   -1 als het object o kleiner is dan dit object
    *           0 als het object o even groot is als dit object
    *           1 als het object o groter is dan dit object
    */
    public int compareTo(GeoObject o);
    
    /*
    * @param o = object om mee te vergelijken, sortMeth = sorteer methode (op x of y as)
    * @return   -1 als het object o kleiner is dan dit object
    *           0 als het object o even groot is als dit object
    *           1 als het object o groter is dan dit object
    */
    public int compareTo(GeoObject o, Database.sortID sortMeth);
}
