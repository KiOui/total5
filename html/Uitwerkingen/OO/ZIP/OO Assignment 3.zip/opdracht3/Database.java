/*
 * Database klasse om alle objecten in op te slaan
 */
package opdracht3;

import java.util.Arrays;
import java.util.Comparator;



public class Database {
    
    public enum sortID{xA, yA}; //xAs, yAs of Area
    private GeoObject[] Data;
    private final int maxSize;
    private int next;
    
    /*
    * Maakt een nieuwe database aan
    * @param i = grootte database
    */
    public Database(int i) {
        this.maxSize = i;
        this.next = 0;
        this.Data = new GeoObject[maxSize];
    }
    
    /*
    * Voegd een cirkel toe aan de Database
    * @param x = positie x-as, y = positie y-as, r = radius
    * @return true als het aanmaken gelukt is
    */
    public boolean addCircle(double x, double y, double r) {
        if (isFull()) {
            Circle dummy = new Circle(x, y, r);
            Data[next] = dummy;
            next++;
            show();
            return true;
        }
        else {
            System.out.println("De array is vol, verwijder objecten voordat nieuwe objecten worden aangemaakt.");
            return false;
        }
        
    }
    
    /*
    * Voegd een rechthoek toe aan de Database
    * @param x = positie x-as, y = positie y-as, w = breedte, h = hoogte
    * @return true als het aanmaken gelukt is
    */
    public boolean addRectangle(double x, double y, double w, double h) {
        if (isFull()) {
            Rectangle dummy = new Rectangle(x, y, w, h);
            Data[next] = dummy;
            next++;
            show();
            return true;
        }
        else {
            System.out.println("De array is vol, verwijder objecten voordat nieuwe objecten worden aangemaakt.");
            return false;
        }
    }
    
    /*
    * Verplaatst een object in de Database
    * @param i = element ID in de Database, dx = hoeveelheid verplaatsing x-as, dy = hoeveelheid verplaatsing y-as
    * @return true als het verplaatsen gelukt is
    */
    public boolean move(int i, double dx, double dy) {
        if (i <= next && i > 0) {
            Data[i-1].move(dx, dy);
            show();
            return true;
        }
        else {
            System.out.println("De parameter valt buiten de range van de array, gebruik een getal tussen 0 en " + next + ".");
            return false;
        }
    }
    
    /*
    * Verwijderd een element uit de Database
    * @param i = element ID in de array
    * @return true als het verwijderen gelukt is
    */
    public boolean remove(int i) {
        if (i <= next && i > 0) {
            for (int o = i-1; o < next-1; o++) {
                Data[o] = Data[o+1];
            }
            next--;
            show();
            return true;
        }
        else {
            System.out.println("De parameter valt buiten de range van de array, gebruik een getal tussen 0 en " + next + ".");
            return false;
        }
    }
    
    /*
    * Laat alle objecten in de Database array naar de console toe schrijven
    * @return true
    */
    public boolean show() {
        for(int i = 0; i < next; i++) {
            System.out.println((i+1) + ": " + Data[i].toString());
        }
        return true;
    }
    
    /*
    * Sorteerd de Database
    * @param a = hoe de database gesorteerd moet worden, 
    *           als a = 'a' dan wordt de Database op area-grootte van de objecten gesorteerd
    *           als a = 'x' dan wordt de Database op x-as van de objecten gesorteerd
    *           als a = 'y' dan wordt de Database op y-as van de objecten gesorteerd
    * @return true als het sorteren gelukt is
    */
    public boolean sorteer(char a) {
        switch (a) {
            case 'a':
                Arrays.sort(Data, 0, next, new Comparator<GeoObject>() {
                    @Override
                    public int compare(GeoObject o1, GeoObject o2) {
                        return o1.compareTo(o2);
                    }
                });
                return show();
            case 'x':
                Arrays.sort(Data, 0, next, new Comparator<GeoObject>() {
                    @Override
                    public int compare(GeoObject o1, GeoObject o2) {
                        return o1.compareTo(o2, Database.sortID.xA);
                    }
                });
                return show();
            case 'y':
                Arrays.sort(Data, 0, next, new Comparator<GeoObject>() {
                    @Override
                    public int compare(GeoObject o1, GeoObject o2) {
                        return o1.compareTo(o2, Database.sortID.yA);
                    }
                });
                return show();
            default:
                System.out.println("Sorteren mislukt omdat de parameter geen bekende parameter is, gebruik: x, y of geen parameter.");
                return false;
        }
    }
    
    
    /*
    * @return true als de Array nog niet vol is
    */
    private boolean isFull() {
        return next < maxSize;
    }
}
