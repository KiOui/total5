/*
 * Deze klasse decodeerd alle ingevoerde data tot commando's en voert die commando's uit.
 */
package opdracht3;

public class commandLineInput {
    
    public enum commandID{quit, show, circle, rectangle, move, remove, sort};    
    private final String lineInput;
    private commandID identificator;
    private String[] splited;
    
    /*
    * Constructor neemt de ingevoerde line als input
    * @param de ingevoerde zin
    */
    public commandLineInput(String line) {
        this.lineInput = line;
    }
    
    /*
    * Verwerkt de ingevoerde string tot commando en roept de database aan om eventueel het commando te verwerken.
    * @param de database waarin alle objecten moeten worden opgeslagen.
    * @return true als het commando goed gedecodeerd is
    */
    public boolean decode(Database Data) {
        splited = lineInput.split("\\s+");
        if (command()) {
            if (identificator == commandID.circle && splited.length > 3) {
                double x = Double.parseDouble(splited[1]);
                double y = Double.parseDouble(splited[2]);
                double r = Double.parseDouble(splited[3]);
                return Data.addCircle(x, y, r);
            }
            else if (identificator == commandID.rectangle && splited.length > 4) {
                double x = Double.parseDouble(splited[1]);
                double y = Double.parseDouble(splited[2]);
                double w = Double.parseDouble(splited[3]);
                double h = Double.parseDouble(splited[4]);
                return Data.addRectangle(x, y, w, h);
            }
            else if (identificator == commandID.move && splited.length > 3) {
                int i = Integer.parseInt(splited[1]);
                double dx = Double.parseDouble(splited[2]);
                double dy = Double.parseDouble(splited[3]);
                return Data.move(i, dx, dy);
            }
            else if (identificator == commandID.remove && splited.length > 1) {
                int i = Integer.parseInt(splited[1]);
                return Data.remove(i);
            }
            else if (identificator == commandID.sort && splited.length > 0) {
                char sortC;
                if (splited.length >= 2) {
                    sortC = splited[1].charAt(0);
                }
                else {
                    sortC = 'a';
                }
                return Data.sorteer(sortC);
            }
            else if (identificator == commandID.show) {
                return Data.show();
            }
            else if (identificator == commandID.quit) {
                return true;
            }
        }
        System.out.println("Commando wordt niet herkend of te weinig parameters.");
        return false;
    }
    
    /*
    * Decodeerd het eerste gedeelte van het commando om te identificeren om welk commando het gaat en zet de identificator naar het juiste commando
    * @return true als het eerste ingevoerde woord een juist commando is
    */
    
    private boolean command() {
        if (splited.length <= 0) {
            return false;
        } 
        else {
            switch(splited[0]) {
                case "quit":
                    identificator = commandID.quit;
                    return true;
                case "show":
                    identificator = commandID.show;
                    return true;
                case "circle":
                    identificator = commandID.circle;
                    return true;
                case "rectangle":
                    identificator = commandID.rectangle;
                    return true;
                case "move":
                    identificator = commandID.move;
                    return true;
                case "remove":
                    identificator = commandID.remove;
                    return true;
                case "sort":
                    identificator = commandID.sort;
                    return true;
                default:
                    return false;
            }
        }
    }
    
    /*
    * @return true als het quit commando is gegeven
    */
    public boolean getQuit() {
        return identificator == commandID.quit;
    }
}
