/*
 * De circle klasse
 */
package opdracht3;

public class Circle implements GeoObject, Comparable{
    private double x;
    private double y;
    private final double r;
    
    /*
    * Maakt een circle aan
    * @param x = positie x-as, y = positie y-as, r = radius
    */
    public Circle(double x, double y, double r) {
        this.x = x;
        this.y = y;
        this.r = r;
    }
    
    //Voor Javadoc, zie GeoObject.java
    @Override
    public double leftBorder() {
        return x-r;
    }
    
    @Override
    public double rightBorder() {
        return x+r;
    }
    
    @Override
    public double topBorder() {
        return y+r;
    }
    
    @Override
    public double bottomBorder() {
        return y-r;
    }
    
    @Override
    public double area() {
        return Math.PI*r*r;
    }
    
    @Override
    public void move(double dx, double dy) {
        x = x + dx;
        y = y + dy;
    }
    
    @Override
    public double xAs() {
        return x;
    }
    
    @Override
    public double yAs() {
        return y;
    }
    
    @Override
    public String toString() {
        return "Circle at x = " + x + " and y = " + y + " with radius = " + r + ".";
    }
    
    public int compareTo(GeoObject o) {
        double Area = Math.PI * r * r;
        if (Area == o.area()) {
            return 0;
        }
        else if (Area < o.area()) {
            return -1;
        }
        else {
            return 1;
        }
    }

    public int compareTo(GeoObject o, Database.sortID sortMeth) {
        if (sortMeth == Database.sortID.xA) {
            if (x == o.xAs()) {
                return 0;
            }
            else if (x < o.xAs()) {
                return -1;
            }
            else {
                return 1;
            }
        }
        else {
            if (y == o.yAs()) {
                return 0;
            }
            else if (y < o.yAs()) {
                return -1;
            }
            else {
                return 1;
            }
        }
    }

    @Override
    public int compareTo(Object o) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
   
}

