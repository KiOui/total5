/*
 * De rectangle klasse
 */
package opdracht3;

public class Rectangle implements GeoObject, Comparable{
    private double x;
    private double y;
    private final double h;
    private final double w;
    
    /*
    * Maakt een rectangle aan
    * @param positie x-as, positie y-as, breedte, lengte
    */
    public Rectangle(double x, double y, double w, double h) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    }
    
    
    //Voor Javadoc, zie GeoObject.java
    @Override
    public double leftBorder() {
        return x;
    }
    
    @Override
    public double rightBorder() {
        return x+w;
    }
    
    @Override
    public double topBorder() {
        return y+h;
    }
    
    @Override
    public double bottomBorder() {
        return y;
    }
    
    @Override
    public double area() {
        return w*h;
    }
    
    @Override
    public void move(double dx, double dy) {
        x = x+dx;
        y = y+dy;
    }
    
    @Override
    public double xAs() {
        return x;
    }
    
    @Override
    public double yAs() {
        return y;
    }
    
    @Override
    public String toString() {
        return "Rectangle at x = " + x + " and y = " + y + " with width = " + w + " and height = " + h + ".";
    }

    public int compareTo(GeoObject o) {
        double Area = w * h;
        if (Area == o.area()) {
            return 0;
        }
        else if (Area < o.area()) {
            return -1;
        }
        else {
            return 1;
        }
    }

    public int compareTo(GeoObject o, Database.sortID sortMeth) {
        if (sortMeth == Database.sortID.xA) {
            if (x == o.xAs()) {
                return 0;
            }
            else if (x < o.xAs()) {
                return -1;
            }
            else {
                return 1;
            }
        }
        else {
            if (y == o.yAs()) {
                return 0;
            }
            else if (y < o.yAs()) {
                return -1;
            }
            else {
                return 1;
            }
        }
    }

    @Override
    public int compareTo(Object o) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
