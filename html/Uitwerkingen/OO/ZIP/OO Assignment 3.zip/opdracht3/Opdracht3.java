/*
 * De main klasse voor deze opdracht. Deze klasse vraagt om een grootte voor de Array waarin alle objecten worden opgeslagen en start daarna de User Interface.
 */
package opdracht3;

import java.util.Scanner;

public class Opdracht3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Grootte voor de array wordt hier bepaald:
        Scanner scanner = new Scanner(System.in);
        System.out.println("Geef een grootte voor de array in: ");
        int i = scanner.nextInt();
        //
        Database World = new Database(i);
        UI mainUI = new UI(World);
        System.out.println("Teminated");
    }
    
}
