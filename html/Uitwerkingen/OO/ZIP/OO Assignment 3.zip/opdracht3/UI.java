/*
 * Deze klasse verwerkt alle input van het programma.
 */
package opdracht3;

import java.util.Scanner;

public class UI {
    
    /*
    * Deze method verwerkt alle input en stopt als het commando "quit" wordt ingegeven.
    * @param Data de database waar alle objecten in moeten worden opgeslagen
    */
    public UI(Database Data) {
        Scanner scanner = new Scanner(System.in);
        boolean cont = true;
        //input loop:
        while (cont) {
            System.out.print(">>> ");
            commandLineInput nextCommand = new commandLineInput(scanner.nextLine());
            if (nextCommand.decode(Data)) {
                cont = !(nextCommand.getQuit());
            }
        }
    }
}
