/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opdracht1;

import java.util.Scanner;
public class Opdracht1 {


    static Groep group;
    /**
     * Hoofdklasse om een groep aan te maken en studenten toe te voegen.
     * @param args
     */
    private static void printGroep() {
        //Print de string "De groep bevat nu:" en de gehele meegegeven groep naar de console.
        System.out.println("De groep bevat nu:\n" + group.toString());
    }
    
    
    public static void main(String[] args) {
        System.out.println("Hoe groot moet de groep worden? ");
        Scanner scanner = new Scanner (System.in);
        int grootte = scanner.nextInt();
        String help = scanner.nextLine();
        group = new Groep(grootte);
        for (int i = 0;i < grootte; i++) {
            System.out.println("Voer een voornaam in: ");
            String voor = scanner.nextLine();
            System.out.println("Voer een achternaam in: ");
            String achter = scanner.nextLine();
            System.out.println("Voer een studentnummer in: ");
            int nummer = scanner.nextInt();
            help = scanner.nextLine();
            Student student = new Student(voor, achter, nummer);
            group.voegToe(student);
        }
        int lidnummer = 0;
        printGroep();
        while(lidnummer >=0) {
            System.out.println("Geef lidnummer op:");
            lidnummer = scanner.nextInt();
            help = scanner.nextLine();
            if (lidnummer > 0 && lidnummer <= grootte) {
                System.out.println("Geef nieuwe voornaam op:");
                String voor = scanner.nextLine();
                System.out.println("Geef nieuwe achternaam op:");
                String achter = scanner.nextLine();
                group.getStudent(lidnummer).setNaam(voor, achter);
                printGroep();
            }
            else if (lidnummer > grootte) {
                System.out.println("Lidnummer is te groot!");
            }
        }
        
    }
    
    
}
