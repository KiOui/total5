/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opdracht1;

public class Groep {
    //Deze klasse bevat een array met studenten van grootte.
    private int grootte;
    private int laatste = 0;
    private Student[] studenten;
    
    public Groep(int aantal) {
        this.studenten = new Student [aantal];
        this.grootte = aantal;
    }
    
    public boolean voegToe (Student s) {
        //Voegd student s toe aan de array studenten als de array nog niet vol is, returnd true als dat gelukt is, anders false.
        if (laatste < grootte) {
            studenten[laatste] = s;
            laatste++;
            return true;
        }
        else {
            return false;
        }
    }
    
    public Student getStudent(int i) {
        //Returnd student die op plek i-1 staat in de array studenten
        if (i > 0 && i <= laatste) {
            return studenten[i-1];
        }
        else {
            return null;
        }
    }
    
    @Override
    public String toString() {
        //Returnd alle studenten in de array studenten als een string met newlines tussen alle studenten.
        String total = "";
        for (int i = 0; i < laatste; i++) {
            total += studenten[i].toString() + '\n';
        }
        return total;
    }
}
