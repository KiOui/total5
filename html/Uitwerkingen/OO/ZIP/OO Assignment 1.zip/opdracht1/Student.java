/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opdracht1;

public class Student {
    //De klasse student heeft een voornaam, achternaam en studentnummer
    private String voornaam;
    private String achternaam;
    private int studentnummer;
    
    public Student (String voor, String achter, int nummer) {
        this.voornaam = voor;
        this.achternaam = achter;
        this.studentnummer = nummer;
    }
    
    @Override
    public String toString() {
        //Returnd de voornaam, achternaam en studentnummer met een spatie er tussen als een string.
        return voornaam + " " + achternaam + " s" + studentnummer;
    }
    
    public void setNaam(String voor, String achter) {
        //Deze methode veranderd de voor en achternaam
        this.voornaam = voor;
        this.achternaam = achter;
    }
}
