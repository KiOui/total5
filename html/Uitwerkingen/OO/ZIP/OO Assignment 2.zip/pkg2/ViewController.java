/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opdracht.pkg2;

import java.util.Scanner;


public class ViewController {
    
    private Galg currentGalg;
    private Scanner scanner;
    
    /**
     * Constructor voor ViewController
     * @param galg de galg om deze game mee te starten
     */
    public ViewController(Galg galg) {
        this.currentGalg = galg;
        this.scanner = new Scanner(System.in);
    }
    
    /**
     * Veranderd de huidige galg
     * @param woord het woord voor de nieuwe game
     */
    public void newGalg(String woord) {
        this.currentGalg = new Galg(woord);
    }
    
    /**
     * Veranderd de huidige galg
     */
    public void newGalg() {
        this.currentGalg = new Galg();
    }
    
    /**
     * Executeerd de viewcontroller
     */
    public void exec() {
        while (currentGalg.stillLiving() && !currentGalg.totalGuessed()) {
            System.out.println("Lives left: " + currentGalg.getLivesLeft());
            System.out.println("Word left: " + currentGalg.showGuessed());
            System.out.println("Please enter a new character: ");
            String line = scanner.nextLine();
            if (line.length() != 0) {
                if (currentGalg.inWord(line.charAt(0))) {
                    currentGalg.execGuess(line.charAt(0));
                }
                else {
                    currentGalg.removeLife();
                }
            }
        }
        if (currentGalg.totalGuessed()) {
            System.out.println("You've won! Congratulations!");
            System.out.println("Word: " + currentGalg.getWoord());
        }
        else {
            System.out.println("Such a shame...");
            System.out.println("Word: " + currentGalg.getWoord());
        }
    }
}
