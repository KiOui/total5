/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opdracht.pkg2;

import java.util.Scanner;


public class Opdracht2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a word or leave blank for a random one: ");
        String line = scanner.nextLine();
        Galg galg;
        if (line.equals("")) {
            galg = new Galg();
        }
        else {
            galg = new Galg(line);
        }
        ViewController c = new ViewController(galg);
        c.exec();
    }
    
}
