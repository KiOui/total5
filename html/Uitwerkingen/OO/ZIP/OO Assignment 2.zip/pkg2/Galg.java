/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opdracht.pkg2;


public class Galg {
    
    public final String TEXTBESTAND = "words.txt";
    public final int STARTLIVES = 8;
    
    private final String toGuess;
    private int lives;
    private final StringBuilder str;
    
    /**
     * Constructor voor galg
     * @param woord het te raden woord
     */
    public Galg(String woord) {
        this.toGuess = woord;
        this.str = new StringBuilder();
        for (int i = 0; i < woord.length(); i++) {
            str.append('.');
        }
        
        this.lives = STARTLIVES;
    }
    
    /**
     * Constructor voor galg, genereerd een random woord met de wordreader klasse
     */
    public Galg() {
        WordReader temp = new WordReader(TEXTBESTAND);
        String woord = temp.getWord();
        this.toGuess = woord;
        this.str = new StringBuilder();
        for (int i = 0; i < woord.length(); i++) {
            str.append('.');
        }
        
        this.lives = STARTLIVES;
    }
    
    /**
     * Checkt of een karakter in het te raden woord zit
     * @param a het karakter om te checken
     * @return true als de karakter in het woord zit
     */
    public boolean inWord(char a) {
        for (int i = 0; i < toGuess.length(); i++) {
            if (toGuess.charAt(i) == a) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Removes a life
     */
    public void removeLife() {
        this.lives--;
    }
    
    /**
     * 
     * @return the lives left 
     */
    public int getLivesLeft() {
        return this.lives;
    }
    
    /** 
     * 
     * @return true als het aantal levens groter dan 0 is 
     */
    public boolean stillLiving() {
        return this.lives > 0;
    }
    
    /**
     * Update de stringbuilder met karakter a
     * @param a het te updaten karakter
     */
    public void execGuess(char a) {
        for (int i = 0; i < toGuess.length(); i++) {
            if (toGuess.charAt(i) == a) {
                this.str.setCharAt(i, a);
            }
        }
    }
    
    /**
     * 
     * @return de stringbuilder met alle geraden karakters 
     */
    public String showGuessed() {
        return str.toString();
    }
    
    /**
     * 
     * @return het te raden woord 
     */
    public String getWoord() {
        return toGuess;
    }
    
    /**
     * 
     * @return true als het woord helemaal geraden is
     */
    public boolean totalGuessed() {
        return toGuess.equals(str.toString());
    }
}
