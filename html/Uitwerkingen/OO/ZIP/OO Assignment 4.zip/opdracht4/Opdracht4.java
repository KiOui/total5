/*
 * De main klasse van opdracht 4
 * De vragen worden hier toegevoegd voordat het programma gestart wordt.
 */
package opdracht4;

import java.util.LinkedList;
import java.util.List;

public class Opdracht4 {
    
    
    /**
     * Maakt een list vragen aan, voegt vragen toe aan de list en start de controller met de list met vragen
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        List<Vraag> vragen = new LinkedList<>();
        voegToe(vragen);
        Controller dummy = new Controller(vragen);
        
    }
    
    /*
    * Deze functie voegt vragen toe aan de list die meegegeven wordt
    * @param vragen: De vragen die meegegeven worden
    */
    public static void voegToe(List<Vraag> vragen) {
        vragen.add(new openVraag(
    "Wat is de complexiteit van binair zoeken?",
    "O(log N)"
    ));
        vragen.add(new openVraag(
    "Hoe lees je in Java een integer i uit een scanner s?",
    "i = s.nextInt();",
    2));
        vragen.add(new openVraag(
    "Is er verschil tussen een interface en een abstracte klasse?",
    "Ja",
    5));
        vragen.add(new openVraag(
    "Hoeveel constructoren je minstens maken bij een klasse in Java?",
    "0",
    2));
        vragen.add(new openVraag(
    "Is er een maximum aantal constructoren van een klasse in Java?",
    "Nee"
    ));
        vragen.add(new meerkeuzeVraag("Hoeveel bier kan Gijs handelen?", new String[]{"2", "3", "4", "5"}, 0, 5));
        vragen.add(new meerkeuzeVraag("Hoe groot is de kans dat je deze vraag goed gokt?", new String[]{"50%", "25%", "50%", "75%", "100%", "49.5%"}, 2, 1));
        vragen.add(new meerkeuzeVraag("Hoe lang is een Chinees?", new String[]{"2 meter 15", "15 centimeter", "hoe lang", "dit is sws een strikvraag jonguh"}, 3, 3));
        vragen.add(new tweekeuzeVraag("THIS SENTENCE IS FALSE.", "Goed", "Fout", 0, 5));
        vragen.add(new tweekeuzeVraag("Bier?", "Ja", "Ja natuurlijk", 1, 5));
    }
}
