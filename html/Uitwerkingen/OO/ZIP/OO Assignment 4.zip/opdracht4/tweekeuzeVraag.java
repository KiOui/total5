/*
 * De klasse voor de tweekeuzevraag, dit is een specifieke groep van de meerkeuzevragen. Er zijn maar twee antwoorden op deze vraag.
 */
package opdracht4;

public class tweekeuzeVraag extends meerkeuzeVraag{
    private String antwoord1;
    private String antwoord2;
    
    /**
     * De constructor van deze klasse, indien het gewicht niet wordt opgegeven wordt het gewicht op 3 gezet.
     * @param vraag De vraag die wordt gesteld
     * @param antwoord1 Eén van de twee antwoorden op de vraag
     * @param antwoord2 Eén van de twee antwoorden op de vraag
     * @param juiste de index van het juiste antwoord op de vraag (0 of 1)
     * @param gewicht Hoeveel de vraag meeteld in de score
     */
    public tweekeuzeVraag(String vraag, String antwoord1, String antwoord2, int juiste, int gewicht) {
        super(vraag, new String[]{antwoord1, antwoord2}, juiste, gewicht);
        if (juiste != 1 && juiste != 0) {
            throw new RuntimeException("Juiste heeft geen goede waarde bij het maken van object: " + vraag + ".");
        }
        this.antwoord1 = antwoord1;
        this.antwoord2 = antwoord2;
    }
    
    
    /**
     * De constructor van deze klasse zonder het gewicht (het gewicht wordt automatisch op 3 gezet)
     * @param vraag De vraag die wordt gesteld
     * @param antwoord1 Eén van de twee antwoorden op de vraag
     * @param antwoord2 Eén van de twee antwoorden op de vraag
     * @param juiste de index van het juiste antwoord op de vraag (0 of 1)
     */
    public tweekeuzeVraag(String vraag, String antwoord1, String antwoord2, int juiste) {
        super(vraag, new String[]{antwoord1, antwoord2}, juiste);
        if (juiste != 1 && juiste != 0) {
            throw new RuntimeException("Juiste heeft geen goede waarde bij het maken van object: " + vraag + ".");
        }
        this.antwoord1 = antwoord1;
        this.antwoord2 = antwoord2;
    }
    
    /**
     * Deze methode checkt of het antwoord wat gegeven is het correcte antwoord is.
     * @param antwoord het antwoord wat gegeven is (niet hoofdlettergevoelig)
     * @return true als het goede antwoord gegeven is
     */
    @Override
    public boolean isCorrect(String antwoord) {
        if (antwoord.equalsIgnoreCase(antwoord1) && getAntwoordIndex() == 0) {
            return true;
        }
        else if (antwoord.equalsIgnoreCase(antwoord2) && getAntwoordIndex() == 1) {
            return true;
        }
        else {
            return false;
        }
    }
    
    /**
     * Laat de antwoorden zien met de vraag achter de antwoorden
     * @return een string in de volgende vorm: [eerste antwoord] of [tweede antwoord]: [vraag]
     */
    @Override
    public String toString() {
        String dummy;
        dummy = antwoord1 + " of " + antwoord2 + ": " + getVraag();
        return dummy;
    }
    
    /**
     * Dupliceert dit object
     * @return dit object
     */
    @Override
    public tweekeuzeVraag duplicate() {
        return new tweekeuzeVraag(getVraag(), antwoord1, antwoord2, getJuiste(), super.gewicht);
    }
}
