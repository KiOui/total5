/*
 * De abstracte Vraag klasse
 */
package opdracht4;

public class Vraag {
    private String vraag;
    private String correcteAntwoord;
    public int gewicht;
    
    /**
     * De constructor van deze klasse zonder meegegeven gewicht, het gewicht wordt automatisch op 3 gezet.
     * @param vraag de vraag die gesteld wordt
     * @param correcteAntwoord het correcte antwoord op de vraag in de vorm van een string
     */
    public Vraag(String vraag, String correcteAntwoord) {
        this.vraag = vraag;
        this.correcteAntwoord = correcteAntwoord;
        this.gewicht = 3;
    }
    
    /**
     * De constructor van deze klasse met meegegeven gewicht.
     * @param vraag de vraag die gesteld wordt
     * @param correcteAntwoord het correcte antwoord op de vraag in de vorm van een string
     * @param gewicht het gewicht van de vraag (0 tot en met 5), indien het gewicht hoger of lager is dan deze waarde wordt een error gegeven.
     */
    public Vraag(String vraag, String correcteAntwoord, int gewicht) {
        if (gewicht < 0 || gewicht > 5) {
            throw new RuntimeException("Gewicht heeft geen goede waarde bij het maken van object: " + vraag + ".");
        }
        this.vraag = vraag;
        this.correcteAntwoord = correcteAntwoord;
        this.gewicht = gewicht;
    }
    
    /**
     * Deze functie geeft het juiste antwoord op de vraag
     * @return het juiste antwoord op de vraag
     */
    public String juisteAntwoord() {
        return correcteAntwoord;
    }
    
    /**
     * Bepaald of een meegegeven antwoord correct is
     * @param antwoord het gegeven antwoord (door de gebruiker)
     * @return true als het meegegeven antwoord correct is
     */
    public boolean isCorrect(String antwoord) {
        return antwoord.equalsIgnoreCase(correcteAntwoord);
    }
    
    /**
     * Deze functie geeft de vraag
     * @return de vraag
     */
    public String getVraag() {
        return vraag;
    }
    
    /**
     * Deze functie geeft de vraag
     * @return de vraag
     */
    @Override
    public String toString() {
        return vraag;
    }
    
    /**
     * Deze functie dupliceert dit object
     * @return dit object
     */
    public Vraag duplicate() {
        return new Vraag(vraag, correcteAntwoord, gewicht);
    }
}
