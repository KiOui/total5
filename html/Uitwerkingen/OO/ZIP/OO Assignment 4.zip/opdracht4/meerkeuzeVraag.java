/*
 * De klasse voor een meerkeuzevraag. De keuzes worden meegegeven in de vorm van een String array.
 */
package opdracht4;

import java.util.Random;
public class meerkeuzeVraag extends Vraag{
    private String[] antwoorden;
    private int antwoordIndex;
    
    /**
     * De constructor voor een meerkeuzevraag, de keuzes worden meegegeven in de vorm van een String array. Als het gewicht niet wordt meegegeven wordt het gewicht automatisch op 3 gezet.
     * @param vraag de vraag die gesteld moet worden
     * @param antwoorden een array van antwoorden
     * @param juisteAntwoord de index van het juiste antwoord in de array 'antwoorden'
     * @param gewicht het gewicht van de vraag
     */
    public meerkeuzeVraag(String vraag, String [] antwoorden, int juisteAntwoord, int gewicht) {
        super(vraag, antwoorden[juisteAntwoord], gewicht);
        this.antwoorden = antwoorden;
        this.antwoordIndex = juisteAntwoord;
    }
    
    /**
     * De constructor voor als het gewicht niet meegegeven wordt, het gewicht wordt automatisch op 3 gezet
     * @param vraag de vraag die gesteld moet worden
     * @param antwoorden een array van antwoorden
     * @param juisteAntwoord de index van het juiste antwoord in de array 'antwoorden'
     */
    public meerkeuzeVraag(String vraag, String[] antwoorden, int juisteAntwoord) {
        super(vraag, antwoorden[juisteAntwoord]);
        this.antwoordIndex = juisteAntwoord;
        this.antwoorden = antwoorden;
    }
    
    /**
     * Geeft de antwoordindex van het juiste antwoord terug
     * @return de index in de array 'antwoorden' van het juiste antwoord
     */
    public int getAntwoordIndex() {
        return antwoordIndex;
    }
    
    /**
     * Controleerd of een antwoord wat meegegeven wordt correct is
     * @param antwoord het gegeven antwoord (door de gebruiker), indien er meer dan 1 karakter wordt meegegeven wordt alleen het eerste karakter nagekeken door deze functie.
     * @return true als het goede antwoord is gegeven
     */
    @Override
    public boolean isCorrect(String antwoord) {
        antwoord = antwoord.toLowerCase();
        char dummy = antwoord.charAt(0);
        int antwoordInt = dummy - 'a';
        return antwoordInt == antwoordIndex;
        
    }
    
    /**
     * Laat de vraag zien gevolgd door genummerde antwoorden
     * @return een string in de volgende vorm: [vraag]\na: [antwoord1]\nb: [antwoord2]...\n
     */
    @Override
    public String toString() {
        char letter = 'a';
        String returnString;
        returnString = super.toString() + '\n';
        for (String antwoord : antwoorden) {
            returnString = returnString + letter + ": " + antwoord + "\n";
            letter++;
        }
        return returnString;
    }
    
    /**
     * Dupliceerd dit object en husselt de antwoorden door elkaar
     * @return dit object met verwisselde antwoorden
     */
    @Override
    public meerkeuzeVraag duplicate() {
        Random random = new Random();
        int shift = random.nextInt(antwoorden.length);
        String[] dummy = new String[antwoorden.length];
        for(int i = 0; i < antwoorden.length; i++) {
            int shuffle = shift + i;
            if (shuffle >= antwoorden.length) {
                shuffle = shuffle - antwoorden.length;
            }
            dummy[shuffle] = antwoorden[i];
            //Debug:
            //System.out.println("Iteration: " + i + " Shuffle has value: " + shuffle + " antwoorden[i] has value: " + antwoorden[i]);
        }
        int juiste = antwoordIndex + shift;
        if (juiste >= antwoorden.length) {
            juiste = juiste - antwoorden.length;
        }
        return new meerkeuzeVraag(getVraag(), dummy, juiste, super.gewicht);
    }
    
    public int getJuiste() {
        return antwoordIndex;
    }
}
