/*
 * Een minimale view klasse om output te doen en input te vragen
 */
package opdracht4;

import java.util.Scanner;

public class View {
    Scanner scanner;
    
    /**
     * constructor van deze klasse
     * @param scanner de scanner die gebruikt wordt om gebruikerinput te lezen
     */
    public View(Scanner scanner) {
        this.scanner = scanner;
    }
    
    /**
     * Geeft de volgende zin van de gebruikerinput terug
     * @return de volgende zin van de gebruikerinput
     */
    public String getLine() {
        return scanner.nextLine();
    }
    
    /**
     * Drukt af naar de console
     * @param line de af te drukken string
     */
    public void Output(String line) {
        System.out.println(line);
    }
}
