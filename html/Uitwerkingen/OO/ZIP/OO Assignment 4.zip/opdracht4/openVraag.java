/*
 * De open vraag klasse (niet veel verschillend aan de vraag klasse)
 */
package opdracht4;

public class openVraag extends Vraag{
    
    /**
     * De constructor van deze klasse zonder meegegeven gewicht, het gewicht wordt automatisch op 3 gezet.
     * @param vraag de vraag die gesteld wordt
     * @param correcteAntwoord het correcte antwoord op de vraag in de vorm van een string
     */
    public openVraag(String vraag, String correcteAntwoord) {
        super(vraag, correcteAntwoord);
    }
    
    /**
     * De constructor van deze klasse met meegegeven gewicht.
     * @param vraag de vraag die gesteld wordt
     * @param correcteAntwoord het correcte antwoord op de vraag in de vorm van een string
     * @param gewicht het gewicht van de vraag (0 tot en met 5), indien het gewicht hoger of lager is dan deze waarde wordt een error gegeven.
     */
    public openVraag(String vraag, String correcteAntwoord, int gewicht) {
        super(vraag, correcteAntwoord, gewicht);
    }
}
