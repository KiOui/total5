/*
 * De controller klasse, deze klasse regelt de in en output van het programma met de View.
 */
package opdracht4;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public final class Controller {
    private List<Vraag> vragen;
    private int score1;
    private int score2;
    private final View currentView;
    
    /**
     * De constructor van deze klasse, maakt een scanner object en een view object aan en start ronde 1 en 2.
     * @param vragen Een lijst van vragen die gesteld moet worden
     */
    public Controller(List<Vraag> vragen) {
        this.vragen = vragen;
        this.score1 = 0;
        this.score2 = 0;
        Scanner scanner = new Scanner(System.in);
        this.currentView = new View(scanner);
        currentView.Output("Welkom bij de quiz!!!\n");
        currentView.Output("Ronde 1:\n");
        this.vragen = ronde1();
        currentView.Output("\n\nRonde 2:\n");
        ronde2();
        einde();
    }
    
    /**
     * Deze functie regelt ronde 1 van het spel, alle vragen die fout zijn beantwoord worden opgeslagen in een lijst.
     * @return een lijst met vragen die fout zijn beantwoord
     */
    public List<Vraag> ronde1() {
        List<Vraag> nieuweVragen = new LinkedList<>();
        for (int i = 0; i < vragen.size(); i++) {
            currentView.Output(vragen.get(i).toString());
            boolean dummy = vragen.get(i).isCorrect(currentView.getLine());
            if (dummy) {
                currentView.Output("Goede antwoord!\n");
                score1 = score1 + vragen.get(i).gewicht;
            }
            else {
                currentView.Output("Verkeerde antwoord! Het antwoord was: " + vragen.get(i).juisteAntwoord() + ".\n");
                nieuweVragen.add(vragen.get(i).duplicate());
            }
        }
        return nieuweVragen;
    }
    
    /**
     * Deze functie regelt ronde 2 van het spel, alle fout beantwoorde vragen van ronde 1 worden hier nog eens gesteld.
     */
    public void ronde2() {
        for (int i = 0; i < vragen.size(); i++) {
            currentView.Output(vragen.get(i).toString());
            boolean dummy = vragen.get(i).isCorrect(currentView.getLine());
            if (dummy) {
                currentView.Output("Goede antwoord!\n");
                score2 = score2 + vragen.get(i).gewicht;
            }
            else {
                currentView.Output("Verkeerde antwoord! Het antwoord was: " + vragen.get(i).juisteAntwoord() + ".\n");
            }
        }
    }
    
    /**
     * Deze functie regelt het einde van het spel, de score van ronde 1 en 2 worden naar de console geschreven
     */
    public void einde() {
        currentView.Output("De quiz is afgelopen, de score van de eerste ronde was " + score1 + ".\nIn de tweede ronde zijn " + score2 + " punten behaald.\nIn totaal is dit een score van: " + (score1 + score2) + ".");
    }
}
