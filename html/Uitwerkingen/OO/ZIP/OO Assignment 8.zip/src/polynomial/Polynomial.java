package polynomial;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 * A skeleton class for representing Polynomials
 * @author Sjaak Smetsers
 * @date 19-04-2016
 */
public class Polynomial {

    /**
     * A polynomial is a sequence of terms here kept in an List
     */
    List<Term> terms;

    /**
     * A constructor for creating the zero Polynomial zero is presented as an
     * empty list of terms and not as a single term with 0 as a coefficient
     */
    public Polynomial() {
        terms = new LinkedList<>();
    }

    /**
     * A Constructor creating a polynomial from the argument string.
     *
     * @param s a String representing a list of terms which is converted to a
     * scanner and passed to scanTerm for reading each individual term
     */
    public Polynomial( String s ) {
        terms = new LinkedList<>();
        Scanner scan = new Scanner( s );

        for (Term t = Term.scanTerm(scan); t != null; t = Term.scanTerm(scan)) {
            terms.add(t);
        }
        clean();
        sort();
    }

    /**
     * The copy constructor for making a deep copy
     *
     * @param p the copied polynomial
     *
     */
    public Polynomial( Polynomial p ) {
        terms = new LinkedList<>();
        for (Term t : p.terms) {
            terms.add(new Term(t));
        }
        clean();
        sort();
    }
    
    /**
     * A straightforward conversion of a Polynomial into a string based on the
     * toString for terms
     *
     * @return a readable string representation of this
     */
    
    @Override
    public String toString() {
        if (!(terms.isEmpty())) {
            String dummy = terms.get(0).toString();
            for(int i = 1; i < terms.size(); i++) {
                if (terms.get(i).getCoef() >= 0) { 
                    dummy = dummy + " + " + terms.get(i).toString();
                }
                else {
                    dummy = dummy + " - " + terms.get(i).toString().substring(1);
                }
            }
            return dummy;
        }
        else {
            return "Such empty...";
        }

    }
    
    /**
     * 
     * @return the list within this polynomial
     */
    public List<Term> getList() {
        return terms;
    }
    
    /**
     * Adds two polynomails together, then minimizes and sorts them
     * @param b The polynomial to be added up to this polynomial
     */
    public void plus(Polynomial b) {
        int o = b.getList().size();
        for (int i = 0; i < o; i++) {
            terms.add(b.getList().get(i));
        }
        clean();
        sort();
        
    }

    /**
     * Substracts a polynomial from this polynomail, then minimizes and sorts them
     * @param b The polynomail to be substracted from this one
     */
    public void minus(Polynomial b) {
        int o = b.getList().size();
        for (int i = 0; i < o; i++) {
            terms.add(new Term(-1 * b.getList().get(i).getCoef(), b.getList().get(i).getExp()));
            System.out.println(terms);
        }
        clean();
        sort();
    }

    /**
     * Multiplies two polynomials, then minimizes and sorts them
     * @param b The polynomial to be multiplied with this one
     */
    public void times(Polynomial b) {
        List<Term> dummy = new LinkedList<>();
        for(int i = 0; i < terms.size(); i++) {
            for(int o = 0; o < b.getList().size(); o++) {
                dummy.add(new Term(terms.get(i)));
                
                dummy.get(dummy.size()-1).times(b.getList().get(o));
                System.out.println(dummy.get(dummy.size()-1));
                
            }
        }
        terms = dummy;
        clean();
        sort();
            
    }
    
    /**
     * Not implemented yet
     * @param b The polynomial to be divided with this polynomial
     */
    public void divide(Polynomial b) {
    }
    
    /**
     * Standard implementation of the equals function
     * @param other_poly The polynomial to be compared to this one
     * @return true if the two polynomials are the same, false otherwise
     */
    @Override
    public boolean equals(Object other_poly) {
        if (other_poly == null || getClass() != other_poly.getClass()) {
            return false;
        } 
        else {
            Polynomial poly = (Polynomial) other_poly;
            if (terms.size() != poly.getList().size()) {
                return false;
            }
            for (int i = 0; i < terms.size(); i++) {
                if (!(terms.get(i).equals(poly.getList().get(i)))) {
                    return false;
                }
            }
            return true;
        }
    }
    
    /**
     * Removes duplicate terms from this polynomial. Two terms having the same exponent will be added together, a term having a coefficient of 0 will be deleted from the polynomial.
     */
    private void clean() {
        
        for (int i = 0; i < terms.size(); i++) {
            int currentExp = terms.get(i).getExp();
            for (int o = i+1; o < terms.size(); o++) {
                if (currentExp == terms.get(o).getExp()) {
                    terms.get(i).plus(terms.get(o));
                    terms.remove(o);
                    o--;
                }
            }
        }
        
        for (int i = 0; i < terms.size() && !(terms.isEmpty()); i++) {
            if (terms.get(i).getCoef() == 0.0) {
                    terms.remove(i);
                    i--;
            }
        }
    }
    
    /**
     * A (very slow) implementation for sorting polynomials (on exponent).
     */
    private void sort() {
        List<Term> dummy = new LinkedList<>();
        while(!(terms.isEmpty())) {
            int lowestValue = terms.get(0).getExp();
            int index = 0;
            for (int i = 0; i < terms.size(); i++) {
                Term nextTerm = terms.get(i);
                if (nextTerm.getExp() <= lowestValue) {
                    lowestValue = nextTerm.getExp();
                    index = i;
                }
            }
            dummy.add(terms.get(index));
            terms.remove(index);
        }
        terms = dummy;
    }
    
    
}
