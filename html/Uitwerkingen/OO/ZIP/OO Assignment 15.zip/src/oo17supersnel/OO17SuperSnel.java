package oo17supersnel;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class OO17SuperSnel {

  private static final int AANTAL_KLANTEN = 30;

  public static void main(String[] args) {
    Thread[] threads = new Thread[AANTAL_KLANTEN];
    ExecutorService executor = Executors.newCachedThreadPool();
    Winkel winkel = new Winkel(executor);
    for (int i = 0; i < AANTAL_KLANTEN; i++) {
      Klant k = new Klant(i, winkel);
      Thread t = new Thread(k);
      threads[i] = t;
      executor.execute(t);
    }
  }
  
}
