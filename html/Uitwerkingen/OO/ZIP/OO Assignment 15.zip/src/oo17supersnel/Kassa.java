package oo17supersnel;

public class Kassa {
    private static final int BANDGROOTTE = 40, BAKGROOTTE = 10;
    private final BWR<Artikel> band;
    private final BWR<Artikel> bak;
    private int totaleArtikelen = 0;
    private boolean isClaimed = false;
    private final int id;
    
    public Kassa(int id) {
        this.band = new BWR<>(BANDGROOTTE);
        this.bak = new BWR<>(BAKGROOTTE);
        this.id = id;
    }
    
    /**
     * 
     * @param artikel het artikel op de band gelegd moet worden
     * @throws InterruptedException 
     */
    public synchronized void legOpBand (Artikel artikel) throws InterruptedException {
        while (band.aantalOpBand() == BANDGROOTTE) {
            wait();
        }
        band.stopIn(artikel);
        totaleArtikelen++;
        notifyAll();
    }
    
    /**
     * 
     * @return het laatst toegevoegde artikel van de band
     * @throws InterruptedException 
     */
    public synchronized Artikel haalVanBand () throws InterruptedException {
        while (band.isLeeg()) {
            wait();
        }
        Artikel b = band.haalUit();
        notifyAll();
        return b;
    }
    
    /**
     * 
     * @param artikel het artikel wat in de bak gelegd moet worden
     * @throws InterruptedException 
     */
    public synchronized void legInBak (Artikel artikel) throws InterruptedException {
        while (bak.aantalOpBand() == BAKGROOTTE) {
            wait();
        }
        bak.stopIn(artikel);
        notifyAll();
    }
    
    /**
     * 
     * @return het laatst toegevoegde element uit de bak
     * @throws InterruptedException 
     */
    public synchronized Artikel haalUitBak () throws InterruptedException {
        while (bak.isLeeg()) {
            wait();
        }
        Artikel b = bak.haalUit();
        notifyAll();
        return b;
    }
    
    /**
     * 
     * @return het aantal producten op de band
     */
    public int aantalOpBand () {
        return band.aantalOpBand();
    }
    
    /**
     * 
     * @return de band van deze kassa
     */
    public BWR<Artikel> getBand() {
        return band;
    }
    
    /**
     * 
     * @return de bak van deze kassa
     */
    public BWR<Artikel> getBak() {
        return bak;
    }
    
    /**
     * Voor het reserveren van deze kassa
     * @throws InterruptedException 
     */
    public synchronized void Claim() throws InterruptedException {
        while (isClaimed) {
            wait();
        }
        //System.out.println("Kassa " + id + " is nu bezet.");
        isClaimed = true;
    }
    
    /**
     * Voor het ongedaan maken van het reserveren van deze kassa
     */
    public synchronized void deClaim() {
        isClaimed = false;
        //System.out.println("Kassa " + id + " is nu open.");
        notifyAll();
    }
    
    /**
     * Voor het wachten op een volgende klant
     * @throws InterruptedException 
     */
    public synchronized void wachtOpKlant() throws InterruptedException {
        while (!isClaimed) {
            wait();
        }
    }
    
    /**
     * 
     * @return id 
     */
    public int getId() {
        return id;
    }
    
    /**
     * 
     * @return het aantal totale artikelen dat deze kassa heeft verwerkt
     */
    public int getTotaleArtikelen() {
        return totaleArtikelen;
    }
}
