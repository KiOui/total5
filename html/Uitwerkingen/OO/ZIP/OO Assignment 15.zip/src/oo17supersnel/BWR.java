package oo17supersnel;

public class BWR<T> {

  private final T[] elementen;
  private int aantal, begin, eind;

  public BWR(int grootte) {
    elementen = (T[]) new Object[grootte];
    aantal = 0;
    begin = 0;
    eind = 0;
  }

  public void stopIn(T item) {
    elementen[eind] = item;
    eind = (eind + 1) % elementen.length;
    aantal = aantal + 1;
  }

  public T haalUit() {
    T item = elementen[begin];
    begin = (begin + 1) % elementen.length;
    aantal = aantal - 1;
    return item;
  }

  public boolean isLeeg() {
    return aantal == 0;
  }
  
  public int aantalOpBand() {
      return aantal;
  }
}
