package oo17supersnel;

import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Klant implements Runnable {    
    private final Winkel winkel;
    private final int klantNummer;
    private final int aantalArtikelen;
    private final static Random generator = new Random ();
    
    public Klant (int nummer, Winkel winkel) {
        this.winkel = winkel;
        klantNummer = nummer;
        aantalArtikelen = generator.nextInt (20) + 1;
        System.out.println("Klant " + klantNummer + " heeft " + aantalArtikelen);
    }
    
    /**
     * Zorgt ervoor dat de klant zijn/haar boodschappen kan doen
     */
    @Override
    public void run() {
        List<Artikel> artikelen = winkel.pakArtikelen(aantalArtikelen);
        Kassa kassa = winkel.getKassa(generator.nextInt(Winkel.AANTAL_KASSAS));
        try {
            kassa.Claim();
        } catch (InterruptedException ex) {
            Logger.getLogger(Klant.class.getName()).log(Level.SEVERE, null, ex);
        }
        //System.out.println("Kassa " + kassa.getId() + " wordt nu gebruikt door klant " + klantNummer + ".");
        for (int i = 0; i < aantalArtikelen; i++) {
            try {
                kassa.legOpBand(artikelen.get(i));
            } catch (InterruptedException ex) {
                Logger.getLogger(Klant.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        //System.out.println("Klant " + klantNummer + " is klaar met het op de band leggen van al de artikelen.");
        try {
            kassa.legOpBand(null);
        } catch (InterruptedException ex) {
            Logger.getLogger(Klant.class.getName()).log(Level.SEVERE, null, ex);
        }
        for (int i = 0; i < aantalArtikelen; i++) {
            try {
                kassa.haalUitBak();
            } catch (InterruptedException ex) {
                Logger.getLogger(Klant.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        System.out.println("Klant " + klantNummer + " is klaar met het uit de bak halen van al de artikelen.");
    }
}
