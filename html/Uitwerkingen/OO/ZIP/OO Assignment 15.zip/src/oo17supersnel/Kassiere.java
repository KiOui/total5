/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package oo17supersnel;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Kassiere implements Runnable {

  private final Kassa kassa;
  private int totaalArtikelen = 0;

  public Kassiere(Kassa kassa) {
    this.kassa = kassa;
  }
  
  /**
   * Zorgt ervoor dat de kassiere haar werk kan doen
   * LET OP: deze functie stopt nooit dus deze thread zou geforceerd gestopt moeten worden
   */
  @Override
  public void run() {
      while (true) {
          //System.out.println("Kassa " + kassa.getId() + " heeft " + totaalArtikelen);
          try {
              kassa.wachtOpKlant();
          } catch (InterruptedException ex) {
              Logger.getLogger(Kassiere.class.getName()).log(Level.SEVERE, null, ex);
          }
          Artikel a = null;
          try {
              a = kassa.haalVanBand();
              if (!(a == null)) {
                  totaalArtikelen++;
              }
          } catch (InterruptedException ex) {
              Logger.getLogger(Kassiere.class.getName()).log(Level.SEVERE, null, ex);
          }
          while (a != null) {
              try {
                  kassa.legInBak(a);
              } catch (InterruptedException ex) {
                  Logger.getLogger(Kassiere.class.getName()).log(Level.SEVERE, null, ex);
              }
              try {
                  a = kassa.haalVanBand();
                  if (!(a == null)) {
                      totaalArtikelen++;
                  }
              } catch (InterruptedException ex) {
                  Logger.getLogger(Kassiere.class.getName()).log(Level.SEVERE, null, ex);
              }
          }
          kassa.deClaim();
      }
  }
}
