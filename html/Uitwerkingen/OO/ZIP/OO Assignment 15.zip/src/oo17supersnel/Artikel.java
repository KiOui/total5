package oo17supersnel;

public class Artikel {

  private int barcode;

  public Artikel(int barcode) {
    this.barcode = barcode;
  }
}
