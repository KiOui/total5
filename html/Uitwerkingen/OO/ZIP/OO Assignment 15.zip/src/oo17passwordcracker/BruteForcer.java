/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oo17passwordcracker;

import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.scene.control.ProgressBar;
import javafx.scene.text.Text;
public class BruteForcer implements Runnable {
    private boolean stopped = false;
    private final ProgressBar bar;
    private final Text t;
    private int passwordHash;
    private int hashCounter;
    private final PasswordCracker main;
    private static final int Too_long_password = 100000000;
    
    public BruteForcer (ProgressBar bar, Text t, int passwordHash, PasswordCracker main) {
        this.bar = bar;
        this.t = t;
        this.passwordHash = passwordHash;
        this.hashCounter = hashCounter;
        this.main = main;
    }
    
    /**
     * Updates the value of passwordHash.
     * @param passwordHash the new value for passwordHash.
     */
    public void updatepasswordHash (int passwordHash) {
        this.passwordHash = passwordHash;
    }
    
    /**
     * Run tries to crack the password and updates the progressbar and
     * informational text in the user interface.
     */
    @Override
    public void run() {
        this.stopped = false;
        boolean cracked = false;
        this.hashCounter = 0;
        
        Platform.runLater( () -> t.setText("Running"));
        while (!stopped) {
            if (hashCounter == passwordHash) {
                Platform.runLater( () -> t.setText("Cracked"));
                cracked = true;
                this.stopped = true;
            } else if (hashCounter >= Too_long_password) {
                Platform.runLater( () -> t.setText("Password too long"));
            }
            if (this.hashCounter % 1000 == 0) {
                Platform.runLater( () -> this.bar.setProgress( (double) this.hashCounter / (double) Too_long_password));
                this.stopped = main.getstopped();
                try {
                    Thread.sleep(1);
                } catch (InterruptedException ex) {
                    Logger.getLogger(PasswordCracker.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            this.hashCounter++;
        }
        if (!cracked) Platform.runLater( () -> t.setText("Stopped"));
    }
    
}
