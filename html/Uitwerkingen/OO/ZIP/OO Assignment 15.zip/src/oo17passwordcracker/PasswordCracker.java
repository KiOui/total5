package oo17passwordcracker;


import java.awt.Font;
import java.util.Arrays;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import static javafx.application.Application.launch;
import static javafx.application.Platform.exit;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.Group;
import javafx.scene.control.PasswordField;
import javafx.scene.text.Text;
import javafx.scene.control.Label;

public class PasswordCracker extends Application {
    
    private Button saveButton;
    private Button checkButton;
    private Button stopButton;
    private PasswordField text;
    private ProgressBar bar;
    private GridPane grid;
    private GridPane grid2;
    private int passwordHash = 0;
    private String information = "Welcome";
    Text t = new Text();
    private boolean stopped = false;
    private BruteForcer bruteForcer;
    
    /**
     * Makes the two stages separately 
     * @param primaryStage the primary stage
     */
    @Override
    public void start(Stage primaryStage) {
        makeEnterpassword(primaryStage);
        makeCheckPasswordStage();
    }
    
    
    /**
     * Initializes the "Enter password" GUI and sets the action handlers for the buttons.
     * @param primaryStage the primary stage.
     */
    public void makeEnterpassword(Stage primaryStage) {
        grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(5);
        grid.setVgap(10);
        grid.setStyle("-fx-background-color: #ffffff;");

        text = new PasswordField();
        grid.add(text, 0, 1);
        
        saveButton = new Button();
        saveButton.setText("Save");
        grid.add(saveButton, 2, 2);
        saveButton.setOnAction((ActionEvent event) -> {
            saveBtn();
        });

        Scene scene = new Scene(grid, 250, 100);

        
        primaryStage.setTitle("Enter password");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }
    
    /**
     * Initializes the "Check password" GUI and sets the action handlers for the buttons.
     * @param primaryStage the primary stage.
     */
    private void makeCheckPasswordStage() {

            grid2 = new GridPane();
            grid2.setAlignment(Pos.CENTER);
            grid2.setHgap(5);
            grid2.setVgap(10);
            grid2.setStyle("-fx-background-color: #ffffff;");
            
            bar = new ProgressBar();
            bar.prefWidthProperty().bind(grid2.widthProperty().multiply(0.9));
            grid2.add(bar, 0, 0, 3, 1);

            t.setText(information);
            grid2.add(t, 2, 1);

            checkButton = new Button();
            checkButton.setText("Check");
            grid2.add(checkButton, 2, 2);
            checkButton.setOnAction((ActionEvent event) -> {
                checkBtn();
            });

            stopButton = new Button();
            stopButton.setText("Stop");
            grid2.add(stopButton, 2, 3);
            stopButton.setOnAction((ActionEvent event) -> {
                stopBtn();
            });

            Scene scene2 = new Scene(grid2, 300, 300);

            Stage stage = new Stage();
            stage.setTitle("Check Password");
            stage.setScene(scene2);
            stage.show();

            this.bruteForcer = new BruteForcer(bar, t, passwordHash, this);
        }
                
    /**
     * This function is activated by the save button and saves the password.
     */
    private void saveBtn() {
        String password = text.getText();
        passwordHash = Arrays.hashCode(password.toCharArray());
        bruteForcer.updatepasswordHash(passwordHash);
    }
    
    /**
     * This function is activated by the check button checks the hash of the password.
     */
    private void checkBtn() {
        stopped = false;
        checkButton.setDisable(true);
        information = "Checking";
        t.setText(information);
        Thread thread = new Thread(bruteForcer);
        thread.start();
    }
    
    /**
     * This function is activated by the stop button and stops the progress of the check button.
     */
    private void stopBtn() {
        stopped = true;
        checkButton.setDisable(false);
        bar.setProgress(-1);
    }
   
    /**
     * Gets the value for stopped
     * @return the value for stopped
     */
    public boolean getstopped() {
        return this.stopped;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
