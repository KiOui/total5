/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment11;

import javafx.util.Duration;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.Animation;
import static javafx.application.Platform.exit;
import javafx.geometry.Pos;

public class Assignment11 extends Application {
    
    private Button startButton;
    private Button stopButton;
    private Button quitButton;
    private TextField text;
    private ProgressBar bar;
    private GridPane grid;
    private Timeline timeline;
    private double time = 0.;
    private double timeCount = 0.;
    
    /**
     * Initializes the GUI and sets the action handlers for the buttons.
     * @param primaryStage the primary stage.
     */
    @Override
    public void start(Stage primaryStage) {
        grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(5);
        grid.setVgap(10);
        grid.setStyle("-fx-background-color: #ffffff;");
        
        bar = new ProgressBar();
        bar.prefWidthProperty().bind(grid.widthProperty().multiply(0.9));
        grid.add(bar, 0, 0, 3, 1);

        text = new TextField();
        grid.add(text, 0, 1);
        
        quitButton = new Button();
        quitButton.setText("Quit");
        grid.add(quitButton, 2, 2);
        quitButton.setOnAction((ActionEvent event) -> {
            quitBtn();
        });
        
            
        startButton = new Button();
        startButton.setText("Start");
        grid.add(startButton, 2, 1);
        startButton.setOnAction((ActionEvent event) -> {
            startBtn();
        });
        
        stopButton = new Button();
        stopButton.setText("Stop");
        grid.add(stopButton, 0, 2);
        stopButton.setOnAction((ActionEvent event) -> {
            stopBtn();
        });

        Scene scene = new Scene(grid, 250, 100);
        
        primaryStage.setTitle("Time flies");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    /**
     * This function manages the progress bar.
     * @param e the action event.
     */
    public void tickHandler(ActionEvent e) {
        timeCount++;
        bar.setProgress(1 - timeCount/time);
        text.setText(String.valueOf((int) (time-timeCount)));
        if (timeCount >= time) {
            timeline.stop();
            grid.setStyle("-fx-background-color: #ff0000;"); 
            timeCount = 0;
        }
        if (time == 0)
            timeline.stop();
    }
    
    /**
     * This function starts the timer when the start button is pressed.
     */
    private void startBtn() {
        grid.setStyle("-fx-background-color: #ffffff;");
        String numberfield = text.getText();  
        time = Double.parseDouble(numberfield);
        timeline = new Timeline(new KeyFrame(Duration.seconds(1) , e -> tickHandler(e) ) ) ;
        timeline.setCycleCount(Timeline.INDEFINITE) ;
        timeline.play();
            }
         
    /**
     * This function stops the timer when the stop button is pressed.
     */
    private void stopBtn() {
        if (timeline.getStatus() == Animation.Status.RUNNING) {
            timeline.pause();
    }
    }
            
    /**
     * This function closes the timer when the close button is pressed.
     */
    private void quitBtn() {
        exit();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
