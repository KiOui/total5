package com.company;

public class Edge {
    private int v1;
    private int v2;
    private int weight;

    /**
     * Creates an edge from node v1 to node v2 with weight weight
     * @param v1 the first node of the edge
     * @param v2 the second node of the edge
     * @param weight the weight of the edge to create
     * Complexity: O(1)
     */
    public Edge(int v1, int v2, int weight) {
        this.v1 = v1;
        this.v2 = v2;
        this.weight = weight;
    }

    /**
     * Returns the first node of this edge
     * @return the first node of this edge
     * Complexity: O(1)
     */
    public int getV1() {
        return v1;
    }

    /**
     * Returns the second node of this edge
     * @return the second node of this edge
     * Complexity: O(1)
     */
    public int getV2() {
        return v2;
    }

    /**
     * Returns a string of this edge from v1 to v2 with weight weight
     * @return a string of this edge
     * Complexity: O(1)
     */
    @Override
    public String toString() {
        return (v1 + " " + v2 + " " + weight);
    }
}
