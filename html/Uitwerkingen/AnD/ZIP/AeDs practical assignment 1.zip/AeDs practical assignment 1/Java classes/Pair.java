package com.company;

public class Pair {
    private int x;
    private int y;

    /**
     * Creates a new pair with parameters x and y
     * @param x the first element of the pair
     * @param y the second element of the pair
     * Complexity: O(1)
     */
    public Pair(int x, int y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Returns the first element of the pair
     * @return the first element of the pair
     * Complexity: O(1)
     */
    public int getX() {
        return x;
    }

    /**
     * Returns the second element of the pair
     * @return the second element of the pair
     * Complexity: O(1)
     */
    public int getY() {
        return y;
    }
}
