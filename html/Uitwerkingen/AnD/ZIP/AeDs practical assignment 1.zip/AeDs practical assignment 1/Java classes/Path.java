package com.company;

public class Path {
    private Node to;
    private int length;

    /**
     * Creates a new path
     * @param to the node to go to
     * @param length the weight of the path
     * Complexity: O(1)
     */
    public Path(Node to, int length) {
        this.to = to;
        this.length = length;
    }

    /**
     * Return the node this path goes to
     * @return to
     * Complexity: O(1)
     */
    public Node getTo() {
        return to;
    }

    /**
     * Return the weight of this path
     * @return length
     * Complexity: O(1)
     */
    public int getLength() {
        return length;
    }
}
