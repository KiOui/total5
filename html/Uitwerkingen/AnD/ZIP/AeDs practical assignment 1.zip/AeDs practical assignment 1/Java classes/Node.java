package com.company;


import java.util.LinkedList;

public class Node {
    private LinkedList<Path> nodes = new LinkedList<Path>();
    private int label;

    public Node(int label) {
        this.label = label;
    }

    /**
     * Returns the size of the linkedlist nodes
     * @return the amount of nodes this node has a path to
     * Complexity: O(1)
     */
    public int getDegree() {
        return nodes.size();
    }

    /**
     * Returns the node of a path at index index
     * @param index the index of the path in nodes
     * @return the node the path at index goes to, if the index does not exists null will be returned
     * Complexity: O(N)
     */
    public Node getNode(int index) {
        if (index < nodes.size() && index >= 0) {
            return nodes.get(index).getTo();
        } else {
            return null;
        }
    }

    /**
     * Adds a path from this node to another node
     * @param to the node to add the path to
     * @param weight the weight of the path to add
     * Complexity: O(1)
     */
    public void addPath(Node to, int weight) {
        nodes.add(new Path(to, weight)); //Complexity: O(1)
    }

    /**
     * Returns the nodes linkedlist
     * @return nodes
     * Complexity: O(1)
     */
    public LinkedList<Path> getNodes() {
        return nodes;
    }

    /**
     * Returns the label of this node
     * @return label
     * Complexity: O(1)
     */
    public int getLabel() {
        return label;
    }

    /**
     * Returns this node as a string of its label
     * @return its label in string form
     * Complexity: O(1)
     */
    @Override
    public String toString() {
        return label + "";
    }
}
