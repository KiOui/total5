package com.company;

import java.util.LinkedList;

public class Shortest {
    private int last;
    private int size;
    private int[][] array;

    /**
     * Creates a 2D array with size size
     * @param array the input array
     * @param size the size of the array
     * Complexity: O(1)
     */
    public Shortest(int[][] array, int size) {
        this.last = 0;
        this.array = array;
        this.size = size;
    }

    /**
     * Returns the next lowest element in the array
     * @return the next lowest element in the array list, if this element can not be found this will return -1
     * Complexity: O(N^2)
     */
    public int shortestRemaining() {
        int current = -1;
        for (int i = 0; i < size; i++) { //Complexity: O(N^2)
            for (int j = i + 1; j < size; j++) { //Complexity: O(N)
                if (array[i][j] > last && (array[i][j] < current || current == -1)) {
                    current = array[i][j];
                }
            }
        }
        last = current;
        return current;
    }

    /**
     * Creates a linkedlist of Pairs for which weight is equal to the edge weights in the 2D array
     * @param weight the edge weight of the pairs to return
     * @return a linkedlist with pairs with edges of weight weight
     * Complexity: O(N^2)
     */
    public LinkedList<Pair> getPairs(int weight) {
        LinkedList<Pair> pairs = new LinkedList<>();
        for (int i = 0; i < size; i++) { //Complexity: O(N^2)
            for (int j = i + 1; j < size; j++) { //Complexity: O(N)
                if (array[i][j] == weight) {
                    pairs.add(new Pair(i, j)); //Complexity: O(1)
                }
            }
        }
        return pairs;
    }
}
