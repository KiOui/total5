package com.company;

import java.util.LinkedList;
import java.util.Scanner;

public class Main {

    /**
     * Executes algorithm
     * @param args agruments
     * Complexity: O(N^5)
     */
    public static void main(String[] args) {
        /**
         * Input
         * Complexity: O(N^2)
         */
        Scanner s = new Scanner(System.in);
        int n = s.nextInt();

        int[][] shortestPaths = new int[n][n];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                shortestPaths[i][j] = s.nextInt();
            }
        }


        Graph constellation = new Graph(n); //Complexity: O(N)
        Shortest helper = new Shortest(shortestPaths, n); //Complexity: O(1)


        int drawnEdges = 0;

        /**
         * Constructing constellation
         * This while loop will, in the worst case, loop through the whole array, this will take N^2 computations
         * Complexity: O(N^5)
         */
        while (drawnEdges < n) {
            int nextShortest = helper.shortestRemaining();

            /**
             * Adding final edges
             * Complexity: O(N)
             */
            if (nextShortest == -1) {
                if(!constellation.addFinalEdge()) {
                    System.out.println("Something went terribly wrong...");
                }
                drawnEdges++;
            }

            /**
             * Adding a normal edge
             * Complexity: O(N^3)
             */
            else {
                LinkedList<Pair> nextPairs = helper.getPairs(nextShortest); //Complexity: O(N^2)

                /**
                 * Adding all pairs to constellation edges
                 * Complexity: O(N^3)
                 */
                for (int i = 0; i < nextPairs.size(); i++) {
                    Pair nextPair = nextPairs.get(i); //Complexity: O(N)
                    /**
                     * Setting array
                     * Complexity: O(N)
                     */
                    boolean[] list = new boolean[n];
                    for (int j = 0; j < list.length; j++) {
                        list[j] = false;
                    }
                    /**
                     * Adding edges
                     * Complexity: O(N^2)
                     */
                    if (drawnEdges < n && !constellation.drawn(nextPair.getX(), nextPair.getY(), nextShortest, list)) { //Complexity: O(N^2)
                        constellation.addEdge(nextPair.getX(), nextPair.getY(), nextShortest); //Complexity: O(1)
                        drawnEdges++;
                    }
                }
            }
        }

        System.out.println(constellation); //Complexity: O(N)
    }

}
