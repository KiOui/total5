package com.company;

import java.util.LinkedList;

/**
 * Class for graph object
 */
public class Graph {
    private Node[] vertices;
    private LinkedList<Edge> edges = new LinkedList<Edge>();

    /**
     * Creates a graph with size nodes
     * @param size the amount of nodes
     * Complexity: O(N)
     */
    public Graph(int size) {
        vertices = new Node[size];
        for (int i=1; i <= size; i++) {
            vertices[i-1] = new Node(i);
        }
    }

    /**
     * Adds an edge from node from to node to of weight weight
     * @param from index of node from (label-1)
     * @param to index of node to (label-1)
     * @param weight the weight of this edge
     * Complexity: O(1)
     */
    public void addEdge(int from, int to, int weight) {
        vertices[from].addPath(vertices[to], weight); //Complexity: O(1)
        vertices[to].addPath(vertices[from], weight); //Complexity: O(1)
        edges.add(new Edge(from+1, to+1, weight)); //Complexity: O(1)
    }

    /**
     * Returns all adjecent nodes of node with label index+1
     * @param index the index location of the node with label index+1
     * @return the adjecency list of node with index index
     * Complexity: O(1)
     */
    public LinkedList<Path> getAdj(int index) {
        return vertices[index].getNodes(); //Complexity: O(1)
    }

    /**
     * Executes a breath first search to search if a shortest path is already drawn, this breath first search reminds the last item it has gone to so it won't directly go back to the node it was called from
     * @param from the node to search from
     * @param to the node to search to
     * @param weight the current total weight of coming to a certain node
     * @param visited the array indicating which vertices have already been visited
     * @return if a shorter edge already exists
     * Complexity: O(N^2)
     */
    public boolean drawn(int from, int to, int weight, boolean[] visited) {
        if (!visited[from]) {
            if (from == to && weight == 0)
                return true;

            LinkedList<Path> adj = vertices[from].getNodes(); //Complexity: O(1)

            for (int i = 0; i < adj.size(); i++) {
                Path nextPath = adj.get(i); //Complexity: O(N)
                if (weight - nextPath.getLength() >= 0) {
                    visited[from] = true;
                    //The maximum amount of recursive calls is equal to the total amount of vertices - 1
                    if (drawn(nextPath.getTo().getLabel() - 1, to, weight - nextPath.getLength(), visited)) {
                        return true;
                    }
                    visited[from] = false;
                }
            }
            return false;
        }
        else {
            return false;
        }
    }

    /**
     * Add n'th edge to a connected graph with n-1 edges, connects two of the vertices with degree 1
     * as these cannot already be connected (otherwise the graph would not be connected)
     * @return true if the function succeeded
     * Complexity: O(N)
     */
    public boolean addFinalEdge() {
        int[] unconnected = new int[] {-1, -1};
        int i = 0;
        while (unconnected[0] == -1 || unconnected[1] == -1) {
            if (i < vertices.length) {
                if (vertices[i].getDegree() == 1) {
                    if (unconnected[0] == -1) {
                        unconnected[0] = i;
                    } else {
                        unconnected[1] = i;
                    }
                }
            }
            else {
                return false;
            }
            i++;
        }
        this.addEdge(unconnected[0], unconnected[1], 2000000);
        return true;
    }

    /**
     * Returns a string of all created edges
     * @return string of created edges
     * Complexity: O(N)
     */
    @Override
    public String toString() {
        String retval = "";
        for (int i = 0; i < edges.size(); i++) {
            retval = retval + edges.get(i).toString() + "\n";
        }
        return retval;
    }

}
