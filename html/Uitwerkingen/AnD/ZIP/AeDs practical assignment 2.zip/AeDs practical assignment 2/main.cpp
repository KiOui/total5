#include <iostream>
#include <cassert>

using namespace std;

const int MAX_ITEMS = 5000;

typedef int row[MAX_ITEMS+1];

const int ROUNDAT = 10;

/**
* This function will round toRound to the next (or previous) multiply of ROUNDAT
* toRound:          The integer to round.
*
* Return:           Rounded toRound.
*
* Total complexity: O(1)
*/
int roundAt(int toRound) {
    //Complexity: O(1)
    //Only primitive operations used.
    return ((toRound + (ROUNDAT/2))/ROUNDAT)*ROUNDAT;
}

/**
* This function computes the column of the matrix.
* previous:         The previous column of the matrix.
* next:             The next column of the matrix, this array will be used for the output of this function.
* dividerAmount:    The amount of dividers to use.
* products:         The amount of products.
* productBelts:     A pointer to the array which contains all products.
*
* Total complexity: O(n^2)
*/
void nextStep(row previous, row next, int dividerAmount, int products, const int* productBelts) {
    next[0] = 0;
    //Complexity: O(n^2)
    //This will iterate dividerAmount to products and will execute O(n) complexity each iteration.
    for (int productAmount = dividerAmount; productAmount <= products; productAmount++) {
        int previousMin = previous[productAmount];
        int currentSum = 0;
        //Complexity: O(n)
        //This will iterate from productAmount-1 to dividerAmount. Each iteration will execute O(1) complexity.
        for (int t = productAmount-1; t >= dividerAmount; t--) {
            //Complexity: O(1)
            //Only primitive operations used.
            currentSum = currentSum + productBelts[t];
            int nextMin = roundAt(currentSum) + previous[t];
            if (nextMin < previousMin) {
                previousMin = nextMin;
            }
        }
        next[productAmount] = previousMin;
    }
}

/**
* Main
*
* Total complexity: O(kn^2)
* Calculation: O(n) + O(n) + O(k*n^2) = O(kn^2)
*/
int main()
{

    int products;
    int dividers;

    cin >> products;
    cin >> dividers;

    int productBelts[products];

    //Complexity: O(n)
    for (int i = 0; i < products; i++) {
        cin >> productBelts[i];
    }

    row previous;
    row next;

    previous[0] = 0;

    int total = 0;
    //Complexity: O(n)
    for (int i = 1; i < products+1; i++) {
        total = total + productBelts[i-1];
        previous[i] = roundAt(total);
    }

    bool prev = false;

    //Complexity: O(k*n^2)
    //This loop will iterate divider times, and will execute a O(n^2) complexity algorithm.
    for (int dividerAmount = 1; dividerAmount <= dividers; dividerAmount++) {
        //Complexity: O(n^2)
        //nextStep executes in O(n^2).
        if (prev) {
            nextStep(next, previous, dividerAmount, products, productBelts);
        }
        else {
            nextStep(previous, next, dividerAmount, products, productBelts);
        }
        prev = !prev;
    }

    if (prev) {
        cout << next[products] << endl;
    }
    else {
        cout << previous[products] << endl;
    }

    return 0;
}
