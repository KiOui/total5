#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>

struct stat st = {0};

char *dirpath = "/tmp/.ossechidden/";
char *path = "/tmp/.ossechidden/.hiddenfile";

void flush_cin(){
    char c;
    while ((c = getchar()) != '\n' && c != EOF) { }
}

int main() {
    printf("Do you want to send (1) or receive (2) a message?\n");
    int input;
    scanf("%d", &input);
    flush_cin();
    if (input == 2){

        // receive message

        FILE *fp = fopen(path, "r");
        char message[256];
        fgets(message, 256, fp);
        fclose(fp);
        printf("%s", message);
        int ret = unlink(path);
        if (ret==0)
            printf("Message deleted\n");
        else
            printf("Message not deleted\n");
    }
    else {

        // send message

        char message[256];
        if(access(path, F_OK)!=-1) {
            printf("You are now deleting your previous message, are you sure (0) or abort (1)?\n");
            int answer;
            scanf("%d", &answer);
            flush_cin();
            if (answer == 1)
                exit(0);
        }
        printf("Enter the message:\n");
        fgets(message, 256, stdin);
        if (stat(dirpath, &st) == -1) {
            umask(0);
            mkdir(dirpath, 0777);
        }
        FILE *fp = fopen(path, "w");
        fprintf(fp, "%s", message);
        fclose(fp);
        chmod (path,0777);
    }
    return 0;
}
