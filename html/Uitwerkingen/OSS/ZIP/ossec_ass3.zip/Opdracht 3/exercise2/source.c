char p[] = "char p[] = %c%s%c; main(){printf(p,34,p,34,10);}%c"; main(){printf(p,34,p,34,10);}
