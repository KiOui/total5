#include <time.h>
#include <stdio.h>
#include <stdlib.h>


/*
    We wrote this code based on the following code on:
    https://www.raspberrypi.org/forums/viewtopic.php?t=64835&p=479657
*/

double  theseSecs = 0.0;
double  startSecs = 0.0;
double  secs;
double  CPUsecs = 0.0;
double  CPUutilisation = 0.0;
double  answer = 0;
clock_t starts;

void start_CPU_time()
{      
    starts = clock();;
    return;
}

void end_CPU_time()
{
    CPUsecs = (double)(clock() - starts)/(double)CLOCKS_PER_SEC;
    return;
}    

struct timespec tp1;
void getSecs()
{
   clock_gettime(CLOCK_REALTIME, &tp1);
   theseSecs =  tp1.tv_sec + tp1.tv_nsec / 1e9;           
   return;
}

void start_time()
{
    getSecs();
    startSecs = theseSecs;
    return;
}

void end_time()
{
    getSecs();
    secs    = theseSecs - startSecs;
    return;
}    

void calculate()
{
    int i, j;
    for (i=1; i<100001; i++)
    {
        for (j=1; j<10001; j++)
        {
            answer = answer + (float)i / 100000000.0;
        }
    }
}
      
double calc_cpu_usage()
{
    theseSecs = 0.0;
    startSecs = 0.0;
    secs = 0.0;
    CPUsecs = 0.0;
    CPUutilisation = 0.0;
    answer = 0;
 
    start_time();
    start_CPU_time();
    calculate();
    end_time();
    end_CPU_time();
    return 100*secs;
}

/* 
    From here we wrote our own code:
*/

int main() {
    float treshold;
    printf("Enter treshold value, something like 0.3 will be fine (worked on our system, but the faster the system, the lower the treshold should be (however this will cause more false positives))\n");
    scanf("%f", &treshold);
    printf("treshold is %f, receiving will start in a bit\n", treshold);
    int meancpu = 0;
    int cyclecount = 1;
    int curcpu = 0;
    curcpu = calc_cpu_usage();
    meancpu = curcpu;
    printf("%s\n", "started receiving, stop process by CTRL+C");

    while (1) {
        meancpu = ((cyclecount * meancpu) + curcpu) / (cyclecount+1);
        cyclecount = cyclecount + 1;
        curcpu = calc_cpu_usage();
 
       // printf("%i\n", curcpu);
 
       // the value below is the treshold 
        if (abs(meancpu-curcpu) > (treshold * meancpu)){
            printf("%s\n","message detected, receiving temporarily stoppend");
            curcpu = calc_cpu_usage();
            printf("%s\n", "started receiving again, stop process by CTRL+C");
            cyclecount = 1;
            meancpu = curcpu;
        }
    }
    return 0;
}
