#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main(){
    printf("Sending message now, this will slow down your system for several seconds.\n");
    fork();
    fork();
    fork();
    fork();
    for (int n = 0; n < 100000; n++) {
	    int i, flag = 0;
	    for (i = 2; i <= n/2; i++) {
            if (n%i==0) {
          	flag = 1;
		break;
	    }
        }
    }
}
