ciphertext = "KEK! TOP! KEK! TOP! KEK! TOP!!! KEK! TOP!!! KEK! TOP! KEK! TOP! KEK! TOP!! KEK!!! TOP! KEK!! TOP!! KEK!!! TOP! KEK!! TOP!! KEK!!!! TOP! KEK!! TOP! KEK!!!!!! TOP!! KEK! TOP!! KEK!!! TOP!!! KEK! TOP! KEK! TOP! KEK! TOP!! KEK!!! TOP! KEK!! TOP!! KEK!!! TOP! KEK!! TOP!! KEK!!!! TOP! KEK!! TOP! KEK!!!!!! TOP!! KEK!! TOP! KEK!!! TOP!!! KEK! TOP! KEK! TOP! KEK! TOP!! KEK!!! TOP! KEK!!! TOP! KEK!!!!!! TOP!! KEK!! TOP! KEK!!! TOP!!! KEK! TOP! KEK! TOP! KEK! TOP!! KEK!!! TOP! KEK!!! TOP! KEK!!!!!!! TOP! KEK! TOP!! KEK! TOP! KEK!! TOP! KEK!!!!!! TOP! KEK! TOP! KEK!! TOP! KEK!! TOP!! KEK! TOP! KEK!! TOP! KEK! TOP!! KEK!!! TOP!! KEK! TOP!! KEK! TOP! KEK! TOP!! KEK!! TOP! KEK!!!!!! TOP! KEK! TOP! KEK!! TOP!! KEK! TOP!! KEK!!!! TOP! KEK! TOP!! KEK! TOP!!! KEK!! TOP!! KEK!!! TOP!! KEK! TOP!! KEK! TOP! KEK!!!! TOP!! KEK!! TOP! KEK! TOP! KEK! TOP!!!! KEK! TOP! KEK!"

split_cipher = ciphertext.split()
decrypted = ''
for block in split_cipher:
    if block.startswith('KEK'):
        decrypted += '0' * (len(block) - 3)
    else:
        decrypted += '1' * (len(block) - 3)

def n2s(n):
    """
    Number to string.
    """
    s = hex(n)[2:].rstrip("L")
    if len(s) % 2 != 0:
        s = "0" + s
    return s.decode("hex")

decrypted = int(decrypted, 2)
print (n2s(decrypted))
