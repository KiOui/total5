import kmeans.kmeans as own
from scipy.io import loadmat
import sklearn.cluster as default
import csv

data_files = ["synth1.mat", "synth2.mat", "synth3.mat", "synth4.mat"]


def compare_kmeans(X, k):

    centroids_own, clusters_own, sse_own = own.k_means(X, k, bisecting=False)
    centroids, clusters, sse = default.k_means(X, k, precompute_distances=False, algorithm="full", n_init=1, max_iter=100)
    centroids_bisecting, clusters_bisecting, sse_bisecting = own.k_means(X, k, bisecting=True)
    return sse_own, sse, sse_bisecting


def write_csv_comparison(datafile, csv_name, range_max):
    matfile = loadmat(datafile)

    X = matfile['X']
    y = matfile['y']

    c = csv.writer(open(csv_name, "w"))
    c.writerow(['Clusters', 'Own kmeans algorithm', 'Standard kmeans algorithm', 'Bisecting kmeans algorithm'])
    for i in range(2, range_max):
        print("Starting row " + str(i))
        sse_own_l = []
        sse_l = []
        sse_bisecting_l = []
        for k in range(0, 10):
            sse_own, sse, sse_bisecting = compare_kmeans(X, i)
            sse_own_l = sse_own_l + [sse_own]
            sse_l = sse_l + [sse]
            sse_bisecting_l = sse_bisecting_l + [sse_bisecting]

        c.writerow([str(i), str(sum(sse_own_l)/len(sse_own_l)), str(sum(sse_l)/len(sse_l)), str(sum(sse_bisecting_l)/len(sse_bisecting_l))])


write_csv_comparison(data_files[3], "test4.csv", 40)