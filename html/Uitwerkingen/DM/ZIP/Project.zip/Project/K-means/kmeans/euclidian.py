import math

class Euclidian:
    """Euclidian distance object"""

    def get_distance(self, point1: [], point2: []) -> float:
        '''
        Complexity: O(d) (disregarding the fact that both point variables are lists)
        Computes the distance between two points
        :param point1: the first point
        :param point2: the second point
        :return: the distance between point1 and point2
        '''
        sum = 0
        for i in range(0, len(point1)):
            difference = point1[i] - point2[i]
            sum = sum + difference*difference
        return math.sqrt(sum)
