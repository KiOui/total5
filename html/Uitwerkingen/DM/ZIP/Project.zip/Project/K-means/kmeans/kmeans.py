from kmeans.euclidian import Euclidian
import random
from kmeans.centroid import Centroid
import numpy as np


class Kmeans:

    def __init__(self, values, k, distance_algorithm=Euclidian()):
        '''
        Initialiser for the Kmeans class
        :param values: the values to create clusters on
        :param k: the amount of clusters that should be created
        :param distance_algorithm: the distance algorithm that should be used, this class should include the get_distance function
        '''
        self.values = values
        self.k = k

        if len(values) < k <= 0:
            raise Exception("Can't create " + k + " partitions out of set with " + str(len(values)) + "  elements")

        self.distance_algorithm = distance_algorithm

    def apply(self, max_iterations=100, start='kmeans++'):
        '''
        Applies the kmeans algorithm
        :param max_iterations: the maximum amount of iterations
        :return: an ndarray of centroids (k centroids) and an ndarray of best_centroid for all values (as an index position in the previous array)
        '''
        if start == 'kmeans++':
            centroids = self.kmeans_plus_plus()
        else:
            centroids = self.pick_random_start()

        # O(mkdn)
        for i in range(0, max_iterations):
            # O(kn)
            self.add_values_to_centroids(centroids)
            # O(kdn)
            new_centroids = self.recalculate_centers(centroids, self.distance_algorithm)
            if self.same_centroids(centroids, new_centroids):
                break
            else:
                centroids = new_centroids

        return np.array([x.centroid_values for x in centroids]), np.array([self.best_centroid(centroids, value).id for value in self.values])

    def add_values_to_centroids(self, centroids: [Centroid]):
        '''
        Complexity: O(kn)
        Adds all values to the closest centroid
        :param centroids: the centroids the values should be added too
        :return: None
        '''
        for value in self.values:
            self.best_centroid(centroids, value).add_to_centroid(value)

    def same_centroids(self, old_centroids, new_centroids):
        '''
        Compares two sets of centroids
        :param old_centroids: the first set to compare
        :param new_centroids: the second set to compare
        :return: True if both sets match
        '''
        return set(old_centroids) == set(new_centroids)

    def best_centroid(self, centroids: [Centroid], value):
        '''
        Complexity: O(k)
        Returns the closest centroid to the value
        :param centroids: the list of centroids to choose from
        :param value: the value for which the distance should be calculated
        :return: the closest centroid in the centroids list
        '''
        distances = [(centroid.distance_to_point(value), centroid) for centroid in centroids]
        min_distance, closest_centroid = min(distances)
        return closest_centroid

    def best_distance(self, centroids: [Centroid], value):
        '''
        Returns the closest centroid to the value
        :param centroids: the list of centroids to choose from
        :param value: the value for which the distance should be calculated
        :return: the closest centroid in the centroids list
        '''
        distances = [centroid.distance_to_point(value) for centroid in centroids]
        min_distance = min(distances)
        return min_distance

    def recalculate_centers(self, centroids: [Centroid], distance_algorithm):
        '''
        Complexity: O(kdn)
        Recalculates the centers of all centroid objects (produces new centroids)
        :param centroids: the centroids where the centers need to be recalculated
        :param distance_algorithm: the used distance algorithm
        :return: a list with new centroids and new centers
        '''
        return [Centroid(centroid.recalculate_center(), distance_algorithm, centroid.id) for centroid in centroids]

    def pick_random_start(self):
        '''
        Picks a random start out of all values
        :return: a list with k values from self.values
        '''
        aux = [x for x in range(len(self.values))]
        retvalue = []
        for i in range(0, self.k):
            posit = random.randrange(len(aux))
            index = aux[posit]
            elem = self.values[index]
            del aux[posit]
            retvalue = retvalue + [Centroid(elem, self.distance_algorithm, i)]
        return retvalue

    def kmeans_plus_plus(self):
        '''
        Executes the kmeans++ method of selecting initial points
        :return: a list with k values from self.values
        '''
        posit = random.randrange(len(self.values))
        retvalue = [Centroid(self.values[posit], self.distance_algorithm, 0)]
        for i in range(1, self.k):
            to_add = self.add_point(retvalue)
            retvalue = retvalue + [Centroid(to_add, self.distance_algorithm, i)]
        return retvalue

    def add_point(self, centers):
        distances = [self.best_distance(centers, value) for value in self.values]
        distance_squared = [distance**2 for distance in distances]
        total_distance = sum(distance_squared)
        distance_divided = [distance/total_distance for distance in distance_squared]
        prob = random.uniform(0, 1)
        counter = 0
        for i in range(0, len(self.values)):
            counter = counter + distance_divided[i]
            if counter > prob:
                return self.values[i]
        raise Exception("No value selected in random generator!")


    def sum_squared_error(self, centroids: np.array, values, nearest_centroid: np.array):
        '''
        Computes the SSE of given clusters and values
        :param centroids: the centroids
        :param values: the values of the entire data set (this function does not work over self.values)
        :param nearest_centroid: a list with nearest centroids
        :return: SSE of the centroids and values
        '''
        if len(values) != len(nearest_centroid):
            raise Exception("Values length must be equal to centroid list length")

        centroids = [Centroid(centroids[x].tolist(), self.distance_algorithm, x) for x in range(0, len(centroids))]
        distances = [centroids[nearest_centroid[x]].distance_to_point(values[x].tolist())**2 for x in range(0, len(values))]
        return sum(distances)

    def best_bisection(self, centroid: Centroid, iterations: int) -> [Centroid]:
        '''
        Complexity: O(imkdn)
        Returns the best bisection out of iterations runs of kmeans
        :param centroid: the current centroid which should be bisected (the centroid should have values in its cluster variable)
        :param iterations: the amount of times kmeans should be executed
        :return: the best iteration of kmeans
        '''
        # O(i*mkdn)
        clusters = [k_means(centroid.cluster, 2) for i in range(0, iterations)]
        # O(i)
        sses = [x for _, _, x in clusters]
        # O(i)
        min = int(np.argmin(sses))
        # O(i)
        centroids, clusters, sse = clusters[min]
        # O(c)
        centroids = [Centroid(centroids[x].tolist(), self.distance_algorithm, x) for x in range(0, len(centroids))]
        for i in range(0, len(clusters)):
            centroids[clusters[i]].add_to_centroid(centroid.cluster[i])

        return centroids

    def apply_bisecting(self, iterations=10):
        '''
        Executes the bisecting kmeans algorithm
        :param iterations: the amount of times kmeans should be executed each iteration
        :return: a clustering
        '''
        start = Centroid([], Euclidian(), 0)
        # O(n)
        for value in self.values:
            start.add_to_centroid(value)

        clusters = [start]

        # O(imk^2dn)
        while len(clusters) < self.k:
            pick = random.randint(0, len(clusters)-1)
            cluster = clusters[pick]
            if len(cluster.cluster) > 1:
                # O(imkdn)
                clusters = clusters + self.best_bisection(cluster, iterations)
                del clusters[pick]
            else:
                pass

        return clusters


def k_means(values, k, bisecting=False):
    '''
    Mimics the standard k_means function in the sklearn library
    :param values: the values where kmeans is executed upon
    :param k: the amount of clusters kmeans should make
    :param bisecting: should bisecting kmeans be used instead of kmeans
    :return: a triple with centroids, clustering and the SSE of the created clustering
    '''
    kmeans = Kmeans(values, k)
    if bisecting:
        clustering = kmeans.apply_bisecting()
        for i in range(0, len(clustering)):
            clustering[i].id = i
        centroids = np.array([x.centroid_values for x in clustering])
        clustering = np.array([kmeans.best_centroid(clustering, value).id for value in values])
    else:
        centroids, clustering = kmeans.apply()
    return centroids, clustering, kmeans.sum_squared_error(centroids, values, clustering)
