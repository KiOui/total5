import logging


class Centroid:
    """Centroid object"""

    def __init__(self, centroid_values: [float], distance_algorithm, id):
        '''
        Initializer for the Centroid object
        :param centroid_values: The coordinates of the centroid
        :param distance_algorithm: The distance algorithm to be used
        :param id: The identifier of this centroid
        '''
        self.dimension = len(centroid_values)
        self.centroid_values = centroid_values
        self.distance_algorithm = distance_algorithm
        self.cluster = []
        self.id = id

    def distance_to_point(self, point) -> int:
        '''
        Complexity: O(d)
        Calculates the distance from this centroid to a point
        :param point: The point to where the distance should be calculated for
        :return: The distance, according to the distance algorithm supplied in the constructor, to the point
        '''
        if len(point) != self.dimension:
            logging.error("Length of point is different than length of centroid")
            raise Exception("Properties not equal")
        return self.distance_algorithm.get_distance(self.centroid_values, point)

    def add_to_centroid(self, value):
        '''
        Complexity: O(1)
        Adds a point to a centroid
        :param value: The point to be added
        :return: None
        '''
        self.cluster = self.cluster + [value]

    def recalculate_center(self):
        '''
        Complexity: O(dn)
        Recalculates the center of this centroid, according to all points in the self.cluster variable
        :return: The new center calculated by this function
        '''
        return [sum([x[dimension] for x in self.cluster])/len(self.cluster) for dimension in range(0, self.dimension)]

    def erase_cluster(self):
        '''
        Erases the self.cluster variable
        :return: None
        '''
        self.cluster = []

    def __str__(self):
        '''
        To string method
        :return: This centroid in string form
        '''
        return "Centroid with " + str(self.centroid_values)

    def __repr__(self):
        '''
        List string method
        :return: self.__str__()
        '''
        return self.__str__()

    def __lt__(self, other):
        if other.dimension != self.dimension:
            raise Exception("Dimensions of centroids are different!")

        for x in range(0, self.dimension):
            if other.centroid_values[x] != self.centroid_values[x]:
                return self.centroid_values[x] < other.centroid_values[x]
        return False

    def __eq__(self, other):
        if other.dimension != self.dimension:
            raise Exception("Dimensions of centroids are different!")

        for x in range(0, self.dimension):
            if other.centroid_values[x] != self.centroid_values[x]:
                return False

        return True

    def __hash__(self):
        return hash(tuple(self.centroid_values))
