#!/usr/bin/env python3

import socket
import struct

def parse_ip(packet):
	header_length_in_bytes = (packet[0] & 0x0F) * 4
	header = packet[:header_length_in_bytes]
	
	total_length = header[2] + header[3]
	protocol = header[9]
	source_ip = socket.inet_ntoa(header[12:16])

	destination_ip = socket.inet_ntoa(header[16:20])

	data = packet[header_length_in_bytes:]
	return header_length_in_bytes, header, data, total_length, protocol, source_ip, destination_ip

def parse_udp(packet):
	header_length = 8
	header = packet[:header_length]
	data = packet[header_length:]
	(source_port, dest_port, data_length, checksum) = struct.unpack("!HHHH", header)
	return source_port, dest_port, data_length, checksum, data

def parse_ethernet(packet):
	type_code = None
	data = None
	header = packet[:14]
	destination_addr = "%x:%x:%x:%x:%x:%x" % struct.unpack("BBBBBB", header[0:6])
	source_addr = "%x:%x:%x:%x:%x:%x" % struct.unpack("BBBBBB", header[6:12])
	number = b'\x81\x00'
	if header[12:14] == number:
		header = header+packet[14:16]
		type_code = header[14:16]
		data = packet[16:]
	else:
		type_code = header[12:14]
		data = packet[14:]
	return type_code, source_addr, destination_addr, data
	

def main():
	s = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(0x0003))

	while True:
		(received, _) = s.recvfrom(size)
		type_code, eth_src, eth_dest, data = parse_ethernet(received)
		print("Ethernet Source: {}\nEthernet Destination: {}\nEthernet Type: {}".format(eth_src, eth_dest, type_code))
		if type_code != b'\x08\x00':
			print("")
			continue
		_, _, data, total_length, protocol, source_ip, destination_ip = parse_ip(data)
		print("Source IP: {}\nDestination IP: {}\nProtocol: {}\nTotal length: {}\n".format(source_ip, destination_ip, protocol, total_length))
		if protocol != 17:
			print("")
			continue
		source_port, dest_port, data_length, checksum, data = parse_udp(data)
		print("Source Port: {}\nDestination Port: {}\nData length: {}\nChecksum: {}\nData: {}\n".format(source_port, dest_port, data_length, checksum, len(data)))

	s.close()

if __name__ == "__main__":
	size = 65565
	main()

