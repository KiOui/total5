#!/usr/bin/env python3

import socket
import struct

def parse_ip(packet):
	header_length_in_bytes = (packet[0] & 0x0F) * 4
	header = packet[:header_length_in_bytes]
	
	total_length = header[2] + header[3]
	protocol = header[9]
	source_ip = socket.inet_ntoa(header[12:16])

	destination_ip = socket.inet_ntoa(header[16:20])

	data = packet[header_length_in_bytes:]
	return header_length_in_bytes, header, data, total_length, protocol, source_ip, destination_ip

def parse_udp(packet):
	header_length = 8
	header = packet[:header_length]
	data = packet[header_length:]
	(source_port, dest_port, data_length, checksum) = struct.unpack("!HHHH", header)
	return source_port, dest_port, data_length, checksum, data

def main():
	s = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_UDP)

	while True:
		(received, (_, _)) = s.recvfrom(size)
		_, _, data, total_length, protocol, source_ip, destination_ip = parse_ip(received)
		source_port, dest_port, data_length, checksum, data = parse_udp(data)
		print("Source IP: {}\nDestination IP: {}\nProtocol: {}\nTotal length: {}\nSource Port: {}\nDestination Port: {}\nData length: {}\nChecksum: {}\nData: {}\n".format(source_ip, destination_ip, protocol, total_length, source_port, dest_port, data_length, checksum, len(data)))

	s.close()

if __name__ == "__main__":
	size = 65565
	main()

