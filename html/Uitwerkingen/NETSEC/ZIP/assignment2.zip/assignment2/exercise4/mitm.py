#!/usr/bin/env python3

# This program uses the hexdump module. Install it through your distribution's
# package manager (python-hexdump on arch), through pip (pip3 install hexdump)
# or download it at https://pypi.python.org/pypi/hexdump Alternatively, remove
# all calls to hexdump.hexdump(), and print that data some other way.

import hexdump
import socket
import struct
import binascii

SOURCE_IP = "192.168.84.60"
ipbytes = socket.inet_aton(SOURCE_IP)
SOURCE_MAC = "9c:ad:97:cf:0b:13"
macbytes_source = binascii.unhexlify(SOURCE_MAC.replace(':', ''))
DEST_MAC = "00:0f:c9:0c:f7:8c"
macbytes_dest = binascii.unhexlify(DEST_MAC.replace(':', ''))

def main():
    s = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(3))
    s.bind(("eth0", 0))
    while True:
        frame, source = s.recvfrom(65565)
        eth_src, eth_dst, eth_type, eth_payload = parse_ethernet(frame)
        if eth_type != 0x0800:  # IP is type 0x0800
            print("Frame with ethernet type {} received; skipping...".format(
                eth_type))
            continue

        (ip_header_length, ip_total_length, ip_protocol, ip_src, ip_dst,
         ip_payload) = parse_ip(eth_payload)

        if ip_protocol != 17:  # UDP is protocol 17
            print("Packet with protocol nr. {} received; skipping...".format(
                ip_protocol))
            continue

        (udp_src_port, udp_dst_port, udp_data_length,
         udp_checksum, udp_payload) = parse_udp(ip_payload)

        print("Source (python): {}".format(source))
        print("Full frame:")
        hexdump.hexdump(frame)
        print("""\nEthernet:
    Src MAC: {} ({})
    Dst MAC: {} ({})
    Type:    {:#06x}""".format(bytes_to_mac(eth_src), eth_src,
                               bytes_to_mac(eth_dst), eth_dst,
                               eth_type))
        print("""IP:
    Header length: {}
    Total length:  {}
    Protocol:      {}
    Src address:   {}
    Dst address:   {}""".format(ip_header_length, ip_total_length,
                                ip_protocol, ip_src, ip_dst))
        print("""UDP:
    Src port:    {}
    Dst port:    {}
    Data length: {}
    Checksum:    {}""".format(udp_src_port, udp_dst_port, udp_data_length,
                              udp_checksum))
        print("Data:")
        hexdump.hexdump(udp_payload)
        print("\n\n")
        
        if (bytes_to_mac(eth_dst) == SOURCE_MAC and ip_dst == SOURCE_IP):
            new_udp = create_udp(udp_src_port, udp_dst_port, udp_data_length)
            ip_header_length_in_bytes = (eth_payload[0] & 0x0F) * 4
            ip_header = eth_payload[:ip_header_length_in_bytes]
            new_ethernet = create_ethernet(eth_src, eth_type)
            modified_payload = modify_payload(udp_payload)
            new_packet = new_ethernet + ip_header + new_udp + modified_payload
            print("Sending this packet:")
            parse(new_packet)
            s.send(new_packet)
        


def modify_payload(payload):
    payload = payload.replace(b"XXXXXXXX", b"4739736X")
    payload = payload.replace(b"YYYYYYYY", b"4708105Y")
    return payload

def create_ethernet(src, type_code):
    ethernet_packet = struct.pack("!6s6sH", macbytes_dest, src, type_code)
    return ethernet_packet

def create_udp(udp_src, udp_dst, udp_data_length):
    udp_packet = struct.pack("!HHHH", udp_src, udp_dst, udp_data_length, 0)
    return udp_packet

def bytes_to_mac(bytesmac):
    return ":".join("{:02x}".format(x) for x in bytesmac)


def parse_ethernet(frame):
    header_length = 14
    header = frame[:header_length]
    dst, src, type_code = struct.unpack("!6s6sH", header)
    if type_code == 0x8100:  # Encountered an 802.1Q tag, compensate.
        header_length = 18
        header = frame[:header_length]
        type_code = struct.unpack("!16xH", header)
    payload = frame[header_length:]
    return src, dst, type_code, payload


def parse_ip(packet):
    header_length_in_bytes = (packet[0] & 0x0F) * 4
    header = packet[:header_length_in_bytes]
    payload = packet[header_length_in_bytes:]
    (total_length, protocol, src, dst) = struct.unpack_from("!2xH5xB2x4s4s",
                                                            header)
    src = socket.inet_ntoa(src)
    dst = socket.inet_ntoa(dst)
    return header_length_in_bytes, total_length, protocol, src, dst, payload


def parse_udp(packet):
    header_length = 8
    header = packet[:header_length]
    payload = packet[header_length:]
    src_port, dst_port, data_length, checksum = struct.unpack("!HHHH", header)
    return src_port, dst_port, data_length, checksum, payload

if __name__ == "__main__":
    main()
