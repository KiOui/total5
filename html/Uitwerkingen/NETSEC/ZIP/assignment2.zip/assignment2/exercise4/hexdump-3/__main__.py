import sys
import hexdump
sys.exit(hexdump.main())
