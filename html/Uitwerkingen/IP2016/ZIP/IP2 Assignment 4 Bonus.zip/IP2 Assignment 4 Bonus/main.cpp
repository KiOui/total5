#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <cassert>


using namespace std;

int next_equal(char a, string source, int s) {
    int sSize = source.size();
    for (int i = s; i < sSize; i++) {
        if (a == source[i]) {
            return s;
        }
    }
    return sSize;
}

bool match(string pattern, string source, int p, int s) {
    int pSize = pattern.size();
    int sSize = source.size();
    if (pSize == p && sSize == s) {
        return true;
    }
    else if (pSize == p && sSize != s) {
        return false;
    }
    else if (pSize != p && sSize == s) {
        return false;
    }
    else {
        if (pattern[p] == source[s]) {
            return match(pattern, source, p+1, s+1);
        }
        else if (pattern[p] == '.') {
            return match(pattern, source, p+1, s+1);
        }
        else {
            if (p == pSize-1) {
                return true;
            }
            else {
                int eq = next_equal(pattern[p+1], source, s);
                return match(pattern, source, p+1, eq);
            }
        }
    }
}

void make_string(string& a, int from) {
    int aSize = a.size();
    if (!(aSize == from)) {
        if (a[from] == '*') {
            if (from < aSize-1) {
                if (a[from+1] == '.') {
                    a[from] = '.';
                    a[from+1] = '*';
                    make_string(a, from+1);
                }
                else if (a[from+1] == '*'){
                    for (int i = from+1;i<aSize-1;i++){
                        a[i] = a[i+1];
                    }
                    a = a.substr(0, aSize-1);
                    make_string(a, from);
                }
                else {
                    make_string(a, from+1);
                }
            }
            else {
                make_string(a, from+1);
            }
        }
        else {
            make_string(a, from+1);
        }
    }
}

int main()
{
    string str1;
    string str2;
    cout << "Eerste string: ";
    cin >> str1;
    cout << "Tweede string: ";
    cin >> str2;
    make_string(str1, 0);
    cout << match(str1, str2, 0, 0);
    return 0;
}
