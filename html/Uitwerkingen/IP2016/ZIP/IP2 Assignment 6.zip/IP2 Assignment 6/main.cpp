#include <cstdlib>
#include <iostream>
#include <vector>
#include <cassert>

using namespace std;

int time;
int space;

/*

Time & Space
Puzzle 1
B: 0, 1
D: 1, 0

Puzzle 2
B: 26, 83
D: 263, 5

Puzzle 3
B: 473, 1526
D: 873, 6

Puzzle 4
B: ?
D: ?
*/

// data structures:
const int WIDTH  = 4 ;                   // WIDTH  > 0
const int HEIGHT = 4 ;                   // HEIGHT > 0
typedef int Cell ;                       // content of slide: not empty: 1 <= value < WIDTH*HEIGHT, empty: value = WIDTH*HEIGHT
const Cell EMPTY = WIDTH*HEIGHT ;        // the empty cell has value WIDTH*HEIGHT

struct Pos
{   int col ;                            // column index (0 <= col < WIDTH)
    int row ;                            // row    index (0 <= row < HEIGHT)
} ;

struct Puzzle
{   Cell board [WIDTH][HEIGHT] ;         // the slides of the puzzle
    Pos open ;                           // the coordinate of the EMPTY cell
} ;

struct Candidate
{
	Puzzle candidate ;
	int parent ;
} ;

bool operator== (Puzzle a, Puzzle b) {
    for (int i = 0;i < HEIGHT;i++) {
        for (int o = 0;o < WIDTH;o++) {
            if (!(a.board[o][i] == b.board[o][i])) {
                return false;
            }
        }
    }
    return true;
}

// challenges:
// puzzle P1 is immediately ready
const Puzzle P1 = {{{ 1, 5, 9,13}
                   ,{ 2, 6,10,14}
                   ,{ 3, 7,11,15}
                   ,{ 4, 8,12,16}
                   }
                  ,{3,3}
                  } ;
// puzzle P2 is solvable in 3 moves
const Puzzle P2 = {{{ 1, 5, 9,16}
                   ,{ 2, 6,10,13}
                   ,{ 3, 7,11,14}
                   ,{ 4, 8,12,15}
                   }
                  ,{0,3}
                  } ;
// puzzle P3 is solvable in 6 moves
const Puzzle P3 = {{{16, 1, 9,13}
                   ,{ 2, 5, 6,10}
                   ,{ 3, 7,11,14}
                   ,{ 4, 8,12,15}
                   }
                  ,{0,0}
                  } ;
// puzzle P4 is solvable in 13 moves
const Puzzle P4 = {{{ 2, 1, 9,13}
                   ,{ 5, 7, 6,10}
                   ,{ 8,16,11,14}
                   ,{ 3, 4,12,15}
                   }
                  ,{2,1}
                  } ;
Puzzle challenge = P1 ;

bool go_north (Puzzle& p)
{/* implement this function */
    return (!(p.open.row == 0));
}

Pos north (Puzzle& p)
{/* implement this function */
    Pos i;
    i.row = p.open.row - 1;
    i.col = p.open.col;
    return i;
}

bool go_south (Puzzle& p)
{/* implement this function */
    return (!(p.open.row == HEIGHT-1));
}

Pos south (Puzzle& p)
{/* implement this function */
    Pos i;
    i.row = p.open.row + 1;
    i.col = p.open.col;
    return i;
}

bool go_west (Puzzle& p)
{/* implement this function */
    return (!(p.open.col == 0));
}

Pos west (Puzzle& p)
{/* implement this function */
    Pos i;
    i.col = p.open.col - 1;
    i.row = p.open.row;
    return i;
}

bool go_east (Puzzle& p)
{/* implement this function */
    return (!(p.open.col == WIDTH-1));
}

Pos east (Puzzle& p)
{/* implement this function */
    Pos i;
    i.col = p.open.col + 1;
    i.row = p.open.row;
    return i;
}

Puzzle move_empty (Puzzle p, Pos next)
{/* implement this function */
    int help = p.board[next.col][next.row];
    p.board[next.col][next.row] = EMPTY;
    p.board[p.open.col][p.open.row] = help;
    p.open = next;
    return p;
}

void printPuzzle(Puzzle p) {
    for (int i = 0; i < HEIGHT; i++) {
        for (int o = 0; o < WIDTH; o++) {
            cout << p.board[o][i] << '\t';
        }
        cout << endl;
    }
    cout << "---------------------------" << endl;
}

bool puzzle_ready (Puzzle& p)
{/* implement this function */
    int counter = 0;
    for (int i = 0; i < HEIGHT; i++) {
        for (int o = 0; o < WIDTH; o++) {
            counter++;
            if (!(p.board[o][i] == counter)) {
                return false;
            }
        }
    }
    return true;
}

bool puzzle_present (vector<Candidate>& c, int i, Puzzle p)
{/* implement this function */
    for (int o = -1; o < c.size(); o ++) {
        if (c[o].candidate == p) {
            return true;
        }
    }
    return false;
}

void show_path (vector<Candidate>& c, int last)
{/* implement this function */
    if (last != -1) {
        show_path(c, c[last].parent);
        cout << endl;
        printPuzzle(c[last].candidate);
    }
}


void tries (vector<Candidate>& c, int i, Pos next)
{
    Puzzle p = c[i].candidate ;
	Puzzle newp = move_empty (p, next) ;
	Candidate newc = {newp,i} ;
	if (!puzzle_present(c,i,newp))
        c.push_back (newc) ;
}

void solve (vector<Candidate>& c)
{
    int i = 0 ;
    while (i < c.size() && !puzzle_ready (c[i].candidate))
    {
		Puzzle p = c[i].candidate ;
        if (go_north (p)) 	tries (c, i, north(p)) ;
        if (go_south (p)) 	tries (c, i, south(p)) ;
        if (go_west  (p)) 	tries (c, i, west (p)) ;
        if (go_east  (p)) 	tries (c, i, east (p)) ;
        i++ ;
    }
    if (i < c.size()) {
    	show_path (c, i) ;
    }
    time = i;
}


void solve (Puzzle start)
{
    vector<Candidate> c ;
	Candidate first = {start,-1} ;
	c.push_back(first) ;
    solve ( c );
    space = c.size();
}

void solve(vector<Candidate>& c, int& bestPuzzleIndex, int& maximum, int currentDepth, int i) {
    time++;
    if (puzzle_ready(c[i].candidate)) {
        if (bestPuzzleIndex == -1|| c[i].parent < c[bestPuzzleIndex].parent) {
            bestPuzzleIndex = i;
            maximum = currentDepth;
        }
    }
    else if (currentDepth < maximum) {
        Puzzle p = c[i].candidate;
        if (go_north (p)) {
            tries(c, i, north(p));
            solve(c, bestPuzzleIndex, maximum, currentDepth+1, c.size()-1);
        }
        if (go_south (p)) {
            tries(c, i, south(p));
            solve(c, bestPuzzleIndex, maximum, currentDepth+1, c.size()-1);
        }
        if (go_west (p)) {
            tries(c, i, west(p));
            solve(c, bestPuzzleIndex, maximum, currentDepth+1, c.size()-1);
        }
        if (go_east (p)) {
            tries(c, i, east(p));
            solve(c, bestPuzzleIndex, maximum, currentDepth+1, c.size()-1);
        }
    }
    space = maximum;
}

void solveDepth (Puzzle start)
{
    vector<Candidate> c ;
	Candidate first = {start,-1} ;
	c.push_back(first) ;
	int bestSolution = -1;
	int maximum = 13;
    solve (c, bestSolution, maximum, 0, 0);
    show_path(c, bestSolution);
}



int main ()
{
    Puzzle start = P2;
    solveDepth(start);
    cout << time << " " << space << endl;
    return 0 ;
}
