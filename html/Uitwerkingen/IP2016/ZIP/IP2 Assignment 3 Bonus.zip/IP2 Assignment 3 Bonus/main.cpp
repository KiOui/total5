#include <iostream>
#include <vector>
#include <stdlib.h>
#include <assert.h>
#include <string>
#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <cassert>
#define NDEBUG

using namespace std;

int gCounter = 0;

struct Length
{
	int minutes;							// #minuten  (0..)
	int seconds;							// #seconden (0..59)
};

struct Track
{
	string artist;                          // naam van uitvoerende artiest
	string cd;                              // titel van cd
	int    year;                            // jaar van uitgave
	int    track;							// nummer van track
	string title;                           // titel van track
	string tags;                            // tags van track
	Length time;							// lengte van track
	string country;                         // land van artiest
};

typedef vector<Track> MuziekDB;
MuziekDB Heap;

bool operator< (const Length& a, const Length& b){
    if ((a.minutes * 60 + a.seconds) < (b.minutes * 60 + b.seconds)) {
        return true;
    }
    else {
        return false;
    }
}

bool operator== (const Length& a, const Length& b){
    return (a.minutes == b.minutes && a.seconds == b.seconds);
}

bool operator<(const Track& a, const Track& b)
{
    gCounter++;
    if (!(a.time == b.time)) {
        return a.time < b.time;
    }
   if (a.artist != b.artist){
        return a.artist < b.artist;
    }
    else if (a.title != b.title){
        return a.title < b.title;
    }
    else if (a.cd != b.cd){
        return a.cd < b.cd;
    }
    return false;
}

bool operator==(const Track& a, const Track& b)
{
    gCounter++;
    return (a.time == b.time && a.artist == b.artist && a.title == b.title && a.cd == b.cd);
}

bool operator>(const Track& a, const Track& b)
{
	return b < a ;
}

bool operator<=(const Track& a, const Track& b)
{
	return !(b < a) ;
}

bool operator>=(const Track& a, const Track& b)
{
	return b <= a ;
}

istream& operator>> (istream& in, Length& lengte)
{// Preconditie:
    assert (true) ;
/*  Postconditie:
    de waarde van lengte is ingelezen uit in: eerst minuten, daarna ':', daarna seconden.
*/
    char colon ;
    in >> lengte.minutes >> colon >> lengte.seconds ;
    return in ;
}

ostream& operator<< (ostream& out, const Length lengte)
{
    out << lengte.minutes << ':' ;
    if (lengte.seconds < 10)
        out << '0' ;
    out << lengte.seconds ;
    return out ;
}

istream& operator>> (istream& in, Track& track)
{
    string str;
    string artist;
    getline(in, artist);
    if (artist == "") {
        track.artist = "%%%";
    }
    else {
        track.artist = artist;
        getline(in, track.cd);
        in >> track.year;
        getline(in, str);
        in >> track.track;bool operator==(const Track& a, const Track& b);
        getline(in, str);
        getline(in, track.title);
        getline(in, track.tags);
        in >> track.time;
        getline(in, str);
        getline(in, track.country);
        getline(in, str);
    }
    return in;
}


ostream& operator<< (ostream& out, const Track track)
{
    out << track.artist << " " << track.cd << " [" << track.track << "] (" << track.time << ")" ;
    return out ;
}

int lees_liedjes(istream& in, MuziekDB& mDB) {
    bool cont = true;
    Track newTrack;
    string str;

    while (cont) {
        in >> newTrack;
        if (newTrack.artist == "%%%") {
            cont = false;
        }
        else {
            mDB.push_back(newTrack);
        }
    }
    cout << "Tracks imported: " << mDB.size() << endl;
    return mDB.size();
}


int lees_bestand (string bestandnaam)
{
    ifstream nummersDBS (bestandnaam.c_str());
    if (!nummersDBS)
    {
        cout << "Kon '" << bestandnaam << "' niet openen." << endl;
        return -1;
    }
    cout << "Lees '" << bestandnaam << "' in." << endl;
	int aantal = lees_liedjes (nummersDBS, Heap);
	nummersDBS.close();
	return aantal;
}

void toon_MuziekDB (MuziekDB liedjes, int aantalLiedjes)
{
    for (int i = 0 ; i < aantalLiedjes; i++)
        cout << i+1 << ". " << liedjes[i] << endl ;
}















int push_up(MuziekDB& heap, int x) {
    assert(heap.size()>0 && x>0);

    Track help = heap[x];
    heap[x] = heap[(x-1)/2];
    heap[(x-1)/2] = help;
    x = (x-1)/2;
    return x;
    /* de functie wisselt een child node met zijn parent node
    */
}

void build_heap (MuziekDB& heap) {
    assert(heap.size()>0);

    int length = heap.size();
    for (int i = 0; i < length; i++) {
        int index = i;
        while (heap[index] > heap[(index-1)/2] && index != 0) {
            index = push_up(heap, index);
        }
    }
    /*deze functie controleert of de meegegeven vector gesorteerd is, en maakt vervolgens een heap van die vector
    */
}

bool checkHeap(MuziekDB& heap) {
    assert(heap.size()>0);

    int length = heap.size();
    for (int i = 0; i < length && 2*i + 1 < length; i++) {
        if (heap[i] < heap[2*i + 1]) {
            return false;
        }
    }
    return true;
    /*deze functie returnt true als de input een heap is
    */
}

void swap_heap(MuziekDB& heap, int i, int o) {
    assert(i>=0 && o>=0 && i<heap.size() && o<heap.size());

    Track help = heap[o];
    heap[o] = heap[i];
    heap [i] = help;
    /*deze functie wisselt elementen i en o van plaats in de heap
    */
}

void push_down(MuziekDB& heap, int length) {
    assert(heap.size()>0);

    int i = 0;
    bool cont = true;
    while (cont) {
        if (2*i+1 < length) {
            if (heap[i] < heap[2*i+1] || heap[i] < heap[2*i+2]) {
                if (heap[2*i+1] >= heap[2*i+2]) {
                    swap_heap(heap, i, 2*i+1);
                    i = 2*i+1;
                }
                else {
                    swap_heap(heap, i, 2*i+2);
                    i = 2*i+2;
                }
            }
            else {
                cont = false;
            }
        }
        else if (2*i+1 == length) {
            if (heap[i] < heap[2*i+1]) {
                swap_heap(heap, i, 2*i+1);
                i = 2*i+1;
            }
            else {
                cont = false;
            }
        }
        else {
            cont = false;
        }
    }
    /*deze functie zet een parent node op de goede plek onder een child node
    */
}

void pick_heap(MuziekDB& heap) {
    assert(heap.size()>0);

    int length = heap.size();
    while (length != 0) {
        swap_heap(heap, 0, length-1);
        length--;
        push_down(heap, length-1);
    }
    /*deze functie sorteert een ongesorteerde heap
    */
}

bool checkVector(MuziekDB heap) {
    assert(true);

    int length = heap.size();
    for (int i = 0; i < length-1; i++) {
        if (heap[i] > heap[i+1]) {
            return false;
        }
    }
    return true;
    /*deze functie controleert of de meegegeven vector gesorteerd is.
    */
}

void copy_vector(MuziekDB& source, MuziekDB& dest, int amount)
{
    for(int i = 0; i < amount; i++)
    {
        dest.push_back(source[i]);
    }
}

int main()
{
    lees_bestand("Nummers.txt");
    MuziekDB dest;
    for (int i = 99; i < Heap.size(); i += 100) {
        gCounter = 0;
        dest.erase(dest.begin(), dest.end());
        copy_vector(Heap, dest, i);
        build_heap(dest);
        pick_heap(dest);
        while (gCounter != 0) {
            if (gCounter > 100000) {
                cout << "*";
                gCounter = gCounter - 100000;
            }
            else {
                cout << ".";
                gCounter = 0;
            }
        }
        cout << endl;
        //cout << gCounter << endl;
    }


    /*build_heap(Heap);
    cout << "------------------------------" << endl;
    if (checkHeap(Heap)) {
        cout << "Heap gemaakt!" << endl;
    }
    else {
        cout << "Heap maken mislukt!" << endl;
        return -1;
    }
    cout << endl;
    pick_heap(Heap);
    cout << "------------------------------" << endl;
    if (checkVector(Heap)) {
        cout << "Vector gesorteerd!" << endl;
    }
    else {
        cout << "Vector sorteren mislukt!" << endl;
        return -1;
    }
    cout << endl;
    toon_MuziekDB(Heap,Heap.size());
    cout << gCounter << endl;*/
    return 0;
}

//Part 2:
/* De hoeveelheid vergelijkingen bij Heap sort zijn er veel minder dan bij de andere
sorteermethoden. Bij heap sort is dat namelijk zo rond de 100000 vergelijkingen terwijl het
bij de andere methoden meer dan 1 miljoen vergelijkingen was.
*/

//Part 3
/* Er zijn heel weinig vergelijkingen (onder 100000), daarom wordt er steeds een . in de console
geprint. Op een gegeven moment wordt de vector zo groot dat er boven 100000 vergelijkingen nodig zijn
dus daarna wordt een * en een . geprint in de console.
*/

