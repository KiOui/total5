#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <cassert>

using namespace std;

struct Product {
    int price;
    string name;
};

struct Wishlist {
    int budget;
    vector<string> wishes;
};

typedef vector<Product> Giftstore;
Giftstore gStore;
Wishlist best;

istream& operator>> (istream& in, Product& product) {
    string str;
    in >> product.price;
    cout << product.price << endl;
    getline(in, product.name);
    return in;
}

ostream& operator<< (ostream& out, const Product product) {
    out << product.price << " " << product.name;
    return out;
}



void readStore (Giftstore& gStore) {
    ifstream file ("giftstore.txt");
    cout << "Reading Giftstore.txt..." << endl;
    Product newProduct;
    string str;
    while (file && file.is_open()) {
        file >> newProduct.price;
        getline(file, str);
        newProduct.name = str.substr(1,str.length()-1);
        gStore.push_back(newProduct);
    }
    gStore.pop_back();
	file.close();
}

void printStore(Giftstore gStore) {
    int gStoreSize = gStore.size();
    for (int i = 0; i < gStoreSize; i ++) {
        cout << gStore[i] << endl;
    }
}

void importWishlist(string wishlistName, Wishlist& newWishlist) {
    ifstream wishlistIn (wishlistName.c_str());
    cout << "Reading " << wishlistName << "..." << endl;
    string str;
    wishlistIn >> newWishlist.budget;
    getline(wishlistIn, str);
    vector<string> wishesDummy;
    while (wishlistIn && wishlistIn.is_open()) {
        getline(wishlistIn, str);
        wishesDummy.push_back(str);
    }
    newWishlist.wishes = wishesDummy;
}

void printWishlist(Wishlist wishlist) {
    cout << "Budget: " << wishlist.budget << "." << endl;
    for (int i = 0; i <= wishlist.wishes.size()-1;i++) {
        cout << wishlist.wishes[i] << endl;
    }
}

void makeStore(Giftstore& store, Wishlist wishlist) {
    string str;
    for (int i = 0; i < wishlist.wishes.size(); i++) {
        str = wishlist.wishes[i];
        for (int o = 0; o < gStore.size(); o++) {
            if (str == gStore[o].name) {
                store.push_back(gStore[o]);
            }
        }
    }
}

void gifts (Giftstore store, int a, Wishlist current) {
    if (current.budget < 0) {
        return;
    }
    else if (a >= store.size()) {
        return;
    }
    else {
        if (current.budget < best.budget) {
            Wishlist withA = current;
            best = current;
            withA.budget = withA.budget - store[a].price;
            withA.wishes.push_back(store[a].name);
            printWishlist(withA);
            gifts(store, a+1, withA);
            gifts(store, a+1, current);
        }
        else {
            Wishlist withA = current;
            withA.budget = withA.budget - store[a].price;
            withA.wishes.push_back(store[a].name);
            gifts(store, a+1, withA);
            gifts(store, a+1, current);
        }
    }
}

int main()
{
    readStore(gStore);
    cout << "---------------------------" << endl;
    string textFile;
    cout << "Please enter the name of the text file to import from: ";
    cin >> textFile;
    Wishlist currentWishlist;
    importWishlist(textFile, currentWishlist);
    Giftstore wishStore;
    makeStore(wishStore, currentWishlist);
    Wishlist a;
    best.budget = currentWishlist.budget;
    a.budget = currentWishlist.budget;
    gifts(wishStore, 0, a);
    cout << "---------------------------" << endl;
    printWishlist(best);
    return 0;
}
