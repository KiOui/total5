#include <iostream>
#include <fstream>
#include <cassert>
#include <windows.h>
#include "cursor.h"


using namespace std;

enum Cell {Dead=0, Live};                         // a cell is either Dead or Live (we use the fact that dead = 0 and live = 1)

const char DEAD             = '.' ;               // the presentation of a dead cell (both on file and screen)
const char LIVE             = '*' ;               // the presentation of a live cell (both on file and screen)
const int NO_OF_ROWS        = 40 ;                // the number of rows (height) of the universe (both on file and screen)
const int NO_OF_COLUMNS     = 60 ;                // the number of columns (width) of the universe (both on file and screen)
const int ROWS              = NO_OF_ROWS    + 2 ; // the number of rows in a universe array, including the 'frame' of dead cells
const int COLUMNS           = NO_OF_COLUMNS + 2 ; // the number of columns in a universe array, including the 'frame' of dead cells

const int MAX_FILENAME_LENGTH = 80 ;              // the maximum number of characters for a file name (including termination character)

//  Part 1: one-dimensional arrays
bool enter_filename (char filename [MAX_FILENAME_LENGTH])
{
    //Pre:
    assert(true);
    //Post:
    /*array filename is filled with characters from the text that is entered.
    When the text is longer than 80 characters, this function returns false. Otherwise it returns true.*/
    char character;
    cout << "Please enter a filename to be read: ";
    character = cin.get();
    cout << "Filename entered: ";
    for (int i=0; i<MAX_FILENAME_LENGTH && !(character == '\n'); i++) {
        cout << character;
        filename[i] = character;
        character = cin.get();
    }
    cout << endl;
    if (!(character == '\n')) {
        return false;
    }
    else {
        return true;
    }
}

//  Part 2: setting the scene
void clear_universe(Cell universe [ROWS][COLUMNS]) {
    //Pre:
    assert(true);
    //Post:
    //Clears the whole universe so that all cells are dead
    for (int i=0;i<ROWS;i++) {
        for (int o=0;o<COLUMNS;o++) {
            universe [i] [o] = Dead;
        }
    }
}


bool read_universe_file (ifstream& inputfile, Cell universe [ROWS][COLUMNS])
{
    //Pre:
    assert(inputfile.is_open());
    //Post:
    //Fills the universe with the data in the file entered, returns true when the file contains only * and . (readable characters).
    char input;
    clear_universe(universe);
    for (int i=1;i<=ROWS-2;i++) {
        for (int o=1;o<=COLUMNS-2;o++) {
            inputfile >> input;
            if (input == DEAD) {
                universe [i] [o] = Dead;
            }
            else if (input == LIVE) {
                universe [i] [o] = Live;
            }
            else {
                return false;
            }
        }
    }
    return true;
}

void show_universe (Cell universe [ROWS][COLUMNS])
{
    //Pre:
    assert(true);
    //Post:
    //Prints the universe entered, prints * for every living cell, prints . for every dead cell.
    for (int i=0;i<=ROWS-1;i++) {
        for (int o=0; o<=COLUMNS-1; o++) {
            if (universe [i] [o] == Dead) {
                cout << '.';
            }
            else if (universe [i] [o] == Live) {
                cout << '*';
            }
        }
        cout << endl;
    }
}

//  Part 3: the next generation
int checkNeighbors(Cell now [ROWS] [COLUMNS],int i, int o) {
    //Pre:
    assert(i>0 && i<=ROWS-2);
    assert(o>0 && o<=COLUMNS-2);
    //Post:
    //returns the amount of neighboring alive cells.
    int counter = 0;
    if (now[i][o] == Live) {
        counter--;
    }
    for (int a=-1;a<2;a++) {
        for (int b=-1;b<2;b++) {
            if (now [i+a] [o+b] == Live) {
                counter ++;
            }
        }
    }
    return counter;
}

void next_generation (Cell now [ROWS][COLUMNS], Cell next [ROWS][COLUMNS])
{
    //Pre:
    assert(true);
    //Post:
    //Calculates the next generation of a given universe with the constraints in the exercise.
    int neighbors;
    clear_universe(next);
    for (int i=1;i<=ROWS-2;i++) {
        for (int o=1; o<=COLUMNS-2;o++) {
            neighbors = checkNeighbors(now, i, o);
            if (now [i] [o] == Live) {
                if (neighbors < 2) {
                    next [i] [o] = Dead;
                }
                else if (neighbors == 2 || neighbors == 3) {
                    next [i] [o] = Live;
                }
                else {
                    next [i] [o] = Dead;
                }
            }
            else {
                if (neighbors == 3) {
                    next [i] [o] = Live;
                }
                else {
                    next [i] [o] = Dead;
                }
            }
        }
    }
}

void newToOld(Cell universe [ROWS] [COLUMNS], Cell universeNext [ROWS] [COLUMNS]) {
    //Pre:
    assert(true);
    //Post:
    //Sets the universeNext array to the universe array
    //In other words: universe = universeNext
    for (int i=0; i<ROWS;i++) {
        for (int o=0; o<COLUMNS;o++) {
            universe [i] [o] = universeNext [i] [o];
        }
    }
}

void animation(int times, Cell universe [ROWS] [COLUMNS], Cell universeNext [ROWS] [COLUMNS]) {
    //Pre:
    assert (times > 0);
    //Post:
    //Prints all the generations that the user wanted to see.
    for (int i = 1; i<=times;i++) {
        Sleep(500);
        cls();
        cout << "Generation: " << i << endl;
        next_generation(universe, universeNext);
        newToOld(universe, universeNext);
        show_universe(universe);
    }
}

int main ()
{
    char fileName[MAX_FILENAME_LENGTH];
    int times;
    if (!enter_filename(fileName)) {
        cout << "Filename was invalid (max 80 char)." << endl;
        return -1;
    }
    ifstream file;
    file.open(fileName);
    if (!file.is_open()) {
        cout << "File not opened successfully!" << endl;
        return -1;
    }
    Cell universeBefore[ROWS][COLUMNS];
    Cell universeNext [ROWS][COLUMNS];
    if (!read_universe_file(file, universeBefore)) {
        cout << "Universe file could not be read successfully, please look for errors in the console." << endl;
        return -1;
    }
    cout << "Please enter the amount of generations to be calculated: ";
    cin >> times;
    cout << "\n\nUniverse from file:" << endl;
    show_universe(universeBefore);
    animation(times, universeBefore, universeNext);
    cout << endl << endl;
    for (int i = 0; i< times; i++) {
        cout << "-----";
    }
    cout << endl << "De lengte van de streep die hier is geprint is gelijk aan 5 keer het aantal generaties." << endl;
    file.clear();
    file.close();
    return 1;
}
