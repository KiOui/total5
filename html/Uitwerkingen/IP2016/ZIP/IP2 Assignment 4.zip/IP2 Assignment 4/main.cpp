#include <iostream>
#include <vector>
#include <string>
#include <assert.h>
#include <fstream>


using namespace std;


//BESTANDEN VAN VORIGE OPDRACHT:

int globalCounter;
struct Length
{
	int minutes;							// #minuten  (0..)
	int seconds;							// #seconden (0..59)
};

struct Track
{
	string artist;                          // naam van uitvoerende artiest
	string cd;                              // titel van cd
	int    year;                            // jaar van uitgave
	int    track;							// nummer van track
	string title;                           // titel van track
	string tags;                            // tags van track
	Length time;							// lengte van track
	string country;                         // land van artiest
};

typedef vector<Track> MuziekDB;
MuziekDB mDB;

bool operator< (const Length& a, const Length& b){
    if ((a.minutes * 60 + a.seconds) < (b.minutes * 60 + b.seconds)) {
        return true;
    }
    else {
        return false;
    }
}

bool operator== (const Length& a, const Length& b){
    return (a.minutes == b.minutes && a.seconds == b.seconds);
}

bool operator<(const Track& a, const Track& b)
{
    if (!(a.time == b.time)) {
        return a.time < b.time;
    }
   if (a.artist != b.artist){
        return a.artist < b.artist;
    }
    else if (a.title != b.title){
        return a.title < b.title;
    }
    else if (a.cd != b.cd){
        return a.cd < b.cd;
    }
    return false;
}

bool operator==(const Track& a, const Track& b)
{
    return (a.time == b.time && a.artist == b.artist && a.title == b.title && a.cd == b.cd);
}

bool operator>(const Track& a, const Track& b)
{
	return b < a ;
}

bool operator<=(const Track& a, const Track& b)
{
	return !(b < a) ;
}

bool operator>=(const Track& a, const Track& b)
{
	return b <= a ;
}

istream& operator>> (istream& in, Length& lengte)
{// Preconditie:
    assert (true) ;
/*  Postconditie:
    de waarde van lengte is ingelezen uit in: eerst minuten, daarna ':', daarna seconden.
*/
    char colon ;
    in >> lengte.minutes >> colon >> lengte.seconds ;
    return in ;
}

ostream& operator<< (ostream& out, const Length lengte)
{
    out << lengte.minutes << ':' ;
    if (lengte.seconds < 10)
        out << '0' ;
    out << lengte.seconds ;
    return out ;
}

istream& operator>> (istream& in, Track& track)
{
    string str;
    string artist;
    getline(in, artist);
    if (artist == "") {
        track.artist = "%%%";
    }
    else {
        track.artist = artist;
        getline(in, track.cd);
        in >> track.year;
        getline(in, str);
        in >> track.track;
        getline(in, str);
        getline(in, track.title);
        getline(in, track.tags);
        in >> track.time;
        getline(in, str);
        getline(in, track.country);
        getline(in, str);
    }
    return in;
}


ostream& operator<< (ostream& out, const Track track)
{
    out << track.artist << " " << track.cd << " [" << track.track << "] (" << track.time << ")" ;
    return out ;
}

struct Slice
{
	int from ; 	// 0    <= frombool operator==(const Track& a, const Track& b)
	int to ; 	// from <= to
} ;

Slice mkSlice (int from, int to)
{
//	pre-condition:
	assert (0 <= from && from <= to);
	Slice s = { from, to } ;
	return s ;
}

bool valid_slice (Slice s)
{
	return 0 <= s.from && s.from <= s.to ;
}


int lees_liedjes(istream& in, MuziekDB& mDB) {
    bool cont = true;
    Track newTrack;
    string str;

    while (cont) {
        in >> newTrack;
        if (newTrack.artist == "%%%") {
            cont = false;
        }
        else {
            mDB.push_back(newTrack);
        }
    }
    cout << "Tracks imported: " << mDB.size() << endl;
    return mDB.size();
}


int lees_bestand (string bestandnaam)
{
    ifstream nummersDBS (bestandnaam.c_str());
    if (!nummersDBS)
    {
        cout << "Kon '" << bestandnaam << "' niet openen." << endl;
        return -1;
    }
    cout << "Lees '" << bestandnaam << "' in." << endl;
	int aantal = lees_liedjes (nummersDBS, mDB);
	nummersDBS.close();
	return aantal;
}

void toon_MuziekDB (MuziekDB liedjes, int aantalLiedjes)
{
    for (int i = 0 ; i < aantalLiedjes; i++)
        cout << i+1 << ". " << liedjes[i] << endl ;
}

void swap (MuziekDB& mDB, int  i, int  j )
{
//	pre-condition:
	assert ( i >= 0 && j >= 0 ) ;	// ... and i < size of array
						            // ... and j < size of array
// Post-condition: array[i] = old array[j] and array[j] = old array[i]
	const Track help = mDB [i];
	mDB [i] = mDB[j] ;
	mDB [j] = help;
}
//EINDE VAN BESTANDEN VAN VORIGE OPDRACHT
//---------------------------------------------------------------------//


//Power functions:
int naivePower(double x, int n) {
    //Pre conditions:
    assert(n>=0);
    //Post conditions:
    /*X^n*/

    if (n == 0) {
        return 1;
    }
    else {
        return x * naivePower(x, n-1);
    }
}

int power(double x, int n) {
    //Pre conditions:
    assert(n>=0);
    //Post conditions:
    /*X^n*/

    if (n == 0) {
        return 1;
    }
    else if (n%2 == 1) {
        int help = power(x, (n-1)/2);
        return x * help * help;
    }
    else {
        int help = power(x, n/2);
        return help * help;
    }
}


//Selection sort:
int smallest_value_at ( MuziekDB& mDB, Slice s )
{
//	pre-condition:
	assert (valid_slice (s)) ;	// ... and s.to < size (s)
//	Post-condition: s.from <= result <= s.to and array[result] is
//	the minimum value of array[s.from] .. array[s.to]
    int sizeVector = mDB.size();
    if (sizeVector-1 == s.from) {
        return sizeVector-1;
    }
    else {
        int smallest = smallest_value_at(mDB, mkSlice(s.from+1, s.to));
        if (mDB[s.from] <= mDB[smallest]) {
            return s.from;
        }
        else {
            return smallest;
        }
    }
}

void selection_sort (MuziekDB& mDB, int unsorted )
{
    //Pre conditions:
    int vectorSize = mDB.size();
    assert(unsorted > 0 && unsorted < vectorSize);
    //Post conditions:
    /*De MuziekDB mDB is gesorteerd*/

    int sizeVector = mDB.size();
    if (!(unsorted == sizeVector-1)) {
        int smallest = smallest_value_at(mDB, mkSlice(unsorted, mDB.size()-1));
        swap(mDB, unsorted, smallest);
        selection_sort(mDB, unsorted+1);
    }
}



//Toren van Hanoi:
typedef vector<int> Pillar;

Pillar Brass;
Pillar Silver;
Pillar Gold;

void printPillars(Pillar first, Pillar second, Pillar third) {
    //Pre conditions:
    assert(true);
    //Post conditions:
    /*Print de drie ingegeven Pillars naar de console */
    cout << "Brass  : ";
    int firstSize = first.size();
    int secondSize = second.size();
    int thirdSize = third.size();
    for (int i = 0; i < firstSize; i++) {
        cout << first[i] << " ";
    }
    cout << endl;
    cout << "Silver : ";
    for (int i = 0; i < secondSize; i++) {
        cout << second[i] << " ";
    }
    cout << endl;
    cout << "Gold   : ";
    for (int i = 0; i < thirdSize; i++) {
        cout << third[i] << " ";
    }
    cout << endl;
    cout << "----------" << endl;
}

void transport_disc (int n, Pillar& from, Pillar& to) {
    //Pre conditions:
    assert(n > 0 && &from != &to);
    //Post conditions:
    /*Deze functie verplaatst n van pillar from naar pillar to*/
    from.pop_back();
    to.push_back(n);
    //printPillars(Brass, Silver, Gold);
    globalCounter++;

}

void transport (int n, Pillar& from, Pillar& via, Pillar& to)
{
    // Pre-condition:
    assert (n > 0);
    assert (&from != &via && &via != &to && &to != &from);
    // Post-condition: all top n discs of pillar from are on pillar to
    if (n == 1) {
        transport_disc (n, from, to);
    }
    else {
        transport (n-1, from, to, via);
        transport_disc (n, from, to);
        transport (n-1, via, from, to);
    }
}

void makePillar(int amount, Pillar& pillarVector) {
    //Pre conditions:
    assert(amount >= 0);
    //Post conditions:
    /*De pillar is gevuld met waarden vanaf amount tot 1*/
    for (int i = 0; i < amount; i++) {
        pillarVector.push_back(amount - i);
    }
}

int main()
{
    //UNCOMMENT VOOR MUZIEKDB:
    /*lees_bestand("Nummers.txt");
    //toon_MuziekDB(mDB, mDB.size());
    selection_sort(mDB, 0);
    toon_MuziekDB(mDB, mDB.size());*/

    //Towers van Hanoi:
    cout << "Amount of disks: ";
    int amount;
    cin >> amount;
    globalCounter = 0;
    makePillar(amount, Brass);
    //printPillars(Brass, Silver, Gold);
    transport(amount, Brass, Silver, Gold);
    cout << "Amount of turns: " << globalCounter << "." << endl;

    return 0;
}
