#include <iostream>
#include <fstream>          // for file I/O
#include <cassert>          // for assertion checking

//De key om secret.txt te encrypten is: 2016

using namespace std;

int seed = 0 ;
void initialise_pseudo_random (int r)
{
//  pre-condition:
    assert (r > 0 && r <= 65536) ;
/*  post-condition:
    seed has value r.
*/
    seed = r ;
}

int next_pseudo_random_number ()
{
//  pre-condition:
    assert (seed > 0 && seed <= 65536) ;
/*  post-condition:
    result value > 0 and result value <= 65536 and result value != seed at entry of function
*/
    int seed75 = seed * 75 ;
    int next = (seed75 & 65535) - (seed75 >> 16) ;
    if (next < 0)
        next += 65537 ;
    seed = next ;
    return next ;
}

char rotate_char (char a, int r)
{
//  Pre-condition:
    assert (r >= 0);
//  Post-condition:
//  char a >= 0;
    if (a >= 32) {
        a = (a-32 - (r % (128-32)) + (128-32)) % (128-32)+32;
    }
    return a;

}

int globalCounter;
int bestValue;
void search_words (ifstream& infile, int value) {
//  Pre-condition:
    assert(value >0 && value <=65536);
//  Post-condition:
//  The function scans the text for the word 'and' and count the amount of "and's" in the text
//  When the amount of and's is bigger than the amount of and's in all tbe previous scans, the
//  function writes the value of "value" to the variable "bestValue".
    char character;
    char character2;
    char character3;
    char outputCharacter;
    char outputCharacter2;
    char outputCharacter3;
    infile.get(character);
    infile.get(character2);
    infile.get(character3);
    initialise_pseudo_random(value);
    outputCharacter = rotate_char(character, next_pseudo_random_number());
    outputCharacter2 = rotate_char(character2, next_pseudo_random_number());
    int counter = 0;
    while (infile) {
        outputCharacter3 = rotate_char(character3, next_pseudo_random_number());
        if (outputCharacter == 'a' && outputCharacter2 == 'n' && outputCharacter3 == 'd') {
            counter++;
        }
        outputCharacter = outputCharacter2;
        outputCharacter2 = outputCharacter3;
        infile.get(character3);
    }
    if (counter > globalCounter) {
        globalCounter = counter;
        bestValue = value;
    }
}

void use_OTP (ifstream& infile, ofstream& outfile, int initial_value)
{
//  Pre-condition:
    assert (initial_value >= 0 && initial_value <= 65535);
//  Post-condition:
//  The outfile is filled with decrypted text
    initialise_pseudo_random(initial_value);
    char character;
    char outputCharactor;
    int randomNumber;
    while (infile) {
        infile.get(character);
        randomNumber = next_pseudo_random_number();
        outputCharactor = rotate_char(character, randomNumber);
        outfile << outputCharactor;
    }
}

void progress(int l) {
//  Pre-condition:
    assert (l >= 0);
//  Post-condition:
//  Print the progress of the brute force function on the screen
    if (l%1000 == 0) {
        cout << l << " of 65535" << endl;
    }
}

bool open_input_and_output_file (ifstream& infile, ofstream& outfile, string input, string output)
{
//  Pre-condition:
    assert(true);
//  Post-condition:
//  True when input and output files were opened successfully, false otherwise.

    if (input == output) {
        cout << "Input name and output name are the same file!" << endl;
        return false;
    }
    infile.open(input.c_str());
    outfile.open(output.c_str());
    if (infile && outfile) {
        infile.clear();
        outfile.clear();
        infile.close();
        outfile.close();
        return true;
    }
    else {
        infile.clear();
        outfile.clear();
        infile.close();
        outfile.close();
        cout << "The input or output file could not be opened!" << endl;
        return false;
    }
}

int main()
{
    ifstream input_file  ;
    ofstream output_file ;
    string input;
    string output;
    cout << "Please input file to decrypt: ";
    cin >> input;
    cout << "Please input file to write decryption to: ";
    cin >> output;
    if (!open_input_and_output_file (input_file,output_file, input, output))
    {
        cout << "Program aborted." << endl ;
        return -1 ;
    }
    cout << "\n\n\n\n\n----------------------------------" << endl;
    cout << "Now scanning for \"and\" in " << input << "." << endl;
    cout << "Please note: This could take a while!" << endl;
    for (int i = 1; i <= 65536; i++){
        input_file.open(input.c_str());
        search_words(input_file, i);
        input_file.clear () ;
        input_file.close () ;
        progress(i);
    }
    cout << "\n\n\n\n\n----------------------------------" << endl;
    cout << "Program has finished, the best starting value is: " << bestValue << endl;
    cout << "Now decrypting with: " << bestValue << endl;
    input_file.open(input.c_str());
    output_file.open(output.c_str());
    use_OTP (input_file,output_file, bestValue);
    cout << "\n\n\n\n\n----------------------------------" << endl;
    cout << "Decryption done, output can be found in: " << output << "." << endl;
    input_file.clear () ;
    input_file.close () ;
    output_file.clear();
    output_file.close();
    if (!input_file || !output_file)
    {
        cout << "Not all files were closed succesfully. The output might be incorrect." << endl ;
        return -1 ;
    }
    return 0 ;
}
