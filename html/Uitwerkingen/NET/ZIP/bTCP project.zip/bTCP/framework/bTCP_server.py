#!/usr/bin/env python3
import argparse
import logging
import os

from btcp_socket import BTCPSocket

logging.basicConfig(level=logging.DEBUG)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("-w", "--window", help="Define bTCP window size", type=int, default=100)
    parser.add_argument("-t", "--timeout", help="Define bTCP timeout in milliseconds", type=int, default=100)
    parser.add_argument("-o", "--output", help="Where to store file", default="tmp.txt")
    parser.add_argument("-n", "--to-receive", help="Amount of files to receive, use -1 for infinite", type=int, default=1)
    parser.add_argument("-p", "--port", help="The port to bind the server on", type=int, default=9001)
    args = parser.parse_args()

    server_ip = "127.0.0.1"
    server_port = args.port

    sock = BTCPSocket()
    sock.bind((server_ip, server_port))
    sock.listen()
    i = 1

    base, ext = os.path.splitext(args.output)

    while i <= args.to_receive or i == -1:
        file = open(base + str(i) + ext, "wb")
        client = sock.accept()
        read = client.recv(1024)
        while read != b'':
            file.write(read)
            read = client.recv(1024)
        file.close()
        logging.debug("File tmp" + str(i) + ".txt finished writing.")
        i += 1

    sock.close()


if __name__ == '__main__':
    main()
