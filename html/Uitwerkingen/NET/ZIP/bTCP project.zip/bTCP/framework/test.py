import logging
import random
from threading import Thread

from btcp_socket import BTCPSocket

"""This is just a singular test to send a couple of files"""

logging.basicConfig(level=logging.DEBUG)


def new_file(i):
    file = open("data" + str(i) + ".txt", "w")
    for i in range(0, 100):
        file.write(str(random.randint(0, 10000)) + "\n")
    file.close()


def send_file(i):
    file = open("data" + str(i) + ".txt", "rb")
    sock = BTCPSocket()
    sock.connect(('127.0.0.1', 9001))
    to_send = file.read()
    sock.sendall(to_send)
    file.close()
    sock.close()


def main():
    for i in range(5):
        new_file(i)
        thread = Thread(target=send_file, args=(i,))
        thread.start()


if __name__ == '__main__':
    main()
