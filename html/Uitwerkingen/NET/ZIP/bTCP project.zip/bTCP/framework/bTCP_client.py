#!/usr/bin/env python3
import argparse

from btcp_socket import *


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("-w", "--window", help="Define bTCP window size", type=int, default=100)
    parser.add_argument("-t", "--timeout", help="Define bTCP timeout in seconds", type=int, default=1)
    parser.add_argument("-i", "--input", help="File to send", default="tmp.file")
    args = parser.parse_args()

    destination_ip = "127.0.0.1"
    destination_port = 9001

    socket = BTCPSocket(args.timeout)
    socket.connect((destination_ip, destination_port), args.window)
    with open(args.input, 'rb') as f:
        socket.sendall(f.read(1000))
    socket.close()


if __name__ == '__main__':
    main()
