import struct
import textwrap

from btcp_socket import FromBytes, ToBytes, HEADER_FORMAT


class Header(FromBytes, ToBytes):
    """
    A class to hold header information for bTCP packets.
    """

    def __init__(self, stream_id: int, syn_number: int, ack_number: int, flags: int, window: int, data_length: int,
                 checksum: int):
        """
        Initializes a header.
        :param stream_id: the stream id to use.
        :param syn_number: the syn number of this packet.
        :param ack_number: the ack number of this packet.
        :param flags: the flags of this packet.
        :param window: the window size of this packet.
        :param data_length: the lenght of the data contained in this packet
        :param checksum: the checksum calculated over this header.
        """
        self.stream_id = stream_id
        self.syn_number = syn_number
        self.ack_number = ack_number
        self.flags = flags
        self.window = window
        self.data_length = data_length
        self.checksum = checksum

    def to_bytes(self) -> bytes:
        """
        Converts a header to bytes.
        :return: this header in byte format.
        """
        return struct.pack(HEADER_FORMAT, self.stream_id, self.syn_number, self.ack_number, self.flags, self.window,
                           self.data_length, self.checksum)

    @classmethod
    def from_bytes(cls, inp: bytes):
        """
        Converts bytes to a header.
        :param inp: the bytes to convert.
        :return: a header converted from the input bytes.
        """
        return cls(*struct.unpack(HEADER_FORMAT, inp))

    @staticmethod
    def build_flags(urg=False, ack=False, eol=False, rst=False, syn=False, fin=False):
        """
        Build the flag variable for a header.
        :param urg: urgent flag is set. Default: False.
        :param ack: ack flag is set. Default: False.
        :param eol: end of letter flag is set. Default: False.
        :param rst: reset flag is set. Default: False.
        :param syn: syn flag is set. Default: False.
        :param fin: fin flag is set. Default: False.
        :return: the flags that were specified in the parameters.
        """
        return urg << 5 | ack << 4 | eol << 3 | rst << 2 | syn << 1 | fin

    def unpack_flags(self) -> (bool, bool, bool, bool, bool, bool, bool, bool):
        """
        Unpacks the flags of this header.
        #TODO: hier naar kijken.
        :return: a tuple of eight booleans representing the flags in this format: (urg,ack,eol,rst,syn,fin,False,False)
        """
        return tuple(reversed([(self.flags & 2 ** x) >> x for x in range(8)]))

    @property
    def urg(self):
        """
        Checks if the urgent flag is set to True.
        :return: True if the urgent flag is set.
        """
        return (self.flags & 2 ** 5) >> 5

    @property
    def ack(self):
        """
        Checks if the ack flag is set to True.
        :return: True if the ack flag is set.
        """
        return (self.flags & 2 ** 4) >> 4

    @property
    def eol(self):
        """
        Checks if the end of letter flag is set to True.
        :return: True if the end of letter flag is set.
        """
        return (self.flags & 2 ** 3) >> 3

    @property
    def rst(self):
        """
        Checks if the reset flag is set to True.
        :return: True if the reset flag is set.
        """
        return (self.flags & 2 ** 2) >> 2

    @property
    def syn(self):
        """
        Checks if the syn flag is set to True.
        :return: True if the syn flag is set.
        """
        return (self.flags & 2 ** 1) >> 1

    @property
    def fin(self):
        """
        Checks if the urgent fin is set to True.
        :return: True if the urgent fin is set.
        """
        return self.flags & 2 ** 0

    def __str__(self):
        """
        Converts a header to string for debugging purposes.
        :return: this packet in string format.
        """
        _, _, urg, ack, eol, rst, syn, fin = self.unpack_flags()
        return textwrap.dedent(
            """Header[
                stream_id: {},
                syn_number: {},
                ack_number: {},
                flags:{}{}{}{}{}{},
                window: {},
                data_length: {},
                checksum: {}
            ]""".format(self.stream_id,
                        self.syn_number,
                        self.ack_number,
                        ' U' if urg else '',
                        ' A' if ack else '',
                        ' E' if eol else '',
                        ' R' if rst else '',
                        ' S' if syn else '',
                        ' F' if fin else '',
                        self.window,
                        self.data_length,
                        self.checksum))