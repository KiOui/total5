import logging

from btcp_socket import Packet


class RearrangeList:
    """
    A class to help rearrange out of order packets.
    """

    def __init__(self, list_size, ack_number):
        """
        Initializes the RearrangeList.
        :param list_size: the maximum list size this list should have, this is typically the window size.
        :param ack_number: the current next to expect ACK number.
        """
        self.list_size = list_size
        self.list = [None] * list_size
        self.ack_number = ack_number

    def add_packet(self, packet: Packet):
        """
        Adds a packet to the list if it is in scope of this list. It will automatically add the packet at the correct index.
        :param packet: the packet to be added.
        :return: True if the packet was added correctly.
        """
        logging.debug(
            "Packet is about to be added to the RearrangeList.\n Begin ACK number list: " + str(self.ack_number) + "\nSYN number packet: " + str(packet.header.syn_number))
        if self.ack_number + self.list_size > packet.header.syn_number >= self.ack_number:
            list_index = (packet.header.syn_number % self.list_size) - (self.ack_number % self.list_size)
            self.list[list_index] = packet
            logging.debug("Packet added at index: " + str(list_index) + ".")
            return True
        else:
            logging.debug("Packet not added because it is not in scope of this list.")
            return False

    def incr(self):
        """
        Increases the ACK number by one.
        """
        self.ack_number += 1

    def has_next(self):
        """
        Checks if the list already has a next element. This is the case if the first index of the list is filled with a packet.
        :return: True if the first element in the list is not None.
        """
        return self.list[0] is not None

    def get_next(self):
        """
        Returns the next packet. If the first packet in the list is None, an Exception will be thrown. Use this function only after checking if has_next returns True.
        :return: the first element in the list if it is not None.
        """
        if self.list[0] is None:
            raise Exception
        else:
            self.list.append(None)
            self.ack_number = (self.ack_number + 1) % (2 ** 16)
            return self.list.pop(0)
