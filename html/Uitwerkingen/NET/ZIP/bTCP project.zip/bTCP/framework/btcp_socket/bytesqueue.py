from collections import deque

import logging
from io import RawIOBase
from threading import Condition, RLock
from typing import Deque


class BytesQueue(RawIOBase):
    """
    Creates a queue for storing packet data.
    """

    def __init__(self, *args, **kwargs):
        """
        Initializes a BytesQueue by calling the initializer of RawIOBase.
        :param args: the arguments for the initializer of RawIOBase.
        :param kwargs: the arguments for the initializer of RawIOBase.
        """
        super().__init__(*args, **kwargs)
        self.queue: Deque[bytes] = deque()
        self.lock = RLock()
        self.empty_condition = Condition(self.lock)
        self.open = True

    def close(self):
        """
        Close this queue.
        """
        super(BytesQueue, self).close()
        logging.debug("Buffer is being closed...")
        with self.lock:
            self.open = False
            self.empty_condition.notify()

    def seekable(self):
        """
        Returns False.
        :return: False.
        """
        return False

    def _pop(self) -> bytes:
        """
        Returns the next byte in the queue if one exists. Otherwise either waits or returns nothing.
        :return: the next byte in the list.
        """
        with self.lock:
            while len(self.queue) == 0 and self.open:
                self.empty_condition.wait()
            if not self.open and len(self.queue) == 0:
                return b''
            return self.queue.popleft()

    def read(self, size=-1) -> bytes:
        """
        Read the next size bytes from the queue.
        :param size: the amount of bytes to read from the queue. If size is set below 0, the entire queue will be returned. Default: -1.
        :return: the next size bytes held by the queue.
        """
        with self.lock:
            if size < 0:
                val = b''.join(self.queue)
                self.queue.clear()
                return val
            if size == 0:
                return b''
            part = self._pop()
            while len(part) < size and not len(self.queue) == 0:
                part += self._pop()

            left, right = part[:size], part[size:]
            if len(right) > 0:
                self.queue.appendleft(right)
            return left

    def write(self, b: bytes):
        """
        Write bytes to the queue.
        :param b: the bytes to be written to the queue.
        """
        with self.lock:
            self.queue.append(b)
            self.empty_condition.notify()
