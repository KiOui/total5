import binascii

from btcp_socket import FromBytes, ToBytes, Header, HEADER_LENGTH
from btcp_socket.exceptions import BadChecksumException


class Packet(FromBytes, ToBytes):
    """
    A class for holding a complete packet.
    """

    def __init__(self, header: Header, data: bytes):
        """
        Initializes a packet. This method is almost not used because most of the time packets get created with the from_bytes function
        :param header: the header to be used for this packet.
        :param data: the data that this packet must contain.
        """
        self.header = header
        self.data = data

    def to_bytes(self) -> bytes:
        """
        Converst a packet to bytes.
        :return: this packet in byte format.
        """
        self.header.checksum = 0
        checksum = binascii.crc32(self.header.to_bytes() + self.data)
        self.header.checksum = checksum
        return self.header.to_bytes() + self.data

    @classmethod
    def from_bytes(cls, inp: bytes):
        """
        Converts bytes to a packet. If the checksum of the packet does not match, raise a BadChecksumException.
        :param inp: the bytes to convert.
        :return: a decoded packet.
        """
        header = Header.from_bytes(inp[:HEADER_LENGTH])
        checksum = header.checksum
        header.checksum = 0
        if checksum != binascii.crc32(header.to_bytes() + inp[HEADER_LENGTH:]):
            raise BadChecksumException()
        return cls(header, inp[HEADER_LENGTH:])

    def __str__(self):
        """
        Converts a packet to string format for better debugging.
        :return: the packet in string format.
        """
        return "Packet[header: {},\ndata: {}]".format(self.header, self.data)