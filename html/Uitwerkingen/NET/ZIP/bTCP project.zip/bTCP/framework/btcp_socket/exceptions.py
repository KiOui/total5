class MaxRetriesExceeded(Exception):
    """
    This exception gets thrown when a packet did not arrive an x amount of times.
    """
    pass


class BadChecksumException(Exception):
    """
    This exception gets thrown when a packet that we received did not contain a right checksum.
    """
    pass
