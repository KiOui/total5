from typing import NewType, Tuple

HEADER_FORMAT = "IHHBBHI"
HEADER_LENGTH = 16
DATA_LENGTH = 1000

MAX_PACKET_SIZE = 1016
MAX_RETRIES = 10

Addr = Tuple[str, int]
