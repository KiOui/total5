import logging

from btcp_socket import Connection, Packet, Header, State
from btcp_socket.utils import syn_ack, fin_ack, ack, reset


def state_listen(conn: Connection, packet: Packet) -> Connection:
    """
    Imitates the listen state.
    :param conn: the connection that needs to handle the next packet.
    :param packet: the next packet to be handled by the connection.
    :return: a new connection of type SYN_RCVD if the packet was accepted. Otherwise return a non-altered connection.
    """
    if packet.header.flags == Header.build_flags(syn=True):
        conn.state = State.SYN_RCVD
        if conn.window > packet.header.window:
            conn.window = packet.header.window
        conn.sendto(syn_ack(packet.header.stream_id, conn.seq_num, packet.header.syn_number + 1,
                            conn.window))
        return conn
    # We ignore any other packets.
    logging.warning("Client send invalid message in LISTEN state.")
    conn.send_without_retry(reset(packet.header.stream_id, 0, 0,
                            conn.window))
    return conn


def state_syn_rcvd(conn: Connection, packet: Packet) -> Connection:
    """
    Imitates the SYN_RCVD state.
    :param conn: the connection that needs to handle the next packet.
    :param packet: the next packet to be handled by the connection.
    :return: a new connection of type ESTAB if the packet was accepted. Otherwise return a non-altered connection.
    """
    if packet.header.flags == Header.build_flags(ack=True):
        if packet.header.ack_number >= conn.seq_num:
            conn.cancel(packet.header.ack_number)
            conn.set_ack_number(packet.header.syn_number)
            conn.state = State.ESTAB
            return conn
        else:
            logging.warning("ACK number not correct in SYN RCVD state.")
    # We ignore any other packets.
    logging.warning("Client send invalid message in SYN RCVD state.")
    return conn


def state_syn_sent(conn: Connection, packet: Packet) -> Connection:
    """
    Imitates the SYN_SENT state.
    :param conn: the connection that needs to handle the next packet.
    :param packet: the next packet to be handled by the connection.
    :return: a new connection of type ESTAB if the packet was accepted. Otherwise return a non-altered connection.
    """
    if packet.header.flags == Header.build_flags(syn=True, ack=True):
        if packet.header.ack_number >= conn.seq_num:
            if conn.window > packet.header.window:
                conn.window = packet.header.window
            conn.cancel(packet.header.ack_number)
            conn.state = State.ESTAB
            conn.set_ack_number(packet.header.syn_number)
            conn.send_without_retry(
                ack(packet.header.stream_id, conn.seq_num, packet.header.syn_number + 1, conn.window))
            return conn
        else:
            logging.warning("ACK number not correct in SYN SENT state.")
    # We ignore any other packets.
    logging.warning("Client send invalid message in SYN SENT state.")
    return conn


def state_estab(conn: Connection, packet: Packet) -> Connection:
    """
    Imitates the establised state.
    :param conn: the connection that needs to handle the next packet.
    :param packet: the next packet to be handled by the connection.
    :return: a new connection of type CLOSING if a packet was accepted which contained a FIN flag. Otherwise, handle the packet and return a non-altered connection.
    """
    # If the last ACK did not arrive
    if packet.header.flags == Header.build_flags(syn=True, ack=True):
        logging.debug("A SYN-ACK packet has been received in the ESTABLISHED state, this means we return to the SYN_SENT state...")
        return state_syn_sent(conn, packet)
    # First we check if this packet acknowledges any other packets
    if packet.header.ack:
        conn.cancel(packet.header.ack_number)
    # If this packet wants to stop the communication
    if packet.header.flags == Header.build_flags(fin=True):
        logging.debug("FIN received, closing the connection now...")
        conn.state = State.CLOSING
        conn.sendto(
            fin_ack(packet.header.stream_id, conn.seq_num, packet.header.syn_number + 1, conn.window))
        return conn
    # Otherwise, we must check the packet and put it into the buffer
    else:
        if len(packet.data) > 0 and not conn.receive_packet(packet):
            logging.warning("Packet received but sequence number too high.")
        return conn


def state_fin_wait(conn: Connection, packet: Packet) -> Connection:
    """
    Imitates the FIN wait state.
    :param conn: the connection that needs to handle the next packet.
    :param packet: the next packet to be handled by the connection.
    :return: a new connection of type CLOSED if the packet was accepted. Otherwise return a non-altered connection.
    """
    if packet.header.flags == Header.build_flags(fin=True, ack=True) and packet.header.ack_number >= conn.seq_num:
        conn.cancel(packet.header.ack_number)
        conn.send_without_retry(
            ack(packet.header.stream_id, conn.seq_num, packet.header.syn_number + 1, conn.window))
        conn.state = State.CLOSED
        conn.data.close()
        return conn
    # We ignore any other packets.
    logging.warning("Client send invalid message in FIN WAIT state.")
    return conn


def state_closing(conn: Connection, packet: Packet) -> Connection:
    """
    Imitates the closing state.
    :param conn: the connection that needs to handle the next packet.
    :param packet: the next packet to be handled by the connection.
    :return: a new connection of type CLOSED if the packet was accepted. Otherwise return a non-altered connection.
    """
    if packet.header.flags == Header.build_flags(ack=True) and packet.header.ack_number >= conn.seq_num:
        logging.debug("Last ACK received, bye bye!")
        conn.cancel(packet.header.ack_number)
        conn.state = State.CLOSED
        conn.data.close()
        return conn
    # We ignore any other packets.
    logging.warning("Client send invalid message in CLOSING state.")
    return conn


def state_closed(conn: Connection, packet: Packet) -> Connection:
    # Ignore the packet.
    return conn


HANDLERS = {
    State.LISTEN: state_listen,
    State.SYN_RCVD: state_syn_rcvd,
    State.SYN_SENT: state_syn_sent,
    State.ESTAB: state_estab,
    State.CLOSING: state_closing,
    State.FIN_WAIT: state_fin_wait,
    State.CLOSED: state_closed,
}
