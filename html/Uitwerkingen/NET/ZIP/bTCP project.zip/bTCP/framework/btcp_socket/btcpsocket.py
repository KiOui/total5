import struct

import logging
import socket as orig_sock
import time
from queue import Queue
from threading import Thread
from typing import Dict, Tuple

from btcp_socket import Connection, Addr, State, DATA_LENGTH, HANDLERS, Packet, MAX_PACKET_SIZE
from btcp_socket.exceptions import MaxRetriesExceeded
from btcp_socket.utils import reset


class BTCPSocket:
    """Imitates the python socket interface"""

    def __init__(self, timeout=1):
        """
        Initializes the BTCPSocket interface by creating a UDP socket and other needed variables.
        """
        self.socket = orig_sock.socket(orig_sock.AF_INET, orig_sock.SOCK_DGRAM)
        self.socket.settimeout(1)
        self.backlog: Queue = None
        self.conns: Dict[Tuple[int, str], Connection] = dict()
        self.receiver: Thread = None
        self.running = False
        self.server = False
        self.closing_time = 0
        self.is_closing = False
        self.timeout = timeout

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.socket.__exit__(*args)

    def bind(self, addr: Addr):
        """
        Binds the socket to an address
        :param addr: the address the socket must bind to, this needs to be a tuple of (ip address, port).
        """
        self.socket.bind(addr)

    def listen(self, backlog=5):
        """
        Starts the receive_loop by creating a thread and setting running and server variables to True. Also the queue will get initialized with a size of backlog.
        :param backlog: the size of the queue to be crdated, this queue will hold all incoming connections. Default: 5.
        """
        self.backlog = Queue(maxsize=backlog)
        self.running = True
        self.server = True
        self.receiver = Thread(target=self.receive_loop)
        self.receiver.start()

    def accept(self) -> Connection:
        """
        This function is used to receive an incoming connection.
        :return: the first connection in the queue.
        """
        key = self.backlog.get()
        next_connection = self.conns.get(key)
        return next_connection

    def connect(self, addr, window: int = 20):
        """
        Creates a bTCP connection to a client.
        :param addr: tuple of (ip address, port). This tuple specifies where to connect to.
        :param window: the window size to use for this connection. Default: 20.
        """
        conn = Connection(addr=addr, sock=self.socket, window=window, timeout=self.timeout)
        stream_id = conn.open()
        key = (stream_id, conn.addr[0])
        logging.debug("Key: " + str(key))
        self.conns[key] = conn
        self.running = True
        self.receiver = Thread(target=self.receive_loop)
        self.receiver.start()
        while conn.state != State.ESTAB and conn.state != State.CLOSED:
            time.sleep(0.1)

        if conn.state == State.CLOSED:
            raise MaxRetriesExceeded

    @property
    def _conn(self):
        """
        Return the only connection in the list. This function is only used when this socket is a client.
        :return: the only connection in the list.
        """
        assert len(self.conns) == 1
        return next(iter(self.conns.values()))

    def sendall(self, inp: bytes):
        """
        Send arbitrary data to the other side.
        :param inp: the data to be send in binary form.
        """
        offset = 0
        while offset < len(inp):
            data = inp[offset:offset + DATA_LENGTH]
            self._conn.send_data(data)
            offset += DATA_LENGTH
        self._conn.wait()

    def recv(self, amount: int) -> bytes:
        """
        Receive an amount of data. This function is only used when this socket is a client.
        :param amount: the amount of data to receive in bytes.
        :return: the data amount that was asked for.
        """
        return self._conn.recv(amount)

    def close(self, timeout=5):
        """
        Close all connections and the socket.
        :param timeout: the maximum time in seconds we will wait untill we force quit. Default: 5 seconds.
        """
        logging.debug("Closing server...")
        self.is_closing = True
        for client in self.conns.values():
            client.close()
        self.is_closing = False
        self.running = False
        self.closing_time = time.time() + timeout
        logging.debug("Waiting for all clients to close, force close will occur at: " + str(self.closing_time) + ".")
        while len(self.conns) != 0 and self.closing_time >= time.time():
            time.sleep(0.1)
            logging.debug("Waiting for all clients to close, force close will occur in: " + str(self.closing_time-time.time()) + ".")
        logging.debug("Closing socket, current amount of alive clients: " + str(len(self.conns)) + ".")
        self.socket.close()
        logging.debug("Socket closed.")
        self.receiver.join()

    def _stream_id_exists(self, new_stream_id, new_addr):
        """
        Check if a stream id already exists.
        :param new_stream_id: the stream id to check.
        :param new_addr: the address this stream id corresponds to.
        :return: True if the stream if the stream id is already used by another client.
        """
        for stream_id, addr in self.conns.keys():
            if stream_id == new_stream_id and addr != new_addr:
                return True
        return False

    def receive_loop(self):
        """
        Handles all incoming packets. Imitates as a proxy for all connections. Reroutes all different incoming packets to the right connection.
        """
        while True:
            if not self.is_closing:
                for key in list(self.conns.keys()):
                    if self.conns[key].state == State.CLOSED and self.conns[key].data.closed:
                        del self.conns[key]

            if not self.running and (len(self.conns) == 0 or self.closing_time < time.time()):
                break

            try:
                data, addr = self.socket.recvfrom(MAX_PACKET_SIZE)
            except orig_sock.timeout:
                continue
            except OSError:
                break

            try:
                packet = Packet.from_bytes(data)
            except struct.error:
                continue
            stream_id = packet.header.stream_id
            key = (stream_id, addr[0])
            logging.debug(key)
            logging.debug(packet)

            if self._stream_id_exists(*key):
                # Stream is already in use
                self.socket.sendto(reset(packet.header.stream_id, 0, 0, 0).to_bytes(), addr)
                continue

            if key not in self.conns:
                if self.server and self.backlog.full():
                    # Send a reset because our backlog is already full
                    self.socket.sendto(reset(packet.header.stream_id, 0, 0, 0).to_bytes(), addr)
                    logging.error("Backlog full.")
                else:
                    newstate = HANDLERS[State.LISTEN](
                        Connection(stream_id=stream_id, addr=addr, sock=self.socket, timeout=self.timeout), packet)
                    if newstate is not None:
                        self.conns[key] = newstate
                        self.backlog.put(key)
            else:
                conn = self.conns[key]
                newstate = HANDLERS[conn.state](conn, packet)
                self.conns[key] = newstate
