from enum import Enum


class State(Enum):
    LISTEN = 1
    SYN_RCVD = 2
    SYN_SENT = 3
    ESTAB = 4
    CLOSING = 5
    CLOSED = 6
    FIN_WAIT = 7