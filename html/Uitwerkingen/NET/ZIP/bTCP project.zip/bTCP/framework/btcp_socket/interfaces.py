class FromBytes:
    @classmethod
    def from_bytes(cls, inp: bytes):
        raise NotImplementedError()


class ToBytes:
    def to_bytes(self) -> bytes:
        raise NotImplementedError()
