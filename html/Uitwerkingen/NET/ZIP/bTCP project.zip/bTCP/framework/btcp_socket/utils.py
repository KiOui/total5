from btcp_socket import Header, Packet


def syn(*args) -> Packet:
    """
    Builds a SYN packet with arguments. All arguments of Packet are needed except the flags.
    :param args: the other arguments a packet needs.
    :return: a SYN packet.
    """
    return empty(Header.build_flags(syn=True), *args)


def syn_ack(*args) -> Packet:
    """
    Builds a SYN_ACK packet with arguments. All arguments of Packet are needed except the flags.
    :param args: the other arguments a packet needs.
    :return: a SYN_ACK packet.
    """
    return empty(Header.build_flags(syn=True, ack=True), *args)


def fin_ack(*args) -> Packet:
    """
    Builds a FIN_ACK packet with arguments. All arguments of Packet are needed except the flags.
    :param args: the other arguments a packet needs.
    :return: a FIN_ACK packet.
    """
    return empty(Header.build_flags(fin=True, ack=True), *args)


def ack(*args) -> Packet:
    """
    Builds a ACK packet with arguments. All arguments of Packet are needed except the flags.
    :param args: the other arguments a packet needs.
    :return: a ACK packet.
    """
    return empty(Header.build_flags(ack=True), *args)


def reset(*args) -> Packet:
    """
    Builds a RST packet with arguments. All arguments of Packet are needed except the flags.
    :param args: the other arguments a packet needs.
    :return: a RST packet.
    """
    return empty(Header.build_flags(rst=True), *args)


def fin(*args) -> Packet:
    """
    Builds a FIN packet with arguments. All arguments of Packet are needed except the flags.
    :param args: the other arguments a packet needs.
    :return: a FIN packet.
    """
    return empty(Header.build_flags(fin=True), *args)


def empty(flags: int, stream_id: int, syn_number: int, ack_number: int, window: int) -> Packet:
    """
    Creates an emtpy packet with the given parameters.
    :param flags: the flags to use.
    :param stream_id: the stream id to use.
    :param syn_number: the syn number to use.
    :param ack_number: the ack number to use.
    :param window: the window size to use.
    :return: an empty packet.
    """
    return Packet(Header(stream_id, syn_number, ack_number, flags, window, 0, 0), b'')
