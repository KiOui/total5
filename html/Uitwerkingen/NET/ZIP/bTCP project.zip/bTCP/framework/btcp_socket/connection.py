import logging
import random
import time
from threading import Timer
from typing import Dict

from btcp_socket import BytesQueue, Packet, MAX_RETRIES, DATA_LENGTH, Addr, State, Header, \
    RearrangeList
from btcp_socket.utils import fin, ack, reset


class Connection:
    """
    A class for keeping track of a connection.
    """

    def __init__(self, stream_id: int = None, addr: Addr = None, window: int = 20, state: State = State.LISTEN,
                 seq_num=0, sock=None, timeout=1.0):
        """
        Initializes a connection. Not all variables need to be set at initialization.
        :param stream_id: the stream id of this connection. Default: None.
        :param addr: the address we are communicating too. This is a tuple of (ip address, port). Default: None.
        :param window: the window size to use for this connection. Default: 20.
        :param state: the current state of this connection. This will be used to choose the required handler for packets. Default: State.LISTEN.
        :param seq_num: the current sequence number of this connection. Default: 0.
        :param sock: the socket to send data over. Default: None.
        :param timeout: the amount of time to wait in seconds untill a connection timeouts. Default: 0.5 seconds.
        """
        self.stream_id = stream_id
        self.addr = addr
        self.window = window
        self.state = state
        self.seq_num = seq_num
        if self.seq_num == 0:
            self.seq_num = int(time.time() * 4000000) % (2 ** 16)
        self.sock = sock
        self.timers: Dict[int, Timer] = dict()
        self.tries = 0
        self.data = BytesQueue()
        self.timeout = timeout
        self.packet_list = None
        self.last_ack = None
        self.accepted = False

    def open(self):
        """
        Open a connection by sending an ACK packet.
        :return: the stream id to use with this connection.
        """
        stream_id = random.randint(0, 2 ** 32 - 1)
        self.sendto(Packet(
            Header(stream_id, self.seq_num, 0, Header.build_flags(syn=True), self.window, 0, 0),
            b''))
        self.state = State.SYN_SENT
        self.stream_id = stream_id
        return stream_id

    def set_ack_number(self, ack_number):
        """
        Sets the ack number of the other party. Also creates a RearrangeList to be used by this connection.
        :param ack_number: the sequence number of the party we are communicating with.
        """
        self.packet_list = RearrangeList(self.window, ack_number)

    def incr(self):
        """
        Increase the sequence number by one.
        """
        self.seq_num = (self.seq_num + 1) % (2 ** 16)

    def recv(self, amount: int) -> bytes:
        """
        Return bytes from the stored buffer.
        :param amount: the amount of bytes to be returned.
        :return: amount bytes from the buffer.
        """
        return self.data.read(amount)

    def sendto(self, data: Packet):
        """
        Send a packet.
        :param data: the packet to be send.
        """
        self.incr()
        self._send(data, 1)

    def send_without_retry(self, data: Packet):
        """
        Send a packet without setting a retry timer.
        :param data: the packet to be send.
        """
        logging.debug("Sending (WITHOUT RETRY): " + str(data))
        self.sock.sendto(data.to_bytes(), self.addr)

    def _send(self, data: Packet, tries):
        """
        Send a packet and set a timer.
        :param data: the packet to be send.
        :param tries: the amount of times this packet has already been tried to send. This method will get called with tries+1 if a timeout occurs.
        """
        if tries > MAX_RETRIES:
            self.state = State.CLOSED
            self.sock.sendto(reset(self.stream_id, 0, 0,
                                   self.window).to_bytes(), self.addr)
            return

        logging.debug("Sending: " + str(data))

        self.sock.sendto(data.to_bytes(), self.addr)
        timer = Timer(self.timeout, self._send, [data, tries + 1])
        timer.start()
        self.timers[data.header.syn_number] = timer

    def receive_packet(self, packet: Packet):
        """
        Adds a packet to the rearrangelist and transfers in-order packets from the rearrangelist to the buffer. Throws an Exception if the packet_list is None.
        :param packet: the packet to add.
        :return: True if the packet got added.
        """
        if self.packet_list is None:
            raise Exception
        if self.packet_list.add_packet(packet):
            while self.packet_list.has_next():
                next_packet = self.packet_list.get_next()
                logging.debug("Adding data to the buffer: STREAM: " + str(self.stream_id) + ", " + str(next_packet.header.syn_number))

                self.data.write(next_packet.data)
            self.send_without_retry(ack(self.stream_id, self.seq_num, self.packet_list.ack_number,
                                        self.window))
            return True
        else:
            self.send_without_retry(ack(self.stream_id, self.seq_num, self.packet_list.ack_number,
                                        self.window))
            return False

    def cancel(self, ack_num):
        """
        Cancel a timer.
        :param ack_num: the ack_number of the timer to be cancelled.
        """
        if self.last_ack is not None:
            self.last_ack = max(ack_num, self.last_ack)
        else:
            self.last_ack = ack_num
        self.tries = 0
        for i in list(self.timers.keys()):
            if i < ack_num:
                logging.debug("Cancelling timer with id: " + str(i))
                self.timers[i].cancel()
                del self.timers[i]

    def close(self):
        """
        Initiate a termination sequence by sending a FIN.
        """
        if self.state != State.CLOSING and self.state != State.CLOSED:
            logging.debug("Closing connection with stream id " + str(self.stream_id))
            self.state = State.FIN_WAIT
            self.sendto(fin(self.stream_id, self.seq_num, 0, self.window))
        else:
            logging.debug("State of connection is already closing.")

    def send_data(self, data: bytes):
        """
        Sends data to the communicating party.
        :param data: the data to be send.
        """
        assert len(data) <= DATA_LENGTH
        self.sendto(
            Packet(Header(self.stream_id, self.seq_num, 0, 0, self.window, len(data), 0),
                   data))

    def wait(self):
        """
        Wait for a packet.
        """
        while self.last_ack < self.seq_num and self.state != State.CLOSED:
            logging.debug("Waiting for all packet ACKs to arrive, current time: " + str(time.time()) + ".")
            time.sleep(0.1)
