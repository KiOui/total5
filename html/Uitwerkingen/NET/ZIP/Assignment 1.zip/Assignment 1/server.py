from socket import *
from random import randint
import os.path

serverPort = 20000
# build TCP socket
serverSocket = socket(AF_INET, SOCK_STREAM)
# bind it to port
serverSocket.bind(('', serverPort))
# listen (clients will start queuing up)
serverSocket.listen(1)

HELLO = "hello\r\n"
GET = "get"
BYE = "bye\r\n"
NOTFOUND = "file_not_found\r\n"
CONTENT = "file_content\r\n"
UNDERSTAND = "cannot_understand\r\n"
ERROR = "Error\r\n"

def get_file(filename):
    # remove newlines
    filename = filename.replace("\r\n".encode(), "".encode())
    filename = filename.replace("\n".encode(), "".encode())
    # decode binary
    string = filename.decode('UTF-8')
    if (os.path.isfile(string)):
        return CONTENT
    else:
        return NOTFOUND

def handle_command(command):
    splitted = command.split(" ".encode())
    if (len(splitted) > 0):
        if (splitted[0] == GET.encode()):
            if (len(splitted) > 1):
                return get_file(splitted[1])
            else:
                return UNDERSTAND
        elif (splitted[0] == BYE.encode()):
            return BYE
        else:
            return UNDERSTAND
    else:
        return UNDERSTAND

def is_hello(command):
    splitted = command.split(" ".encode())
    if (len(splitted) > 0):
        return splitted[0] == HELLO.encode()
    else:
        return False


print('The server is ready to receive')
while 1:
    # the is waiting for clients to connect/ processes them one at a time
    connectionSocket, addr = serverSocket.accept()
    print('Processing client ', addr)
    try :
        sentence = connectionSocket.recv(1024)
        # this boolean keeps track of the hello exchange
        connected = False;
        while sentence:
            echoedSentence = ERROR
            if (connected):
                echoedSentence = handle_command(sentence)
            else:
                connected = is_hello(sentence)
                if (connected):
                    echoedSentence = HELLO
                else:
                    echoedSentence = UNDERSTAND
                
            connectionSocket.send(echoedSentence.encode())
            
            if (echoedSentence == BYE):
                print("closed")
                connectionSocket.close()
            else:
                sentence = connectionSocket.recv(1024)
    except error:
        pass
    print('Client closed ', addr)
    # close socket
    connectionSocket.close()
