#!/usr/bin/env python3

"""Tests for your DNS resolver and server"""

import sys
import time
import unittest
from argparse import ArgumentParser
from unittest import TestCase

from dns import DEFAULT_TTL
from dns.cache import RecordCache
from dns.classes import Class
from dns.message import Message, Header
from dns.name import Name
from dns.resolver import Resolver
from dns.resource import ResourceRecord, ARecordData, CNAMERecordData, NSRecordData, GenericRecordData
from dns.rtypes import Type
from dns.zone import parse_record, Zone

PORT = 5001
SERVER = "localhost"


class TestResolver(TestCase):
    """Resolver tests"""

    def test_resolver(self):
        resolver_test = Resolver(1, False, 4000, RecordCache(0))
        cases = {
            "www.thalia.nu.": ("virtueleivo.thalia.nu.", ['131.174.41.19'], ['www.thalia.nu.']),  # CNAME
            "www.cs.ru.nl.": ("www.cs.ru.nl.", ['131.174.8.6'], []),  # Normal A name record
            "plaintext.software": ("plaintext.software.", ['188.226.137.65'], []),
            # Normal A name record (question is without last '.')
            "blub.plaintext.software": ("", [], []),
            # CNAME record that directs to another CNAME that directs to this CNAME, an empty output should be generated
            "blab.plaintext.software": ("cs.ru.nl.", ['131.174.8.6'], ['blab.plaintext.software.'])
            # CNAME points to cs.ru.nl. (without last '.')
        }

        for test, expect in cases.items():
            self.assertEqual(resolver_test.gethostbyname(test), expect)


class TestCache(TestCase):
    """Cache tests"""

    def test_cache(self):
        cache_test = RecordCache(0)

        # Normal record
        cache_test.remove_all()

        name_record1 = "nonexistant.non."
        test_record1 = ResourceRecord(name=Name(name_record1), class_=Class.IN, type_=Type.A, ttl=DEFAULT_TTL,
                                      rdata=ARecordData(address="1.1.1.1"))

        cache_test.add_record(test_record1)
        test_equals1 = cache_test.lookup(name_record1, Type.A, Class.IN, 0)

        self.assertEqual(1, len(test_equals1))

        if (len(test_equals1) == 1):
            self.assertEqual(test_record1, test_equals1[0])

        # SOA records should not be added
        cache_test.remove_all()

        name_record2 = "google.com."
        test_record2 = ResourceRecord(name=Name(name_record2), class_=Class.IN, type_=Type.SOA, ttl=DEFAULT_TTL,
                                      rdata=None)

        cache_test.add_record(test_record2)
        test_equals2 = cache_test.lookup(name_record2, Type.SOA, Class.IN, 0)

        self.assertEqual(0, len(test_equals2))

        # CNAME record for A name in cache
        cache_test.remove_all()

        name_record3 = "plaintext.software."
        name_record3a = "something.plaintext.software."
        test_record3 = ResourceRecord(name=Name(name_record3), class_=Class.IN, type_=Type.CNAME, ttl=DEFAULT_TTL,
                                      rdata=CNAMERecordData(name_record3a))
        test_record3a = ResourceRecord(name=Name(name_record3a), class_=Class.IN, type_=Type.A, ttl=DEFAULT_TTL,
                                       rdata=ARecordData(address="3.3.3.3"))

        cache_test.add_record(test_record3)
        cache_test.add_record(test_record3a)
        test_equals3 = cache_test.lookup(name_record3, Type.A, Class.IN, 0)

        self.assertEqual(2, len(test_equals3))

        self.assertEqual(True, test_record3 in test_equals3)
        self.assertEqual(True, test_record3a in test_equals3)

        # Only a CNAME in cache
        cache_test.remove_all()

        name_record4 = "this.is.a.joke."
        name_record4a = "this.is.not.in.cache."
        test_record4 = ResourceRecord(name=Name(name_record4), class_=Class.IN, type_=Type.CNAME, ttl=DEFAULT_TTL,
                                      rdata=CNAMERecordData(name_record4a))

        cache_test.add_record(test_record4)
        test_equals4 = cache_test.lookup(name_record4, Type.A, Class.IN, 0)

        self.assertEqual(1, len(test_equals4))

        if len(test_equals4) == 1:
            self.assertEqual(test_record4, test_equals4[0])

        # Deletion of aged records if cache parameter is 0 (no overwrite)
        seconds = 3

        cache_test.remove_all()

        name_record5 = "dont.forget.me."
        test_record5 = ResourceRecord(name=Name(name_record5), class_=Class.IN, type_=Type.A, ttl=seconds,
                                      rdata=ARecordData(address="4.4.4.4"))

        cache_test.add_record(test_record5)

        time.sleep(seconds + 1)

        test_equals5 = cache_test.lookup(name_record5, Type.A, Class.IN, 0)

        self.assertEqual(0, len(test_equals5))

        # Deletion of aged records if cache parameter is non zero
        cache_test = RecordCache(seconds)

        cache_test.add_record(test_record1)

        time.sleep(seconds + 1)

        test_equals6 = cache_test.lookup(name_record1, Type.A, Class.IN, 0)

        self.assertEqual(0, len(test_equals6))


class TestResolverCache(TestCase):
    """Resolver tests with cache enabled"""

    # We will create a resolver with cache that overwrites the standard time to live to 4000 seconds,
    # this way we can make sure that the records are still in cache when we resolve them twice
    def test_resolver_cache(self):
        test_cache = RecordCache(4000)
        test_cache.remove_all()
        resolver_test = Resolver(1, True, 4000, test_cache)
        cases = {
            "www.thalia.nu.": ("virtueleivo.thalia.nu.", ['131.174.41.19'], ['www.thalia.nu.']),  # CNAME
            "www.cs.ru.nl.": ("www.cs.ru.nl.", ['131.174.8.6'], []),  # Normal A name record
            "plaintext.software": ("plaintext.software.", ['188.226.137.65'], []),
            # Normal A name record (question is without last '.')
            "blub.plaintext.software": ("", [], []),
            # CNAME record that directs to another CNAME that directs to this CNAME, an empty output should be generated
            "blab.plaintext.software": ("cs.ru.nl.", ['131.174.8.6'], ['blab.plaintext.software.'])
            # CNAME points to cs.ru.nl. (without last '.')
        }

        # We will run all tests twice, the second time the records are cached and thus should be the same
        for test, expect in cases.items():
            self.assertEqual(resolver_test.gethostbyname(test), expect)
            self.assertEqual(resolver_test.gethostbyname(test), expect)
            test_cache.remove_all()


class TestServer(TestCase):
    """Server tests"""

    def test_parser(self):
        cases = {
            "thalia.nu. A 13.13.2.3": ResourceRecord(name=Name("thalia.nu."), class_=Class.IN, type_=Type.A,
                                                     ttl=DEFAULT_TTL, rdata=ARecordData(address="13.13.2.3")),
            "www.thalia.nu CNAME virtueleivo.thalia.nu": ResourceRecord(name=Name("www.thalia.nu."), class_=Class.IN,
                                                                        type_=Type.CNAME, ttl=DEFAULT_TTL,
                                                                        rdata=CNAMERecordData(
                                                                            cname=Name('virtueleivo.thalia.nu'))),
            "www.google.com 170 CH NS ns.google.net": ResourceRecord(name=Name("www.google.com"), class_=Class.CH,
                                                                     ttl=170, type_=Type.NS,
                                                                     rdata=NSRecordData(nsdname=Name("ns.google.net"))),
            "abc.ru.nl CS MX 10 mail.ru.nl": ResourceRecord(name=Name('abc.ru.nl'), type_=Type.MX, class_=Class.CS,
                                                            ttl=DEFAULT_TTL, rdata=GenericRecordData(b"10 mail.ru.nl"))
        }
        for test, expect in cases.items():
            self.assertEqual(parse_record(test), expect)

    def test_read_zonefile(self):
        zone = Zone()
        zone.read_master_file('./tests/testzones')
        self.maxDiff = None
        self.assertEqual(zone.records, {
            "thalia.nu.": [ResourceRecord(name=Name("thalia.nu."), class_=Class.IN, type_=Type.A,
                                          ttl=DEFAULT_TTL, rdata=ARecordData(address="13.13.2.3"))],
            "www.thalia.nu.": [ResourceRecord(name=Name("www.thalia.nu."), class_=Class.IN,
                                              type_=Type.CNAME, ttl=DEFAULT_TTL,
                                              rdata=CNAMERecordData(
                                                  cname=Name('virtueleivo.thalia.nu')))],
            "www.google.com.": [ResourceRecord(name=Name("www.google.com"), class_=Class.CH,
                                               ttl=170, type_=Type.NS,
                                               rdata=NSRecordData(nsdname=Name("ns.google.net")))],
            "abc.ru.nl.": [ResourceRecord(name=Name('abc.ru.nl'), type_=Type.MX, class_=Class.CS,
                                          ttl=DEFAULT_TTL, rdata=GenericRecordData(b"10 mail.ru.nl"))]})


class TestFrameworkAdditions(TestCase):
    """Test additions added to the framework"""

    def test_truncation_bit(self):
        """ Tests the added feature of automatically truncating long messages when converting to bytes.

        The UDP standard mandates that messages should be a maximum of 512 bytes long, this function tests if messages
        are truncated and also if the truncated bit is set for the DNS message.
        """
        message = Message(Header(an_count=1, ar_count=0, ns_count=0, qd_count=0, flags=0, ident=1))
        message.answers.append(
            ResourceRecord(name=Name("message.thalia.nu"), class_=Class.IN, type_=Type.A, ttl=DEFAULT_TTL,
                           rdata=GenericRecordData(data=b"""Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
                           Morbi vitae mauris ex. Integer velit eros, vulputate a lorem a, vestibulum varius purus. 
                           Aliquam dignissim arcu vel nisl vehicula, eget bibendum dolor auctor. Nullam vitae libero 
                           arcu. Ut non nisi eget justo accumsan tristique. Nunc quis malesuada dolor. Pellentesque 
                           porta magna nec vehicula dignissim. Nunc vitae mollis mauris. Phasellus auctor suscipit 
                           cursus. Curabitur pulvinar urna vitae maximus iaculis. Integer pharetra sodales risus ut 
                           vulputate. Donec turpis duis.""")))
        bytes_ = message.to_bytes()
        truncmsg = message.from_bytes(bytes_)

        self.assertEqual(truncmsg.header.tc, 1)
        self.assertEqual(len(bytes_), 512)


def run_tests():
    """Run the DNS resolver and server tests"""
    parser = ArgumentParser(description="DNS Tests")
    parser.add_argument("-s", "--server", type=str, default="localhost",
                        help="the address of the server")
    parser.add_argument("-p", "--port", type=int, default=5001,
                        help="the port of the server")
    args, extra = parser.parse_known_args()
    global PORT, SERVER
    PORT = args.port
    SERVER = args.server

    # Pass the extra arguments to unittest
    sys.argv[1:] = extra

    # Start test suite
    unittest.main()


if __name__ == "__main__":
    run_tests()
