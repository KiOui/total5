#!/usr/bin/env python3

"""DNS Resolver

This module contains a class for resolving hostnames. You will have to implement
things in this module. This resolver will be both used by the DNS client and the
DNS server, but with a different list of servers.
"""

import heapq
import logging
import socket

from dns.classes import Class
from dns.message import Message, Question, Header
from dns.name import Name
from dns.resource import ResourceRecord, NSARecord
from dns.rtypes import Type

DEFAULT_BOOTSTRAP = "8.8.8.8"


class Resolver:
    """DNS resolver"""

    def __init__(self, timeout, caching, ttl, cache):
        """Initialize the resolver

        Args:
            caching (bool): caching is enabled if True
            ttl (int): ttl of cache entries (if > 0)
        """
        self.timeout = timeout
        self.caching = caching
        self.ttl = ttl
        self.cache = cache

    def gethostbyname(self, hostname, nameservers=None):
        """ The required library function for the assignment, only with added optional nameservers parameter

        :param hostname: The hostname to be resolved
        :param nameservers: The root servers to use
        :return: A FQDN for the hostname, the ips of the hostname (if resolved) and the aliases of the hostname (if present)
        """

        answers = self.getanswersbyname(hostname, nameservers=nameservers, lookup_type=Type.A, class_=Class.IN)

        # Parsing of answers
        FQDN = ""
        ips = []
        aliases = []

        for record in answers:
            if record.type_ == Type.A:
                ips.append(str(record.rdata.address))
                FQDN = str(record.name)
            elif record.type_ == Type.CNAME:
                aliases.append(str(record.name))

        return FQDN, ips, aliases

    def getroot(self) -> [NSARecord]:
        """
        :return: Returns the root servers
        """

        records = [NSARecord('.', "a.root-servers.net.", "198.41.0.4"),
                   NSARecord('.', "b.root-servers.net.", "199.9.14.201"),
                   NSARecord('.', "c.root-servers.net.", "192.33.4.12"),
                   NSARecord('.', "d.root-servers.net.", "199.7.91.13"),
                   NSARecord('.', "e.root-servers.net.", "192.203.230.10"),
                   NSARecord('.', "f.root-servers.net.", "192.5.5.241"),
                   # At the time of writing, this server did (for at least a week) not respond to any queries
                   # Feel free to uncomment for testing purposes
                   # NSARecord('.', "g.root-servers.net.", "192.112.36.4"),
                   NSARecord('.', "h.root-servers.net.", "198.97.190.53"),
                   NSARecord('.', "i.root-servers.net.", "192.36.148.17"),
                   NSARecord('.', "j.root-servers.net.", "192.58.128.30"),
                   NSARecord('.', "k.root-servers.net.", "193.0.1.129"),
                   NSARecord('.', "l.root-servers.net.", "199.7.83.42"),
                   NSARecord('.', "m.root-servers.net.", "202.12.27.33")]

        return records

    def getanswersbyname(self, hostname, nameservers=None, lookup_type=Type.A, class_=Class.IN, CNAME_list=set()):
        """ Function used for internal lookups, as it returns more information than gethostbyname

        :param hostname: The hostname to be resolved, if this hostname does not end with a '.', this will get appended
        :param nameservers: The nameservers to use, if the nameservers are not set, the hardcoded root servers will be used
        :param lookup_type: The type of the records to look for
        :param class_: The class of the records to look for
        :param CNAME_list: The list of CNAMEs already encountered (if this function gets called recursively)
        :return: A list of records with type lookup_type and CNAME
        """

        if nameservers is None:
            nameservers = self.getroot()

        # Append a '.' if the hostname does not end with one
        if hostname[len(hostname) - 1] != '.':
            hostname = hostname + '.'

        if self.caching:
            cache = self.cache.lookup(hostname, lookup_type, class_, 0)
            if len(cache) > 0:
                logging.info("Found record in cache!")
                return cache

        heapq.heapify(nameservers)
        answers = self.queue_lookup(hostname, nameservers, CNAME_list, lookup_type=lookup_type, class_=class_)

        return answers

    def request(self, dname, type_=Type.A, class_=Class.IN, ns=None) -> ([ResourceRecord],
                                                                         [ResourceRecord],
                                                                         [ResourceRecord]):

        """
        This function handles a single request
        :param dname: The name to resolve for this request
        :param type_: The type to resolve
        :param class_: The class to resolve
        :param ns: The nameserver to use, if this is not set, the default nameserver will be used
        :return: The splitted query
        """
        if self.caching:
            cache = self.cache.lookup(dname, type_, class_, 0)
            if len(cache) > 0:
                return cache, [], []

        rd = 0
        if ns is None:
            ns = DEFAULT_BOOTSTRAP
            rd = 1
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(self.timeout)

        # Create and send query
        question = Question(Name(dname), type_, class_)
        header = Header(9001, 0, 1, 0, 0, 0)
        header.qr = 0
        header.opcode = 0
        header.rd = rd
        query = Message(header, [question])
        sock.sendto(query.to_bytes(), (ns, 53))
        try:
            data = sock.recv(512)
        except socket.timeout:
            logging.warning("Request timed out")
            sock.close()
            return [], [], []

        response = Message.from_bytes(data)

        if self.caching:
            for record in response.answers:
                self.cache.add_record(record)
            for record in response.additionals:
                self.cache.add_record(record)
        sock.close()
        return response.answers, response.authorities, response.additionals

    def queue_lookup(self, hostname, nameserver_queue, CNAME_list, lookup_type=Type.A, class_=Class.IN):
        """
        This function handles the main loop for looking up a domain, the nameserver_queue will be used as a priority
        queue of nameservers

        :param hostname: The hostname to resolve
        :param nameserver_queue: The nameserver queue to start with
        :param CNAME_list: The list of CNAMEs already encountered (if this function gets called recursively)
        :param lookup_type: The type of the records to look for
        :param class_: The class of the records to look for
        :return: A list of records with type lookup_type and CNAME
        """

        # This list will be used to keep track of all nameserver records that we've already queried
        NS_list = set()

        while len(nameserver_queue) > 0:

            # Get the next nameserver
            next_ns_as_record = heapq.heappop(nameserver_queue)
            next_ns = next_ns_as_record.ip

            if next_ns is None:
                # The nameserver has no IP yet so we should resolve it next (*1)
                logging.info("NS address is not resolved yet, resolving now...")
                lookup_ns = self.getanswersbyname(str(next_ns_as_record.nsdname), lookup_type=Type.A, class_=class_)
                if len(lookup_ns) > 0:
                    for record in lookup_ns:
                        if record.type_ == Type.A:
                            if not record.rdata.address in NS_list:
                                to_add = NSARecord(next_ns_as_record, next_ns_as_record.nsdname,
                                                   ip=record.rdata.address)
                                nameserver_queue.append(to_add)
                    heapq.heapify(nameserver_queue)

            else:
                # The nameserver has an IP and can thus be used for the next lookup

                # We will first add the nameserver to all nameservers we have already queried
                NS_list = NS_list | set([next_ns])

                logging.debug("Now looking up {}".format(hostname))
                logging.debug("Nameserver: {}".format(next_ns))
                logging.debug("Name: {}\n".format(next_ns_as_record.nsdname))

                ans, auth, add = self.request(hostname, type_=lookup_type, class_=class_, ns=next_ns)
                logging.debug("Response:\nANS\tAUTH\tADD")
                logging.debug(str(len(ans)) + "\t" + str(len(auth)) + "\t" + str(len(add)) + "\n")

                if len(ans) > 0:
                    return self.handle_answers(hostname, ans, lookup_type, class_, CNAME_list)

                # We have no answers so we should look for new nameservers
                for record in auth:
                    if record.type_ == Type.NS:
                        ns_name = str(record.rdata.nsdname)

                        # We have found a new nameserver thus we should now look if a record in the addtional section
                        # has the address of this nameserver
                        addresses = []
                        for a in add:
                            if str(ns_name) == str(a.name) and a.type_ == Type.A:
                                addresses.append(str(a.rdata.address))

                        # We add all addresses of the nameserver to the nameserver_queue if they are not already in
                        # our NS_list
                        if len(addresses) > 0:
                            for address in addresses:
                                if not address in NS_list:
                                    to_add = NSARecord(record.name, record.rdata.nsdname, ip=address)
                                    nameserver_queue.append(to_add)
                        else:
                            # If no address was found, we will just add it without an address (and it will get resolved
                            # later at (*1))
                            nameserver_queue.append(NSARecord(record.name, record.rdata.nsdname))

                # The queue must put the highest order nameserver in the first place
                heapq.heapify(nameserver_queue)

        return []

    def handle_answers(self, hostname: str, records, lookup_type: Type, class_: Class, CNAME_list):
        """
        Looks through the answer section for lookup_type records with hostname as name

        Cases: - lookup_type record with answer (1)
               - CNAME record with lookup_type record (2)
               - CNAME record without lookup_type record (3)

        :param hostname: The hostname to find in the answer section
        :param records: The records that were returned in the answer section
        :param lookup_type: The type of records to look for
        :param class_: The class of records to look for
        :param CNAME_list: The list of CNAMEs already encountered (if this function gets called recursively)
        :return:
        """

        if hostname in CNAME_list:
            return []
        else:
            CNAME_list = CNAME_list | set([hostname])

        logging.debug("Answers were provided, now searching for: " + hostname)

        # Case (1)
        for record in records:
            if record.type_ == lookup_type and str(record.name) == hostname and record.class_ == class_:
                logging.debug("Found answers!")
                return records

        # Case (2)
        for record in records:
            if record.type_ == Type.CNAME and str(record.name) == hostname and record.class_ == class_:
                logging.debug("Found CNAME, searching for CNAME in answers!")
                retvalue = self.handle_answers(str(record.rdata.cname), records, lookup_type, class_, CNAME_list)
                if len(retvalue) > 0:
                    return retvalue

        # Case (3)
        for record in records:
            if record.type_ == Type.CNAME and str(record.name) == hostname and record.class_ == class_:
                logging.debug("Found CNAME without A record in ans, now looking up CNAME: " + str(record.name))
                retvalue = self.getanswersbyname(str(record.rdata.cname), lookup_type=lookup_type, class_=class_,
                                                 CNAME_list=CNAME_list)
                if len(retvalue) > 0:
                    return retvalue + [record]

        return []
