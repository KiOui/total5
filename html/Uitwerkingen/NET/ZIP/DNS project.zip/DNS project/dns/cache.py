#!/usr/bin/env python3

"""A cache for resource records

This module contains a class which implements a cache for DNS resource records,
you still have to do most of the implementation. The module also provides a
class and a function for converting ResourceRecords from and to JSON strings.
It is highly recommended to use these.
"""

import json
import time
import logging

from dns.rtypes import Type
from dns.resource import ResourceRecord


class RecordCache:
    """Cache for ResourceRecords"""

    def __init__(self, ttl):
        """Initialize the RecordCache

        Args:
            ttl (int): TTL of cached entries (if > 0)
        """
        self.records = []
        self.ttl = ttl

        #Maximum recursion depth for CNAMES
        self.MAX_DEPTH = 10
        self.read_cache_file()

    def lookup(self, dname, type_, class_, recursion_depth):
        """Lookup resource records in cache

        Lookup for the resource records for a domain name with a specific type
        and class.

        Args:
            dname (str): domain name
            type_ (Type): type
            class_ (Class): class
        """
        retvalue = []

        if (recursion_depth >= self.MAX_DEPTH):
            return []

        self.delete_invalid_cache()



        for record in self.records:
            if str(record.name) == str(dname) and record.type_ == type_ and record.class_ == class_:
                retvalue = retvalue + [record]
            elif str(record.name) == str(dname) and record.type_ == Type.CNAME and type_ == Type.A and record.class_ == class_:
                #We are searching for an A record, we can thus also search for a CNAME for this A record
                cname_lookup = self.lookup(str(record.rdata.cname), Type.A, class_, recursion_depth+1)
                retvalue = retvalue + cname_lookup + [record]
        return retvalue

    def record_valid(self, record):
        """Checks if a packet is dead

        Returns True if a packet is still alive

        Args:
            record (ResourceRecord): record to check
        """
        now = time.time()
        max_alive = record.ttl + record.timestamp

        return now <= max_alive

    def delete_invalid_cache(self):
        """Checks if a packet is dead

        Deletes invalid cache
        """
        self.records = list(filter(lambda x: self.record_valid(x), self.records))

    def remove_all(self):
        self.records = []

    def add_record(self, record):
        """Add a new Record to the cache

        Args:
            record (ResourceRecord): the record added to the cache
        """

        record.timestamp = time.time()

        if self.ttl > 0:
            record.ttl = self.ttl

        if (record.type_ == Type.CNAME or record.type_ == Type.A):

            for already_stored_record in self.records:
                if (already_stored_record.name == record.name and already_stored_record.type_ == Type.CNAME):
                    if (already_stored_record.timestamp <= record.timestamp):
                        self.records.remove(already_stored_record)
                    else:
                        return
                elif (already_stored_record.name == record.name and already_stored_record.type_ == Type.A):
                    if (already_stored_record.rdata.address == record.rdata.address and already_stored_record.timestamp <= record.timestamp):
                        self.records.remove(already_stored_record)
                    elif (already_stored_record.rdata.address == record.rdata.address):
                        return
            logging.info("Added" + str(record))
            self.records.append(record)

    def read_cache_file(self):
        """Read the cache file from disk"""
        dcts = []
        try:
            with open("cache", "r") as file_:
                dcts = json.load(file_)
        except:
            logging.error("Could not read cache")
        self.records = [ResourceRecord.from_dict(dct) for dct in dcts]
        self.delete_invalid_cache()

    def write_cache_file(self):
        """Write the cache file to disk"""
        dcts = []
        for record in self.records:
            if (self.record_valid(record)):
                dcts.append(record.to_dict())

        try:
            with open("cache", "w") as file_:
                json.dump(dcts, file_, indent=2)
        except:
            logging.error("Could not write cache")
