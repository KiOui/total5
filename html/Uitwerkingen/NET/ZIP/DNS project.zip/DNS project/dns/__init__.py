#!/usr/bin/env python3

DEFAULT_TTL = 180


def hexdump(data):
    for i, x in enumerate(data):
        print('{:2} '.format(hex(x)[2:]), end='')
        if i % 64 == 0 and i != 0:
            print(" {}".format(data[i - 64:i]))
    print()
