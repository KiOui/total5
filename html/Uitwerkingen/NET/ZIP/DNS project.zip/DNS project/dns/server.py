#!/usr/bin/env python3

"""A recursive DNS server

This module provides a recursive DNS server. You will have to implement this
server using the algorithm described in section 4.3.2 of RFC 1034.
"""
import logging
import socket
from threading import Thread

from dns.cache import RecordCache
from dns.message import Message, Header
from dns.resolver import Resolver
from dns.zone import Zone

RECURSION_AVAILABLE = 1


class RequestHandler(Thread):
    """A handler for requests to the DNS server"""

    def __init__(self, sock, data, zones, ttl, cache, caching=True):
        """Initialize the handler thread"""
        super().__init__()
        self.daemon = True
        self.sock = sock
        self.data, self.address = data
        self.zones = zones
        self.ttl = ttl
        self.cache = cache
        self.caching = caching

    def rcode(self, rcode, ident):
        """Generate a message with error code but no content"""
        header = Header(ident, 0, 0, 0, 0, 0)
        header.rcode = rcode
        return Message(header).to_bytes()

    def answer(self, msg):
        aa = 0
        rcode = 0
        answers = []
        additionals = []
        authoritive = []
        if msg.header.rd and RECURSION_AVAILABLE:
            # Do a recursive lookup when enabled and asked for
            resolver = Resolver(5, self.caching, self.ttl, self.cache)
            for question in msg.questions:
                answers, additionals, authoritive = resolver.request(str(question.qname), type_=question.qtype,
                                                                     class_=question.qclass)
        else:
            # Else look in the zonefile
            for question in msg.questions:
                if question.qname in self.zones.records:
                    records = self.zones.records[question.qname]
                    for record in records:
                        if question.qtype == record.type_ and question.qclass == record.class_:
                            answers.append(record)
                            # Set the authoritive answer bit for things found in the zonefile
                            aa = 1
        message = Message(
            header=Header(flags=0, ident=msg.header.ident, an_count=len(answers), ar_count=len(additionals),
                          ns_count=len(authoritive), qd_count=len(msg.questions)).setflags(1, aa, 0, msg.header.rd,
                                                                                           RECURSION_AVAILABLE,
                                                                                           opcode=msg.header.opcode,
                                                                                           rcode=rcode),
            answers=answers, authorities=authoritive, additionals=additionals, questions=msg.questions)
        self.sock.sendto(message.to_bytes(), self.address)

    def run(self):
        """Run the handler thread"""
        try:
            msg = Message.from_bytes(self.data)
        except:  # TODO: figure out the exact exception thrown when parsing fails
            self.sock.sendto(self.rcode(1, 0), self.address)

        for question in msg.questions:
            logging.info("Qname: {} class: {} type: {}".format(question.qname, question.qclass, question.qtype))
        if not msg.header.qr == 0:
            self.sock.sendto(self.rcode(4, msg.header.ident), self.address)
            return  # Do not reply to answers
        if not msg.header.opcode == 0:
            self.sock.sendto(self.rcode(4, msg.header.ident), self.address)
            return  # Server only supports queries.
        try:
            self.answer(msg)
        except:  # TODO: only catch actual server exceptions
            self.sock.sendto(self.rcode(2, msg.header.ident), self.address)


class Server:
    """A recursive DNS server"""

    def __init__(self, ip, port, caching, ttl, zonefile):
        """Initialize the server

        Args:
            port (int): port that server is listening on
            caching (bool): server uses resolver with caching if true
            ttl (int): ttl for records (if > 0) of cache
        """
        self.caching = caching
        self.ttl = ttl
        self.ip = ip
        self.port = port
        self.zonefile = zonefile
        self.cache = RecordCache(0)
        self.done = False

    def serve(self):
        """Start serving requests

        This function will start a new thread for each DNS message that is received. As python has the global
        interpreter lock, we do not have to worry a lot about data races. Only duplicated cache elements could arise,
        but we did not have the time to implement better concurrent caching.
        """
        zones = Zone()
        zones.read_master_file(self.zonefile)
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.bind((self.ip, self.port))
        while not self.done:
            RequestHandler(sock, sock.recvfrom(512), zones, self.ttl, self.cache, self.caching).start()

    def shutdown(self):
        """Shut the server down"""
        self.done = True
