#!/usr/bin/env python3

"""DNS TYPE and QTYPE values

This module contains an Enum for TYPE and QTYPE values. This Enum also contains
a method for converting Enum values to strings. See sections 3.2.2 and 3.2.3 of
RFC 1035 for more information.
"""

from enum import IntEnum

from dns.name import Name


class Type(IntEnum):
    """DNS TYPE and QTYPE

    Usage:
        >>> Type.A
        <Type.A: 1>
        >>> Type(2)
        <Type.NS: 2>
        >>> str(Type.A)
        'A'
        >>> Type['SOA']
        <Type.SOA: 6>
        >>> Type.MX == 15
        True
    """

    A = 1
    NS = 2
    CNAME = 5
    SOA = 6
    PTR = 12
    MX = 15
    TXT = 16
    AAAA = 28
    ANY = 255
    OTHER = 0

    def __str__(self):
        return self.name

    @staticmethod
    def parse_A(parts):
        from dns.resource import ARecordData  # Late imports becuase this file is imported by dns.resource
        return ARecordData(address=parts[0])

    @staticmethod
    def parse_NS(parts):
        from dns.resource import NSRecordData
        return NSRecordData(nsdname=Name(parts[0]))

    @staticmethod
    def parse_CNAME(parts):
        from dns.resource import CNAMERecordData
        return CNAMERecordData(cname=Name(parts[0]))

    @staticmethod
    def parse_SOA(parts):
        from dns.resource import SOARecordData
        return SOARecordData(mname=parts[0], rname=parts[1], serial=int(parts[2]), refresh=int(parts[3]),
                             retry=int(parts[4]), expire=int(parts[5]), minimum=int(parts[6]))

    @staticmethod
    def parse_default(parts):
        from dns.resource import GenericRecordData
        return GenericRecordData(data=(' '.join(parts)).encode('utf-8'))

    def parse_rdata(self, parts):
        try:
            return getattr(self, 'parse_{}'.format(self.name))(parts)
        except AttributeError:
            return self.parse_default(parts)
