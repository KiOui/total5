#!/usr/bin/env python3

"""Zones of domain name space

See section 6.1.2 of RFC 1035 and section 4.2 of RFC 1034.
Instead of tree structures we simply use dictionaries from domain names to
zones or record sets.

These classes are merely a suggestion, feel free to use something else.
"""
import csv

from dns import DEFAULT_TTL
from dns.classes import Class
from dns.name import Name
from dns.resource import ResourceRecord
from dns.rtypes import Type


class Catalog:
    """A catalog of zones"""

    def __init__(self):
        """Initialize the catalog"""
        self.zones = {}

    def add_zone(self, name, zone):
        """Add a new zone to the catalog

        Args:
            name (str): root domain name
            zone (Zone): zone
        """
        self.zones[name] = zone


class Zone:
    """A zone in the domain name space"""

    def __init__(self):
        """Initialize the Zone """
        self.records = {}

    def add_node(self, name, record_set):
        """Add a record set to the zone

        Args:
            name (Name): domain name
            record_set ([ResourceRecord]): resource records
        """
        self.records[name] = record_set

    def read_master_file(self, filename):
        """Read the zone from a master file

        See section 5 of RFC 1035.

        Args:
            filename (str): the filename of the master file
        """
        with open(filename) as f:
            for line in f:
                entry = line.split(';')[0]
                if entry.strip() == '':
                    continue
                record = parse_record(entry)
                self.records.setdefault(record.name, []).append(record)


def is_type(word):
    try:
        _ = Type[word]
        return True
    except KeyError:
        return False


def is_class(word):
    try:
        _ = Class[word]
        return True
    except KeyError:
        return False


class InvalidZoneFile(Exception):
    pass


def parse_record(line):
    parts = csv.reader([line], delimiter=' ').__next__()
    domain = Name(parts[0])
    ttl = DEFAULT_TTL
    parts = parts[1:]
    if parts[0].isdigit():  # TTL first with no domain name
        ttl = int(parts[0])
        parts = parts[1:]
    class_ = Class.IN
    if is_class(parts[0]):
        class_ = Class[parts[0]]
        parts = parts[1:]
    if not is_type(parts[0]):
        raise InvalidZoneFile()
    type_ = Type[parts[0]]
    rdata = type_.parse_rdata(parts[1:])
    return ResourceRecord(name=domain, ttl=ttl, class_=class_, type_=type_, rdata=rdata)
