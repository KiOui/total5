#!/usr/bin/env python3

""" DNS server

This script contains the code for starting a DNS server.
"""
import logging
from argparse import ArgumentParser

from dns.server import Server


def run_server():
    parser = ArgumentParser(description="DNS Server")
    parser.add_argument("-c", "--caching", action="store_true",
                        help="Enable caching")
    parser.add_argument("-t", "--ttl", metavar="time", type=int, default=0,
                        help="TTL value of cached entries (if > 0)")
    parser.add_argument("-s", "--serve-ip", type=str, default="localhost",
                        help="The IP address in string format of the name server")
    parser.add_argument("-p", "--port", type=int, default=5353,
                        help="Port which server listens on")
    parser.add_argument("-z", "--zone-file", type=str, default="zonefile",
                        help="The location of the zonefile to use")
    parser.add_argument("-v", "--verbose", action='store_true',
                        help="Enable verbose logging")
    args = parser.parse_args()

    if args.verbose:
        logging.basicConfig(level=logging.DEBUG)

    server = Server(args.serve_ip, args.port, args.caching, args.ttl, args.zone_file)
    try:
        server.serve()
    except KeyboardInterrupt:
        server.shutdown()
        print()


if __name__ == "__main__":
    run_server()
