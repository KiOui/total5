#!/usr/bin/env python3

""" Simple DNS client

A simple example of a client using the DNS resolver.
"""

import logging

from argparse import ArgumentParser

from dns.cache import RecordCache
from dns.resolver import Resolver
from dns.resolver import ResourceRecord
from dns.rtypes import Type
from dns.classes import Class


def resolve():
    """Resolve a hostname using the resolver """
    parser = ArgumentParser(description="DNS Client")
    parser.add_argument("hostname", help="hostname to resolve")
    parser.add_argument("-o", "--timeout", metavar="time", type=int, default=5,
                        help="resolver timeout")
    parser.add_argument("-c", "--caching", action="store_true",
                        help="Enable caching")
    parser.add_argument("-t", "--ttl", metavar="time", type=int, default=0,
                        help="TTL value of cached entries (if > 0)")
    parser.add_argument("-v", "--verbose", action='store_true',
                        help="Enable verbose logging")
    args = parser.parse_args()

    if args.verbose:
        logging.basicConfig(level=logging.DEBUG)

    cache = RecordCache(0)
    resolver = Resolver(args.timeout, args.caching, args.ttl, cache)
    (FQDN, ips, aliases) = resolver.gethostbyname(args.hostname)
    print(FQDN)
    print("IP addresses:")
    for address in ips:
        print("\t{}".format(address))
    print("Aliases:")
    for alias in aliases:
        print("\t{}".format(alias))
    logging.info("FQDN: " + FQDN)
    logging.info("IP list: ")
    logging.info(ips)
    logging.info("Aliases: ")
    logging.info(aliases)

    cache.write_cache_file()
    # print(hostname)
    # print(aliaslist)
    # print(ipaddrlist)


if __name__ == "__main__":
    resolve()
