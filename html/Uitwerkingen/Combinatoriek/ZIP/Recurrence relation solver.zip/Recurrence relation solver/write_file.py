FILE_START = "sdir := n -> "
FILE_END = ";"


def write_to_file(file_name, to_write):
    file = open(file_name, 'w')
    file.write(FILE_START + to_write + FILE_END)
    file.close()
