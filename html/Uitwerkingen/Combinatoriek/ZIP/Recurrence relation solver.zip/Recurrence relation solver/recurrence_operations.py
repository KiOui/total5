from sympy import *
import re

OPEN_LEVEL = '('
CLOSE_LEVEL = ')'
START_LEVEL = 0
RECURRENCE_NAME = 's'
FORM_SN = "s(n-x)"
ZERO = "0"
MAX_DEGREE = 5

LIST_DELETE_SOLUTION = ["sqrt"]


# Split recurrence_relation in terms, output is written to splitted
def split_parts(recurrence_relation, splitted):
    recurrence_relation = recurrence_relation.replace(' ', '')
    to_solve = recurrence_relation.split('=')[1]
    level = START_LEVEL

    terms = [""]
    next_term = 0
    o = 0

    for i in range(0, len(to_solve)):
        if to_solve[i] == OPEN_LEVEL:
            level = level + 1
        elif to_solve[i] == CLOSE_LEVEL:
            level = level - 1

        if (not (i == 0)) and level == START_LEVEL and (to_solve[i] == '+' or to_solve[i] == '-'):
            next_term = next_term + 1
            o = 0
            terms.append("")

        if not (level == START_LEVEL and to_solve[i] == '+'):
            terms[next_term] += to_solve[i]
            o = o + 1

    del splitted[:]

    for i in range(0, len(terms)):
        splitted.append(terms[i])
    return True


# Outputs the terms of F(n) to terms_Fn and the terms of the homogeneous part to terms_homogeneous
def split_inhomogeneous_part(splitted_recurrence_relation, write_fn, terms_homogeneous):
    del write_fn[:]
    del terms_homogeneous[:]

    for i in range(0, len(splitted_recurrence_relation)):

        homogeneous = False
        for o in range(0, len(splitted_recurrence_relation[i])):
            if splitted_recurrence_relation[i][o] == RECURRENCE_NAME:
                homogeneous = True
                break

        if homogeneous:
            terms_homogeneous.append(splitted_recurrence_relation[i])
        else:
            write_fn.append(splitted_recurrence_relation[i])


# Will create a list in the form of:
# Example: 4 -> 4*r^2
def char_equation(terms_homogeneous, write_list):
    biggest_n = find_biggest_n(terms_homogeneous)
    splitted_in_order = []
    split_equation(terms_homogeneous, splitted_in_order, biggest_n)
    temp_string = "r^" + str(biggest_n)
    write_list.append(temp_string)
    for i in range(0, len(splitted_in_order)):
        if splitted_in_order[i] is not ZERO:
            if biggest_n - i - 1 == 0:
                temp_string = splitted_in_order[i]
            else:
                temp_string = splitted_in_order[i] + "*r^" + str(biggest_n - i - 1)
            write_list.append(temp_string)


def find_n(term):
    start_s = -1
    for m in range(0, len(term)):
        if term[m] == RECURRENCE_NAME:
            start_s = m
            break
    if start_s == -1:
        return -1

    start_level = -1
    stop_level = -1
    for m in range(start_s, len(term)):
        if term[m] == OPEN_LEVEL:
            start_level = m
        elif term[m] == CLOSE_LEVEL and start_level > -1:
            stop_level = m
            break

    current_n = ""
    for m in range(start_level, stop_level):
        if term[m] == '-':
            current_n = term[m + 1:stop_level]

    return int(current_n)


# Finds the biggest value for [...] in every s(n-[...])
def find_biggest_n(terms_homogeneous):
    biggest_n = -1
    for i in range(0, len(terms_homogeneous)):
        start_s = -1
        for m in range(0, len(terms_homogeneous[i])):
            if terms_homogeneous[i][m] == RECURRENCE_NAME:
                start_s = m
                break
        if start_s == -1:
            return -1

        start_level = -1
        stop_level = -1
        for m in range(start_s, len(terms_homogeneous[i])):
            if terms_homogeneous[i][m] == OPEN_LEVEL:
                start_level = m
            elif terms_homogeneous[i][m] == CLOSE_LEVEL and start_level > -1:
                stop_level = m
                break

        current_n = ""
        for m in range(start_level, stop_level):
            if terms_homogeneous[i][m] == '-':
                current_n = terms_homogeneous[i][m + 1:stop_level]

        temp_n = int(current_n)
        if temp_n > biggest_n:
            biggest_n = temp_n

    return biggest_n


# Splits the equation terms_homogeneous into write_list while deleting all "*s(n-[...])" or "s(n-[...])*"
# Example: 4*s(n-1) will become: 4
def split_equation(terms_homogeneous, write_list, biggest_n):
    for i in range(1, biggest_n + 1):
        sn = FORM_SN
        sn = sn.replace("x", str(i))
        for m in range(0, len(terms_homogeneous)):
            if terms_homogeneous[m].find(sn) > -1:
                temp = terms_homogeneous[m]
                sn = "*" + sn
                temp = temp.replace(sn, '')
                sn = sn[1:]
                sn = sn + "*"
                temp = temp.replace(sn, '')
                sn = sn[:(len(sn) - 1)]
                temp = temp.replace(sn, '')
                if temp is not "":
                    write_list.append(temp)
                else:
                    write_list.append("1")
                break
            elif m == len(terms_homogeneous) - 1:
                write_list.append(ZERO)


# Replaces ^ by ** to fit into the roots() function of sympy
def replace_power_list(terms_equation):
    for i in range(0, len(terms_equation)):
        terms_equation[i] = terms_equation[i].replace("^", "**")


# Makes the characteristic equation out of a list of parameters
def build_char_equation(terms_equation):
    retvalue = terms_equation[0]
    for i in range(1, len(terms_equation)):
        if terms_equation[i][0] == '-':
            retvalue = retvalue + "+" + terms_equation[i][1:]
        else:
            retvalue = retvalue + "-" + terms_equation[i]

    return retvalue


# Takes a dictionary with roots and multiplicities and makes the general solution
def make_general_solution(dictionary, general_solution, used_symbols):
    keys = list(dictionary)
    for i in range(0, len(keys)):
        to_add = "("
        for j in range(0, dictionary.get(keys[i])):
            used_symbols.append(Symbol("a_" + str(i) + str(j)))
            if j == 0:
                to_add = to_add + "a_" + str(i) + str(j)
            elif j == 1:
                to_add = to_add + "a_" + str(i) + str(j) + "*n"
            else:
                to_add = to_add + "a_" + str(i) + str(j) + "*n^" + str(j)
            if j is not (dictionary.get(keys[i]) - 1):
                to_add = to_add + "+"
        to_add = to_add + ")*(" + str(keys[i]) + ")^n"
        general_solution.append(to_add)


# Converts a list to a string, concatenated with +'es
def list_to_eq_string(list_eq):
    eq = ""
    for i in range(0, len(list_eq)):
        if i == 0:
            eq += "(" + list_eq[i] + ")"
        else:
            eq += "+" + "(" + list_eq[i] + ")"
    return eq


# Builds the equation for a particular solution
def build_particular_eq(equation, solution, max_degree):
    new_eq = equation
    solution = "(" + solution + ")"
    for i in range(1, max_degree + 1):
        solution_new = solution.replace("n", "(n-" + str(i) + ")")
        new_eq = new_eq.replace("s(n-" + str(i) + ")", solution_new)
    return new_eq + " - " + solution


def replace_power_string(eq):
    return eq.replace("^", "**")


def construct_equation(start_degree, argument_list):
    ret_value = ""

    for i in range(0, start_degree + 1):
        next_power = start_degree - i
        if i is 0:
            ret_value = ret_value + str(argument_list[i])
        else:
            ret_value = ret_value + "+" + str(argument_list[i])

        if next_power is 0:
            return ret_value
        elif next_power is 1:
            ret_value = ret_value + "*n"
        else:
            ret_value = ret_value + "*n^" + str(next_power)


def replace_terms(equation, dictionary):
    keys = list(dictionary)
    for i in range(0, len(keys)):
        replace_with = "(" + str(dictionary.get(keys[i])) + ")"
        replace_this = str(keys[i])
        equation = equation.replace(replace_this, replace_with)

    return equation


def solve_particular_exponential(particular_part, homogeneous):
    a = Symbol("a")
    b = Symbol("b")
    c = Symbol("c")
    d = Symbol("d")
    e = Symbol("e")
    f = Symbol("f")
    g = Symbol("g")
    h = Symbol("h")
    i = Symbol("i")
    j = Symbol("j")
    k = Symbol("k")
    l = Symbol("l")
    m = Symbol("m")
    o = Symbol("o")
    p = Symbol("p")

    print("\n\nStarting solver...")

    while True:
        
        print("\n\nParticular part: ", particular_part)
        user_input = input("Please enter the form of the particular solution: ")

        equation = user_input

        print("\nNow solving with: ", equation)
        write_list = []
        replace_particular(homogeneous, equation, write_list)
        write_list = write_list + particular_part

        equation_string = ""

        for i in range(0, len(write_list)):
            if len(write_list[i]) is not 0 and write_list[i][0] == '-':
                equation_string = equation_string + write_list[i]
            else:
                equation_string = equation_string + "+" + write_list[i]

        equation_string = replace_power_string(equation_string)

        try:
            dictionary = solve(equation_string, a, b, c, d, e, f, g, h, i, j, k, l, m, o, p, simplify=True,
                               particular=True, quick=True)
        except:
            return None

        print("--------------------------------\nFound solution: ", dictionary)

        while True:
            input_user = input("Please confirm this solution, (2=stop, 1=continue, 0=again): ")

            if input_user == "1":
                if type(dictionary) == list:
                    print("Not sure whether this is true, but we'll try it...")
                    dictionary = dictionary[0]

                keys = list(dictionary)

                for i in range(0, len(keys)):
                    current_key = str(keys[i])
                    replace_with = "(" + str(dictionary.get(keys[i])) + ")"
                    equation = equation.replace(current_key, replace_with)

                return equation
            elif input_user == "0":
                print("Restarting...")
                break
            elif input_user == "2":
                return None
            else:
                print("Wrong input!")


def solve_particular_non_exponential(particular_part, homogeneous):
    a = Symbol("a")
    b = Symbol("b")
    c = Symbol("c")
    d = Symbol("d")
    e = Symbol("e")
    f = Symbol("f")
    g = Symbol("g")
    h = Symbol("h")
    i = Symbol("i")
    j = Symbol("j")
    k = Symbol("k")
    l = Symbol("l")
    m = Symbol("m")
    o = Symbol("o")
    p = Symbol("p")
    arguments = [a, b, c, d, e, f, g, h, i, j, k, l, m, o, p]

    print("\nStarting solver...")

    print("\nParticular part: ", particular_part)

    degree_sol = 0

    while True:

        if degree_sol >= len(arguments):
            print("-----------------------------------------------\nNo solution was found, please restart")
            return None
        elif degree_sol >= 5:
            user_input = input(str("Degree of the solution is exceeding the maximum degree of " + str(MAX_DEGREE) + ", please confirm the next computations (0: continue, 1: stop):"))
            if user_input == 1:
                return None

        equation = construct_equation(degree_sol, arguments)
        print("\nNow solving with: ", equation)
        write_list = []
        replace_particular(homogeneous, equation, write_list)
        write_list = write_list + particular_part

        equation_string = ""

        for i in range(0, len(write_list)):
            if len(write_list[i]) is not 0 and write_list[i][0] == '-':
                equation_string = equation_string + write_list[i]
            else:
                equation_string = equation_string + "+" + write_list[i]

        equation_string = replace_power_string(equation_string)

        try:
            dictionary = solve(equation_string, a, b, c, d, e, f, g, h, i, j, k, l, m, o, p, simplify=True)
        except:
            return None

        print("--------------------------------\nFound solution: ", dictionary)

        if type(dictionary) == dict:
            print("Solution accepted!")
            keys = list(dictionary)

            for i in range(0, len(keys)):
                current_key = str(keys[i])
                replace_with = "(" + str(dictionary.get(keys[i])) + ")"
                equation = equation.replace(current_key, replace_with)

            return equation
        else:
            print("Solution rejected!")
            print("Restarting...")
            degree_sol = degree_sol + 1

        # Splits the nonhomogeneous parts into an exponential, polynomial and linear portion


def parse_fn(fn, fn_exponential, fn_polynomial):
    del fn_exponential[:]
    del fn_polynomial[:]

    regex = re.compile("\^(?:\(.*n.*\)|n)")
    for i in range(0, len(fn)):
        if regex.search(fn[i]) is not None:
            fn_exponential.append(fn[i])
        else:
            fn_polynomial.append(fn[i])


def parse_initials(oldstart, newstart):
    del newstart[:]

    for i in range(0, len(oldstart)):
        parsedvalue = [oldstart[i][2], oldstart[i].split('=', 1)[1]]
        newstart.append(parsedvalue)


def replace_particular(homogeneous, equation, write_list):
    n = find_biggest_n(homogeneous)
    del write_list[:]
    split_equation(homogeneous, write_list, n)
    write_list.insert(0, "-1")

    for i in range(0, len(write_list)):
        temp_particular = equation
        if i is not 0:
            add_to = "(n-" + str(i) + ")"
            temp_particular = temp_particular.replace("n", add_to)
        write_list[i] = write_list[i] + "*(" + temp_particular + ")"


def fixsqrt(input_string):
    edit = input_string
    while re.search(r"sqrt", edit) is not None:
        start = input_string.find("sqrt")
        start += 5
        count = 1
        edit = input_string[:start].replace("sqrt", "")
        while count > 0:
            if input_string[start] == '(':
                count += 1
            if input_string[start] == ')':
                count -= 1
            edit += input_string[start]
            start += 1
        edit += "^(1/2)" + input_string[start:]
        input_string = edit
    return input_string
