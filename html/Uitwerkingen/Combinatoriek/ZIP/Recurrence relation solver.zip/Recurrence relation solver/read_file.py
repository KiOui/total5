FILE_START = "eqs:="
FORMULA_START = '['
FORMULA_END = ']'
FORMULA_SPLIT = ','


def parse_file(file_name, store_initial_values):
    initial_values = []
    all_values = []

    file_contents = get_file_content(file_name)
    if file_contents is None:
        print("Error opening file")
        return None

    elif not (parse_content(file_contents, all_values)):
        print("Parse error")
        return None

    recurrence = get_recurrence(all_values)

    if recurrence is None:
        print("No recurrence part was found")
        return None

    recurrence_index = get_recurrence_index(all_values)
    all_values.pop(recurrence_index)

    parse_initial_values(all_values, initial_values)

    # All computation is done, copying to the lists is done below:

    for initial_value in initial_values:
        store_initial_values.append(initial_value)

    return recurrence


def parse_initial_values(oldstart, newstart):
    del newstart[:]

    for i in range(0, len(oldstart)):
        parsedvalue = [oldstart[i][2], oldstart[i].split('=', 1)[1]]
        newstart.append(parsedvalue)


def request_file_name():
    file_name = input("Please enter file name: ")
    return file_name


def open_file(file_name):
    try:
        file_open = open(file_name, 'r')
        file_content = file_open.read()
        file_open.close()
    except:
        print("I/O error")
        return None
    return file_content


def get_file_content(file_name):
    file_content = open_file(file_name)
    if file_content is None:
        return None
    else:
        return file_content


def parse_content(file_content, reference_list):
    if file_content is None:
        return False

    file_content = file_content.replace(' ', '')
    file_content = file_content.replace('\n', '')

    # First check for FILE_START at start of file
    for i in range(0, 5):
        if FILE_START[i] != file_content[i]:
            return False

    file_content = file_content[5: len(file_content) - 1]

    # Now check for ']'

    file_stop = None

    for i in range(0, len(file_content)):
        if file_content[i] == FORMULA_END:
            file_stop = i
            break

    if file_stop is None or file_content[0] != FORMULA_START:
        return False

    file_content = file_content[1:file_stop]

    return_value = file_content.split(',')

    for i in range(0, len(return_value)):
        reference_list.append(return_value[i])

    return True


# Returns the recurrence part of the equation (the s(n) part)
def get_recurrence(reference_list):
    for i in range(0, len(reference_list)):
        if reference_list[i][2] == 'n':
            return reference_list[i]
    return None


# Returns the index of the recurrence part of the equation (the s(n) part)
def get_recurrence_index(reference_list):
    for i in range(0, len(reference_list)):
        if reference_list[i][2] == 'n':
            return i
    return -1
