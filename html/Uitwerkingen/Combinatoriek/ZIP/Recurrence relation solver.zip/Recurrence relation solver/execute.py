from read_file import *
from recurrence_operations import *
from write_file import *

ANS_EXTENSION = "-dir"
FILE_EXTENSION = ".txt"


def solve_rec_relation_from_file(file_name):
    initial_values = []

    recurrence = parse_file(file_name, initial_values)

    if recurrence is None:
        print("Failure while parsing file, aborting")
        return -1

    print("File read successfully.")

    rec_eq_splitted = []
    split_parts(recurrence, rec_eq_splitted)

    print("\n\nStep 1 (default form):")
    fn_inhomogeneous_part = []
    homogeneous_parts = []
    step_1(rec_eq_splitted, fn_inhomogeneous_part, homogeneous_parts)
    print("F(n): ", fn_inhomogeneous_part)
    print("Homogeneous part: ", homogeneous_parts)

    print("\n\nStep 2 (characteristic equation):")
    char_eq = []
    step_2(homogeneous_parts, char_eq)
    print(char_eq)

    print("\n\nStep 3 (roots and multiplicities):")
    roots_char_eq = step_3(char_eq)
    print(roots_char_eq)

    print("\n\nStep 4 (general solution):")
    general_solution = []
    used_symbols = []
    step_4(roots_char_eq, general_solution, used_symbols)
    print(general_solution)
    print("Symbols used: ", used_symbols)

    print("\n\nStep 5 (particular solution):")
    particular_solution = step_5(fn_inhomogeneous_part, rec_eq_splitted, homogeneous_parts)
    if particular_solution is -1:
        return -1
    elif particular_solution is not "":
        print(particular_solution)

    print("\n\nStep 6 (combine general and particular):")
    total_solution = step_6(general_solution, particular_solution)
    print(total_solution)

    print("\n\nStep 7 (solve using initial conditions):")
    final_solution = step_7(initial_values, total_solution, used_symbols)
    print("Initial values: ", initial_values)

    print("Final solution", final_solution)

    final_solution = fixsqrt(final_solution)

    print("Final solution without sqrt", final_solution)

    output_file = file_name.replace(".txt", ANS_EXTENSION + ".txt")
    print("\n\nWriting answer to output file:", output_file)
    write_to_file(output_file, final_solution)
    return 0


def step_1(rec_eq_splitted, write_inhomogeneous_part, homogeneous_parts):
    split_inhomogeneous_part(rec_eq_splitted, write_inhomogeneous_part, homogeneous_parts)


def step_2(homogeneous_parts, char_eq):
    char_equation(homogeneous_parts, char_eq)


def step_3(char_eq):
    replace_power_list(char_eq)
    to_solve = build_char_equation(char_eq)
    return roots(to_solve)


def step_4(roots_of_equation, general_solution, used_symbols):
    make_general_solution(roots_of_equation, general_solution, used_symbols)


def step_5(Fn, splitted, homogeneous):
    if len(Fn) is 0:
        print("Skipping step 5 because Fn is empty...")
        return ""
    else:
        print(splitted)
        exponential_part = []
        polynomial_part = []
        parse_fn(Fn, exponential_part, polynomial_part)

        particular_solution = ""

        if len(exponential_part) is not 0:
            to_add = solve_particular_exponential(exponential_part, homogeneous)
            if to_add is None:
                return -1

            particular_solution = to_add
        if len(polynomial_part) is not 0:
            to_add = solve_particular_non_exponential(polynomial_part, homogeneous)
            if to_add is None:
                return -1

            if particular_solution is "":
                particular_solution = to_add
            else:
                if to_add[0] is '-':
                    particular_solution = particular_solution + to_add
                else:
                    particular_solution = particular_solution + "+" + to_add

        return particular_solution


def step_6(general_solution, particular_solution):
    total_solution = general_solution[0]
    for i in range(1, len(general_solution)):
        if len(general_solution[i]) > 0 and general_solution[i][0] == "-":
            total_solution = total_solution + general_solution[i]
        else:
            total_solution = total_solution + "+" + general_solution[i]

    if particular_solution is not "":
        total_solution = total_solution + "+" + particular_solution

    return total_solution


def step_7(initial_values, total_solution, used_symbols):
    equations = []
    for i in range(0, len(initial_values)):
        equations.append((total_solution.replace("n", initial_values[i][0])) + ("-" + initial_values[i][1]))

    solution = solve(equations, used_symbols)

    solution = simplify(solution)

    keys = list(solution)

    for i in range(0, len(keys)):
        current_key = keys[i]
        replace_with = solution.get(current_key)
        total_solution = total_solution.replace(str(current_key), str(replace_with))

    total_solution = total_solution.replace("+-", "-")
    total_solution = total_solution.replace("-+", "-")

    return total_solution


def execute_program_looping():
    list_failed = []

    file_name_start = input("Enter the basename and path of each file (for example '../Test/comass'): ")
    number_start = input("Enter the starting number (for example 00): ")

    file_name = file_name_start + number_start + FILE_EXTENSION

    while True:
        start_ok = input("\n\n\n\nStarting file: " + file_name + ", \t is this ok (0), or not (1). Enter 9 to abort: ")
        if start_ok == "9":
            print("\n\nFailed files: ", list_failed)
            exit(0)
        if start_ok == "1":
            file_name = input("Enter filename: ")
        else:
            if solve_rec_relation_from_file(file_name) != 0:
                list_failed.append(number_start)
                print("\n\n\n\nFailed!: ", list_failed)

            number_start = input("\n\n\n\nEnter next number, previous was " + number_start + ": ")
            file_name = file_name_start + number_start + FILE_EXTENSION


execute_program_looping()
