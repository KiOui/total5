extern int shell(bool prompt);

int main(int argc, char** argv) {
    bool showPrompt = argc == 1;
    return shell(showPrompt);
}

/**
 * Design:
 * Firstly, I made a distinction between normal commands such as 'ls' and 'cat'
 * and the commands 'cd' and 'exit'. This clear distinction can be seen in the
 * shell() function. This function checks if it is either exit or cd,
 * otherwise it will execute the command normally.
 *
 * Secondly, I designed the executeCommand() function so that it takes a pipeIn
 * and pipeOut as in and output. If these pipes are not needed, these pipes will
 * be set to the global variable NO_PIPE. This results in the function executeCommand
 * to be simple and small.
 *
 * Thirdly, the Pipe and File handling is done in the shell() function. This function
 * firstly checks if the command needs to be executed in the background, then it
 * parses the input on pipes, these parsed pipes are all executed after each other
 * while setting pipeIn and pipeOut of the executeCommand() function. This way
 * the pipes are handled in a single function (shell()), pipe opening and closing
 * all happens in this function.
 *
 * Error numbers are passed in the executeCommand() function, if the child process executes
 * with an error, it will pass it to the parent process which then returns this error
 * to the shell() function. This way, all errors are also handled in the shell() function
 * in stead of splitting that over multiple other functions.
 *
 * There are also some global variables described here:
 *
 * const std::string EXIT = "exit"      : Constant exit command.
 * const std::string CHANGEDIR = "cd"   : Constant cd command.
 * const std::string FILEIN = "<"       : Constant filein command.
 * const std::string FILEOUT = ">"      : Constant fileout command.
 * const int ERROR = -2                 : Constant error if the executeCommand()
 *                                        function fails to get the error of
 *                                        the child function.
 * const int NO_PIPE = -1               : Constant pipe value if the pipe needs
 *                                        not to be set.
 *
 *
 * Piping happens by passing the reading end of the previous pipe thru the
 * variable 'previousPipe' in the shell() function. This pipe is only set
 * as input if the for loop is not executing the first command.
 *
 * File in and output happens also with setting the pipe variable point to
 * files that are opened for reading or writing, if a file is failed to be
 * opened, the command is not executed and an error is shown to the console.
 *
 * When a command is executed in a set of piped command and if fails to execute
 * properly, error messages are shown to the termial.
 *
 * Typing errors:
 * Some inputs will be accepted and executed even though they are not (perfectly)
 * valid inputs. Inputs that are accepted include:
 *  - Normal inputs
 *  - Piped commands seperated with multiple |'s without spaces seperating these
 *    |'s. Example: cat < a.out || head -n 5
 *  - Commands that need to be executed in the background and have an & with multiple
 *    spaces after it. Example: cat < a.out &___________ (where _ = space)
 *
 *
 */
