#!/bin/bash
CWD=`pwd`
SHELL="$CWD/build/shell -t"
SHELL=/bin/sh
cd test-dir
for dir in `ls $CWD/tests`
do
  rm "outputfile" 2> /dev/null
  OUTPUT=`cat $CWD/tests/$dir/input | $SHELL 2> /dev/null`
  EXPECTED=`cat < $CWD/tests/$dir/output`
  if [ "$OUTPUT" == "$EXPECTED" ]; then
    printf "[\e[32m  OK  \e[39m] %s\n" "$dir (regular output)"
  else
    printf "[\e[31mFAILED\e[39m] %s (regular output)\n\e[33m  Expected: \e[39m\n%s\n\e[33m  Got     : \e[39m\n%s\n" "$dir" "$EXPECTED" "$OUTPUT"
  fi
  if [ -f "$CWD/tests/$dir/outputfile" ]; then
	if [ -f "outputfile" ]; then
		EXPECTED=`cat < $CWD/tests/$dir/outputfile`
		OUTPUT=`cat < outputfile`
  		if [ "$OUTPUT" == "$EXPECTED" ]; then
    			printf "[\e[32m  OK  \e[39m] %s (output to file)\n" "$dir"
  		else
    			printf "[\e[31mFAILED\e[39m] %s (output to file)\n\e[33m  Expected: \e[39m\n%s\n\e[33m  Got     \e[39m: \n%s\n" "$dir" "$EXPECTED" "$OUTPUT"
  		fi
	else
    		printf "[\e[31mFAILED\e[39m] %s (output to file)\n  Expected outputfile; but not found\n" "$dir"
	fi
  fi
done
