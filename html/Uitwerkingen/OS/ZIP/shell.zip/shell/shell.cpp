/**
  * Shell
  * Operating Systems
  */

/**
  Hint: F2 (or Control-click) on a functionname to go to the definition
  Hint: F1 while cursor is on a system call to lookup the manual page (if it does not work, open a shell and type "man [systemcall]")
  Hint: Ctrl-space to auto complete functions and variables
  */

// function/class definitions you are going to use
#include <iostream>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <sys/param.h>
#include <signal.h>
#include <string.h>

#include <vector>

// although it is good habit, you don't have to type 'std::' before many objects by including this line
using namespace std;

const std::string EXIT = "exit";
const std::string CHANGEDIR = "cd";
const std::string FILEIN = "<";
const std::string FILEOUT = ">";
const int ERROR = -2;
const int NO_PIPE = -1;

/**
 * @brief checkExit checks if cmd equals exit
 * @param cmd the command
 * @return true if it equals exit
 */
bool checkExit(string cmd) {
    return cmd == EXIT;
}

// Parses a string to form a vector of arguments. The seperator is a space char (' ').
std::vector<std::string> parseArguments(const std::string& str) {
    std::vector<std::string> retval;
    for (int pos = 0; pos < str.length(); ) {
        // look for the next space
        int found = str.find(' ', pos);
        // if no space was found, this is the last word
        if (found == std::string::npos) {
            retval.push_back(str.substr(pos));
            break;
        }
        // filter out consequetive spaces
        if (found != pos)
            retval.push_back(str.substr(pos, found-pos));
        pos = found+1;
    }
    return retval;
}

// Parses a string to form a vector of arguments. The seperator is a | char ('|').
std::vector<std::string> parsePipes(const std::string& str) {
    std::vector<std::string> retval;
    for (int pos = 0; pos < str.length(); ) {
        // look for the next |
        int found = str.find('|', pos);
        // if no | was found, this is the last word
        if (found == std::string::npos) {
            retval.push_back(str.substr(pos));
            break;
        }
        //filter out consequetive |
        if (found != pos)
            retval.push_back(str.substr(pos, found-pos));
        pos = found+1;
    }
    return retval;
}

int changeDir(std::vector<std::string>& args) {
    //This function gets a vector of strings that all need to be parsed before execution
    if (args.size() == 0)
        return EINVAL;
    // build argument list
    // always start with the command itself
    // always terminate with a NULL pointer

    char** c_args = new char*[args.size()+1];
    for (int i = 0; i < args.size(); ++i) {
        c_args[i] = strdup(args[i].c_str());
    }
    c_args[args.size()] = NULL;


    int return_value = chdir(c_args[1]);
    if (return_value != 0) {
        int retval = errno;
        return retval;
    }
    else {
        return 0;
    }
}

// Executes a command with arguments. In case of failure, returns error code.
int executeCommand(std::vector<std::string>& args, int pipeIn, int pipeOut, int test) {

    //This function gets a vector of strings that all need to be parsed before execution
    if (args.size() == 0)
        return EINVAL;
    // build argument list
    // always start with the command itself
    // always terminate with a NULL pointer

    char** c_args = new char*[args.size()+1];
    for (int i = 0; i < args.size(); ++i) {
        c_args[i] = strdup(args[i].c_str());
    }
    c_args[args.size()] = NULL;


    // replace current process with new process as specified
    int pID = fork();
    if (pID == 0) {
        //Child process

        //Check in pipe for this process
        if (pipeIn != NO_PIPE) {
            dup2(pipeIn, STDIN_FILENO);
        }

        //Check out pipe for this process
        if (pipeOut != NO_PIPE) {
            dup2(pipeOut, STDOUT_FILENO);
        }

        //Execute command
        execvp(c_args[0], c_args);

        // if we got this far, there must be an error
        int retval = errno;

        // in case of failure, clean up memory
        for (int i = 0; i < args.size(); ++i) {
            free(c_args[i]);
        }

        delete c_args;

        //Exit with errno
        exit(retval);
    }
    else {
        int returnStatus;
        waitpid(pID, &returnStatus, 0);
        //Check if the process exited correctly
        if (WIFEXITED(returnStatus)) {
            //Return its return status
            return WEXITSTATUS(returnStatus);
        }
        return ERROR;
    }


}

void displayPrompt() {
    char buffer[512];
    char* dir = getcwd(buffer, sizeof(buffer));
    if (dir)
        std::cout << "\e[32m" << dir << "\e[39m"; // the strings starting with '\e' are escape codes, that the terminal application interpets in this case as "set color to green"/"set color to default"
    std::cout << "$ ";
    std::flush(std::cout);
}

std::string requestCommandLine(bool showPrompt) {
    if (showPrompt)
        displayPrompt();
    std::string retval;
    getline(std::cin, retval);
    return retval;
}

/**
 * @brief checkBackground This function checks if the command needs to be ran in the background
 * @param input The whole input string of the command line
 * @return true if the command ends with &
 */
bool checkBackground(std::string input) {
    if (input.size() > 0) {
        std::vector<std::string> args = parseArguments(input);
        if (args.size() > 0 && args[args.size()-1] == "&") {
            return true;
        }
        else {
            return false;
        }
    }
    else {
        return false;
    }
}

/**
 * @brief shell This function runs the shell
 * @param showPrompt If the shell needs to run untill it is exited with exit()
 * @return 0
 */
int shell(bool showPrompt) {

    //RC is a variable needed in the entire function for return values
    int rc = 0;

    //This loop will execute exactly once if showPrompt is false, otherwise it will run untill it is exited with exit()
    do {
        //First we request input from the user
        std::string commandLine = requestCommandLine(showPrompt);

        //Then we check if the command needs to be executed in the background
        bool backgroundTask = checkBackground(commandLine);

        //If the last argument is equal to &, we will delete all spaces after that & and delete the &
        if (backgroundTask) {
            for (int i = commandLine.size()-1; i >= 0; i--) {
                if (commandLine[i] == ' ') {
                    commandLine = commandLine.substr(0, commandLine.size()-2);
                }
                else if (commandLine[i] == '&') {
                    commandLine = commandLine.substr(0, commandLine.size()-2);
                    i = -1;
                }
            }
        }


        int pID = -1;

        //Now we parse the pipes so that we can execute all commands after eachother
        std::vector<std::string> args = parsePipes(commandLine);

        //If the command needs to be ran in the background, make a new child
        if (backgroundTask) {
            pID = fork();
        }


        //This will execute if either the command needs to be ran in the background and the child is checking or the command needs to be ran normal and it is not the child checking
        if ((pID == 0 && backgroundTask) || (pID == -1 && !backgroundTask)) {

            //Previouspipe will be used for input output of the piped commands
            int previousPipe = -1;
            int pipeFp[2];
            rc = 0;


            //Execute this for loop for each of the piped commands
            for (int i = 0; i < args.size(); i++) {
                //Before forking each seperate command, we first make all pipes ready for usage


                //PipeIn and PipeOut will be used for input output of the piped commands
                int pipeIn = NO_PIPE;
                int pipeOut = NO_PIPE;

                //These will be used for filepointers if < or > is used
                FILE* fpIn = NULL;
                FILE* fpOut = NULL;


                //Parse the piped command
                std::vector<std::string> parsedArgs = parseArguments(args[i]);

                //Create a pipe
                pipe(pipeFp);

                //If this is not the last command, use the writing end of the pipe as output
                if (!(i == args.size()-1)) {
                    pipeOut = pipeFp[1];
                }
                //If this is the last command, check if the command needs to be written to a file
                else {
                    if (parsedArgs.size() > 2 && parsedArgs[parsedArgs.size()-2] == FILEOUT) {
                        std::string fileName = parsedArgs[parsedArgs.size()-1];
                        parsedArgs.pop_back();
                        parsedArgs.pop_back();
                        fpOut = fopen(&fileName[0], "w");
                        if (fpOut == NULL) {
                            rc = errno;
                        }
                        else {
                            pipeOut = fileno(fpOut);
                        }
                    }
                }

                //If this is not the first command, use the reading end of the previous pipe as input
                if (!(i == 0)) {
                    pipeIn = previousPipe;
                }
                //If this is the first command, check if the command needs to read input from a file
                else {
                    if (parsedArgs.size() > 0 && parsedArgs[parsedArgs.size()-2] == FILEIN) {
                        std::string fileName = parsedArgs[parsedArgs.size()-1];
                        parsedArgs.pop_back();
                        parsedArgs.pop_back();
                        fpIn = fopen(&fileName[0], "r");
                        if (fpIn == NULL) {
                            rc = errno;
                        }
                        else {
                            pipeIn = fileno(fpIn);
                        }
                    }
                }

                //Set the previous pipe so that the next command can read input from this pipe
                previousPipe = pipeFp[0];


                //Now we check if the command is cd or exit
                if (parsedArgs[0] == CHANGEDIR) {
                    changeDir(parsedArgs);
                    //If pipeIn was specified, close it now that the command is executed
                    if (pipeIn != NO_PIPE) {
                        close(pipeIn);
                    }
                    //Close the writing end of the pipe the command has written to
                    close(pipeFp[1]);

                    //Close the files if they have been used
                    if (fpIn != NULL) {
                        fclose(fpIn);
                    }
                    if (fpOut != NULL) {
                        fclose(fpOut);
                    }
                }
                else if (parsedArgs[0] == EXIT) {
                    close(pipeFp[0]);
                    close(pipeFp[1]);
                    //Close the files if they have been used
                    if (fpIn != NULL) {
                        fclose(fpIn);
                    }
                    if (fpOut != NULL) {
                        fclose(fpOut);
                    }
                    exit(0);
                }
                else {
                    //For executing all commands in parallel
                    int processID = fork();

                    if (processID == 0) {
                        //Child

                        //If there is no error this far, execute the command with the given input and output pipes
                        if (rc == 0) {
                            rc = executeCommand(parsedArgs, pipeIn, pipeOut, i);
                        }


                        //If pipeIn was specified, close it now that the command is executed
                        if (pipeIn != NO_PIPE) {
                            close(pipeIn);
                        }
                        //Close the writing end of the pipe the command has written to
                        close(pipeFp[1]);

                        //Close the files if they have been used
                        if (fpIn != NULL) {
                            fclose(fpIn);
                        }
                        if (fpOut != NULL) {
                            fclose(fpOut);
                        }

                        if (rc != 0) {
                            std::cout << strerror(rc) << std::endl;
                        }
                        exit(rc);
                    }
                    else if (processID != 0 && i == args.size()-1) {
                        //Parent

                        //Wait for the last command
                        int returnStatus;
                        waitpid(processID, &returnStatus, 0);
                    }
                    //Close the writing end of the pipe in the parent
                    close(pipeFp[1]);

                }
            }
            //Close the previous pipe if the for loop has ended
            close(previousPipe);

        }
        //Stop the child process
        if (pID == 0 && backgroundTask) {
            exit(0);
        }
    }
    while (showPrompt);
    return 0;
}


