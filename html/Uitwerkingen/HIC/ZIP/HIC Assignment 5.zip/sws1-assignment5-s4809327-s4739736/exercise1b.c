#include <stdio.h>

void function_b(void) {
	char buffer[4];
	
	

	
	buffer[24] = buffer[56];
	buffer[25] = buffer[57];
	buffer[26] = buffer[58];
	buffer[27] = buffer[59];
	
	
	
	fprintf(stdout,"Executing function_b\n");
}

void function_a(void) {
	int beacon = 0xa0b1c2d3;
	fprintf(stdout, "Executing function_a\n");
	function_b();
	fprintf(stdout, "Executed function\n");
}

int main(void) {
	function_a();
	fprintf(stdout, "Finished!\n");
	return 0;
}
