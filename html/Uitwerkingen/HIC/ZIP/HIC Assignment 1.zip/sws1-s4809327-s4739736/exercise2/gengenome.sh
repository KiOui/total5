#!/bin/bash
for((i=0;i<500;i++));
do
	for((j=0;j<100;j++));
	do
		rgetal=$(((RANDOM % 4)))
		case $rgetal in 
			"0") echo -n "A" ;;
			"1") echo -n "C" ;;
			"2") echo -n "G" ;;
			"3") echo -n "T" ;; 
		esac
	done
echo
done
