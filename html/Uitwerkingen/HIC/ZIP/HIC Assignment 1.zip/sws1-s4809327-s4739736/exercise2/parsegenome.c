#include <stdio.h>

int main (int argc, char *argv[]) {
	if (argc == 2) {
		char *filename = argv[1];
		FILE *fp;
		fp = fopen(filename, "r");
		for(int i = 0; i < 500;i++) {
			for (int o = 0;o < 100;o++) {		
				char t = fgetc(fp);
				if (!(t == 'A' || t == 'G' || t == 'C' || t == 'T')) {
					return -1;
				}				
			}
			char t = fgetc(fp);
			if (t != '\n') {
				return -1;
			}
		}	
		fclose(fp);
	}
	else {
		printf("-1");
	}
	return 0;
}
