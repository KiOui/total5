#!/bin/bash
echo "Please enter a filename:"
read filename
echo "Please enter a string:"
read search
cat $filename | tr -d '\n' | grep -o $search | wc -l
