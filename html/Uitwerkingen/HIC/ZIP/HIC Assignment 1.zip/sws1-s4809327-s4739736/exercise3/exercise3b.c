#include <stdio.h>
#include <unistd.h>

int main() {
	FILE *fp;
	fp = fopen("/dev/urandom", "r");
	char t = getc(fp);
	printf("%d %u %x", t, t, t);
	while (t != 42) {
		t = getc(fp);
		printf("%d %u %x\n", t, t, t);
	}
	fclose(fp);
	return 0;
}
