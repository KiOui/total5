#include <stdio.h>
#include <unistd.h>
#include <stdint.h>


int main() {
	FILE *fp;
	fp = fopen("/dev/urandom", "r");
	char t = getc(fp);
	char s = getc(fp);
	uint16_t bits  = (t<<8) + s;
	printf("%04x\n", bits);
	while (bits != 42) {
		t = getc(fp);
		s = getc(fp);
		bits = (t<<8) + s;
		printf("%04x\n", bits);
	}
	fclose(fp);
	return 0;
}
