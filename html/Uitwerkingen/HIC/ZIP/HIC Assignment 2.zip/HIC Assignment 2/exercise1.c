#include <stdio.h>


int main(void) {
	
	short i = 0x1234;
	char x = -127;
	long sn1 = 4809327;
	long sn2 = 4739736;
	int y[2] = {0x11223344, 0x44332211};

	printf("i takes %d bytes\n",(unsigned int) sizeof(i));
	printf("x takes %d bytes\n",(unsigned int) sizeof(x));
	printf("sn1 takes %d bytes\n",(unsigned int) sizeof(sn1));
	printf("sn2 takes %d bytes\n",(unsigned int) sizeof(sn2));
	printf("y takes %d bytes\n",(unsigned int) sizeof(y));
	
	printf("\n\n");
	printf("adress\tcontent(hex)\tcontent(dec)\n");
	printf("------------------------------------\n");

	unsigned char* pointer = (unsigned char*) &i;
	for (int o = 0; o < sizeof(i); o++) {
		printf("%p\t%x\t%d\n",&i+o,*(pointer+o),*(pointer+o));
	}
	printf("\n");
	pointer = (unsigned char*) &x;
	for (int o = 0; o < sizeof(x); o++) {
		printf("%p\t%x\t%d\n", &x+o, *(pointer+o), *(pointer+o));
	}
	printf("\n");
	pointer = (unsigned char*) &sn1;
	for (int o = 0; o < sizeof(sn1); o++) {
		printf("%p\t%x\t%d\n", &sn1+o, *(pointer+o), *(pointer+o));
	}
	printf("\n");
	pointer = (unsigned char*) &sn2;
	for (int o = 0; o < sizeof(sn2); o++) {
		printf("%p\t%x\t%d\n", &sn1+o, *(pointer+o), *(pointer+o));
	}
	printf("\n");
	pointer = (unsigned char*) &y;
	for (int o = 0; o < sizeof(y); o++) {
		printf("%p\t%x\t%d\n", &y+o, *(pointer+o), *(pointer+o));
	}

	
}

