#include <string.h>
#include <stdio.h>

int main() {
	char str1[15];
	char str2[15];
	int ret;
	
	memcpy(str1, "abcdef", 6);
	memcpy(str2, "abcdef", 6);

	ret = memcmp(str1, str2, 5);
	printf("%d", ret);
	return 0;
}



void addvector(int *r, const int *a, const int *b, unsigned int len) {
	unsigned int i;
	for (i=0;i<len;i++) {
		*(r+i) = *(a+i) + *(b+i);
	}
}



int memcmp(const void *s1, const void *s2, size_t n) {
	unsigned char* pointer1 = (unsigned char*) s1;
	unsigned char* pointer2 = (unsigned char*) s2;

	for (int i = 0; i < n; i ++) {
		if (*pointer1+i != *pointer2+i) {
			return (*pointer1+i) - (*pointer2+i);
		}
	}
	return 0;
}



int memcmp_backwards(const void *s1, const void *s2, size_t n) {
	unsigned char* pointer1 = (unsigned char*) s1;
	unsigned char* pointer2 = (unsigned char*) s2;
	
	for (int i = n-1; i >= 0; i--) {
		if (*pointer1+i != *pointer2+i) {
			return (*pointer1+i) - (*pointer2+i);
		}
	}
	return 0;
}

