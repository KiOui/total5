#include <stdbool.h>
#include <stdio.h>

int main(void) {
	bool boolean = true;
	printf("A bool needs %d bytes\n", (unsigned int) sizeof(boolean));
	printf("A bool has a hexadecimal true representation of: %x\n", boolean);
	boolean = false;
	printf("A bool has a hexadecimal false representation of: %x\n", boolean);
	for (int i = 0x0; i <= 0xF; i++) {
		boolean = i;
		printf("Boolean with hex value %x is interpreted as %s\n", i, boolean?"true":"false");
	}
}
