#include<stdlib.h>
#include<stdio.h>

int main () {
	int step = 400000; // The better this guess, the faster the programm
	long int size = step;
	void* p;
	while(step > 1){
		p = malloc(size);
		if (p==NULL) {
			size -= step;
			step = step/2;
		}
		size += step;
		free(p);
	}
	printf("One malloc can allocate at most %li bytes.\n", size);
}
