#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void heap_attack(void) {
	char *pointer = malloc(8);
	strcpy(pointer, "1111111");
	for(int i = 0; i <=4; i++) {
		
		
		pointer = pointer - 16;
		
		if (strcmp(pointer, "4809327")==0) {
			pointer = pointer+7;
			while (strcmp(pointer,"4739736")!=0){
				*pointer = ' ';
				pointer++;
			}
		i =1000;
		}
	}
}

int main(void) {
	char *s1 = malloc(8);
	if (s1 == NULL) {
		return -1;
	}
	char *s2 = malloc(8);
	if (s2 == NULL) {
		return -1;
	}

		
	strcpy(s1, "4809327");
	strcpy(s2, "4739736");
	
	heap_attack();
	printf("Student 1: %s\n", s1);
	printf("Student 2: %s\n", s2);

	
	return 0;
}
