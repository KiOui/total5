#include<stdio.h>

int main (void) {
	char array[1] = {(char) 42};
	int i;
	for(i = -5; i >= -4194304; i--){
		array[i] = array[0];		
	}	
	magic_function();
	for(i = -4194304; i < 0 ; i++){
		if (array[i] != array[0]) {
			printf("length of stack: %d bytes...\n",-i);
			i = 0;
		}
	}
	return 0;
}
