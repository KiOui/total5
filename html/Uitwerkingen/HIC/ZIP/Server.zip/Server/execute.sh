#!/bin/bash

echo "Executing script..."

./script.sh | nc hackme.cs.ru.nl 2266


