% Executes the entire algorithm to compute a diangoses for a problem SD, COMP, OBS, stores the diagnoses in Diagnoses
getDiagnoses(SD, COMP, OBS, Diagnoses) :-
				makeHittingTree(SD, COMP, OBS, Tree, []), 
				!, 
				gatherDiagnoses(Tree, Diag), 
				!, 
				getMinimalDiagnoses(Diag, Diagnoses).

% Creates a hitting tree, input as makeHittingTree(SD, COMP, OBS, Tree, []).
makeHittingTree(SD, COMP, OBS, Tree, Trace) :-
  				tp(SD, COMP, OBS, Trace, CS), 
  				addChildren(SD, COMP, OBS, Trace, CS, Children), 
  				Tree = node(Trace, Children).
makeHittingTree(_, _, _, Tree, Trace) :- Tree = leaf(Trace).

% Adds all children from [X | XS] to the tree [Tree | Children]
addChildren(_, _, _, _, [], []).
addChildren(SD, COMP, OBS, Trace, [X | XS], [Tree | Children]) :-
				makeHittingTree(SD, COMP, OBS, Tree, [X | Trace]), 
				addChildren(SD, COMP, OBS, Trace, XS, Children).

% Stores all diagnoses from a hitting tree in Diagnoses
gatherDiagnoses(leaf(Trace), [Trace]).
gatherDiagnoses(node(_, Children), Diagnoses) :-
				addTraces(Children, Diagnoses).

% Helper function for gatherDiagnoses
addTraces([], []).
addTraces([X | XS], Diagnoses) :-
				gatherDiagnoses(X, Diagnoses1), 
				addTraces(XS, Diagnoses2), 
				append(Diagnoses1, Diagnoses2, Diagnoses).

% Returns a minimal diagnoses from a diagnoses list Diagnoses
getMinimalDiagnoses(Diagnoses, MinimalDiagnoses) :-
				removeDuplicates(Diagnoses, Removed), 
				superSet(Removed, MinimalDiagnoses, []).

% Removes supersets from a list Supersets
superSet([], [], _).
superSet([X | XS], Supersets, Processed) :-
				append(Processed, XS, AllLists), 
				append([X], Processed, ProcessedAppended), 
				memberOfAList(X, AllLists), 
				superSet(XS, Supersets, ProcessedAppended).
superSet([X | XS], Supersets, Processed) :-
				append([X], Supersets1, Supersets), 
				append([X], Processed, ProcessedAppended), 
				superSet(XS, Supersets1, ProcessedAppended).

% Checks if a set in [X | XS] is a subset of List
memberOfAList(List, [X | XS]) :-
				memberList(X, List);
				memberOfAList(List, XS).

% Removes the duplicates from a list of list
removeDuplicates([], []).
removeDuplicates([X | XS], Removed) :-
				removeDuplicates(XS, Removed), 
				sameListInList(X, XS).
removeDuplicates([X | XS], [X | DuplicatesRemoved]) :-
				removeDuplicates(XS, DuplicatesRemoved).

% Checks if a list in [X | XS] is exactly the same as List
sameListInList(List, [X | XS]) :-
				sameList(List, X);
				sameListInList(List, XS).

% Checks if List1 and List2 are the same list
sameList(List1, List2) :-
				memberList(List1, List2), 
				memberList(List2, List1).

% Checks if List is a superset of [X | XS]
memberList([], _).
memberList([X | XS], List) :-
				memberOf(X, List), 
				memberList(XS, List).

% Checks if Item is in list [X | XS]
memberOf(Item, [X | XS]) :-
				isMember(Item, X);
				memberOf(Item, XS).

% Compares two Items
isMember(Item, Item).