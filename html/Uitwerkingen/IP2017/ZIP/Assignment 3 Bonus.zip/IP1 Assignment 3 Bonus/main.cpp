#include <iostream>
#include <string>
#include <stdlib.h>
#include <tgmath.h>
#include <sstream>
#include <iostream>

using namespace std;

int inputBase;
int outputBase;
string number;
string numberArray[4];
int intArray[4];
string newBase[1000];
int total;
int minimum;
int printl;

void askUser() {
    cout << "Please enter base to calculate from: ";
    cin >> inputBase;
    cout << "Please enter base to calculate to: ";
    cin >> outputBase;
    cout << "Please enter number to calculate from: ";
    cin >> number;
    cout << "LOG: " << inputBase << " " << outputBase << " " << number << endl;
}

string toString(int interger) {
    stringstream ss;
    ss << interger;
    string newString = ss.str();
    return newString;
}

void makeArray() {
    for (int i=0;i<4;i++) {
        numberArray[i] = number[i];
    }
}

void convertArray() {
    for (int i=0;i<4;i++) {
        if (numberArray[i] == "a" || numberArray[i] == "A") {
            numberArray[i] = "10";
        }
        else if (numberArray[i] == "b" || numberArray[i] == "B") {
            numberArray[i] = "11";
        }
        else if (numberArray[i] == "c" || numberArray[i] == "C") {
            numberArray[i] = "12";
        }
        else if (numberArray[i] == "d" || numberArray[i] == "D") {
            numberArray[i] = "13";
        }
        else if (numberArray[i] == "e" || numberArray[i] == "E") {
            numberArray[i] = "14";
        }
        else if (numberArray[i] == "f" || numberArray[i] == "F") {
            numberArray[i] = "15";
        }
        else if (numberArray[i] == "") {
            numberArray[i] = "0";
        }
    }
    cout << "Array converted to: " << numberArray[0] << numberArray[1] << numberArray[2] << numberArray[3] << endl;
}

void makeInt() {
    for (int i=0;i<4;i++) {
        std::string text = numberArray[3-i];
        intArray[i] = atoi(text.c_str());
    }
    for (int i=0;i<4;i++) {
        if (intArray[0] == 0) {
            intArray[0] = intArray[1];
            intArray[1] = intArray[2];
            intArray[2] = intArray[3];
            intArray[3] = 0;
        }
    }
    cout << "Array rotated to: " << intArray[0] << intArray[1] << intArray[2] << intArray[3] << endl;
}

void calculateArray() {
    for (int i = 0;i<4;i++) {
        total = total + (intArray[i] * pow(inputBase, i));
    }
    cout << "Value of array: " << total << "." << endl;
}

void calculateNewBase() {
    for (int i=0;i<10000000;i++) {
        int check = total / pow(outputBase, i);
        if (check == 0) {
            minimum = i-1;
            i = 10000000;
        }
    }
    for (int i=0;i<=minimum;i++) {
        int extract = total / (pow(outputBase, (minimum-i)));
        newBase[i] = toString(extract);
        total = total - (extract * (pow(outputBase, minimum-i)));
    }
    if (outputBase == 16) {
        for (int i=0;i<=minimum;i++) {
            if (newBase[i] == "10") {
                newBase[i] = "A";
            }
            else if (newBase[i] == "11") {
                newBase[i] = "B";
            }
            else if (newBase[i] == "12") {
                newBase[i] = "C";
            }
            else if (newBase[i] == "13") {
                newBase[i] = "D";
            }
            else if (newBase[i] == "14") {
                newBase[i] = "E";
            }
            else if (newBase[i] == "15") {
                newBase[i] = "F";
            }
        }
    }
}

void printArray() {
    cout << "OUTPUT:" << endl;
    for (int i = 0; i <= minimum; i++) {
        cout << newBase[i];
    }
}

int main()
{
    askUser();
    makeArray();
    if (inputBase == 2 || inputBase == 8 || inputBase == 10) {
        makeInt();
        calculateArray();
        calculateNewBase();
        printArray();
    }
    else if (inputBase == 16) {
        convertArray();
        makeInt();
        calculateArray();
        calculateNewBase();
        printArray();
    }
    else {
        cout << "You entered a wrong value for variable \"Inputbase\", permitted values: 2, 8, 10, 16." << endl;
    }

    return 0;
}
