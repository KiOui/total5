#include <iostream>
#include <cassert>

using namespace std;

int naive_power(int x, int n) {
    //Preconditie:
    assert(x >= 0 && n >= 0);
    //Postconditie:
    //Returns x^n
    if (n == 0) {
        return 1;
    }
    else {
        return x * naive_power(x,n-1);
    }
}

int power(int x, int n) {
    //Preconditie:
    assert(x >= 0 && n >= 0);
    //Postconditie:
    //Returns x^n
    if (n == 0) {
        return 1;
    }
    else if (n%2 == 0) {
        int i = power(x, n/2);
        return i * i;
    }
    else {
        return x * power(x, n-1);
    }
}

bool palindrome1 (string text, int i, int j) {
    //Preconditie:
    assert(i >= 0 && j < text.length());
    //Postconditie:
    //Returns true if text is a palindrome and false otherwise
    if (i >= j) {
        return true;
    }
    else {
        return (text[i] == text[j]) && palindrome1(text, i+1, j-1);
    }
}

bool palindrome2 (string text, int i, int j) {
    //Preconditie:
    assert(i >= 0 && j < text.length());
    //Postconditie:
    //Returns true if text is a palindrome while ignoring upper/lower case and false otherwise
    if (i >= j) {
        return true;
    }
    else {
        int first = tolower(text[i]);
        int second = tolower(text[j]);
        return (first == second) && palindrome2(text, i+1, j-1);
    }
}

bool inMarks (char c) {
    //Preconditie:
    assert(true);
    //Postconditie:
    //Returns true if c is a char in marks[] and false otherwise
    char marks[] = {'.', ',', ':', ';', '\'', '!', '?', '-', ' '};
    for (int i = 0; i < sizeof(marks); i++) {
        if (marks[i] == c) {
            return true;
        }
    }
    return false;
}

bool palindrome3 (string text, int i, int j) {
    //Preconditie:
    assert(i >= 0 && j < text.length());
    //Postconditie:
    //Returns true if text is a palindrome while ignoring upper/lower case and all marks[] characters, returns false otherwise
    if (i >= j) {
        return true;
    }
    else if (inMarks(text[i])) {
        return palindrome3(text, i+1, j);
    }
    else if (inMarks(text[j])) {
        return palindrome3(text, i, j-1);
    }
    else {
        int first = tolower(text[i]);
        int second = tolower(text[j]);
        return (first == second) && palindrome3(text, i+1, j-1);
    }
}

bool match_chars(string chars, int i, string source, int j) {
    //Preconditie:
    assert(i >=0 && i <= chars.length() && j >= 0 && j <= source.length());
    //Postconditie:
    //Returns true if all chars in chars from index i are in source from index j
    if (i == chars.length()) {
        return true;
    }
    else if (j == source.length()) {
        return false;
    }
    else if (chars[i] == source[j]) {
        return match_chars(chars, i+1, source, j+1);
    }
    else {
        return match_chars(chars, i, source, j+1);
    }
}

int main()
{
    bool i = match_chars("abc", 0, "It is a classy bag", 0);
    cout << i << endl;
    return 0;
}
