#include <iostream>
#include<stdio.h>
#include<vector>
#include<fstream>
#include<cassert>
#include <iostream>

using namespace std;

const int NO_PARENT = -1;

enum direction {North=1, East, South, West};
typedef vector<vector<char>> field;

struct position {
    int x;
    int y;
};

struct field_parent {
    int parent;
    field thisfield;
    string val;
};

ostream& operator<< (ostream& out, const field Field) {
    for (int i = 0; i < Field.size(); i++) {
        for (int j = 0; j < Field[i].size(); j++) {
            out << Field[i][j];
        }
        out << endl;
    }
    return out;
}

void read_file(field& inputField, ifstream& file) {
    //Pre:
    assert(file.is_open());
    //Post:
    //Reads a field into inputField
    int x = 0;
    char c;

    do {
        vector<char> newVector;
        inputField.push_back(newVector);
        do {
            c = file.get();
            inputField[x].push_back(c);
        }
        while(c != '\n' && !file.eof());
        x++;
    }
    while (!file.eof());

    inputField.pop_back();

    for (int i = 0; i < inputField.size(); i++) {
        inputField[i].pop_back();
    }
}

void copy_field(field from, field& to) {
    //Pre:
    assert(true);
    //Post:
    //Copies from to to
    for (int i = 0; i < from.size(); i++) {
        vector<char> newVector;
        to.push_back(newVector);
        for (int j = 0; j < from[i].size(); j++) {
            to[i].push_back(from[i][j]);
        }
    }
}

position get_direction(direction dir) {
    //Pre:
    assert(true);
    //Post:
    //Returns relative position from dir
    position retvalue;
    if (dir == North) {
        retvalue.x = -1;
        retvalue.y = 0;
    }
    else if (dir == East) {
        retvalue.x = 0;
        retvalue.y = 1;
    }
    else if (dir == South) {
        retvalue.x = 1;
        retvalue.y = 0;
    }
    else {
        retvalue.x = 0;
        retvalue.y = -1;
    }
    return retvalue;
}

position get_position(field current) {
    //Pre:
    assert(true);
    //Post:
    //Returns position of w or W, if w or W is not present, return <-1, -1>
    position retvalue;
    for (int i = 0; i < current.size(); i++) {
        for (int j = 0; j < current[i].size(); j++) {
            if (current[i][j] == 'w' || current[i][j] == 'W') {
                retvalue.x = i;
                retvalue.y = j;
                return retvalue;
            }
        }
    }
    retvalue.x = -1;
    retvalue.y = -1;
    return retvalue;
}

field move_player(field config, direction dir, position current_position) {
    //Pre:
    assert(current_position.x < config.size() && current_position.x >= 0 && current_position.y < config[current_position.x].size() && current_position.y >= 0);
    //Post:
    //Moves player to specified field
    field retvalue;
    copy_field(config, retvalue);
    position moveTo = get_direction(dir);
    position next;
    next.x = current_position.x + moveTo.x;
    next.y = current_position.y + moveTo.y;
    if (retvalue[current_position.x][current_position.y] == 'W') {
        retvalue[current_position.x][current_position.y] = '.';
    }
    else {
        retvalue[current_position.x][current_position.y] = ' ';
    }

    if (retvalue[next.x][next.y] == 'b' || retvalue[next.x][next.y] == 'B') {
        if (retvalue[next.x][next.y] == 'B') {
            retvalue[next.x][next.y] = 'W';
        }
        else {
            retvalue[next.x][next.y] = 'w';
        }
        position block;
        block.x = next.x + moveTo.x;
        block.y = next.y + moveTo.y;

        if (retvalue[block.x][block.y] == '.') {
            retvalue[block.x][block.y] = 'B';
        }
        else {
            retvalue[block.x][block.y] = 'b';
        }
    }
    else if (retvalue[next.x][next.y] == '.'){
        retvalue[next.x][next.y] = 'W';
    }
    else {
        retvalue[next.x][next.y] = 'w';
    }
    return retvalue;
}

string toval(field thisfield) {
    string retvalue = "";
    for (int i = 0; i < thisfield.size(); i++) {
        for (int j = 0; j < thisfield[i].size(); j++) {
            retvalue.push_back(thisfield[i][j]);
        }
        retvalue.push_back('|');
    }
    return retvalue;
}

bool possibleMove(field config, direction dir, position current_position, bool is_block) {
    //Pre:
    assert(true);
    //Post:
    //Checks if a move is a possible move
    position moveTo = get_direction(dir);
    position next;
    next.x = current_position.x + moveTo.x;
    next.y = current_position.y + moveTo.y;
    if (next.x < 0 || next.x >= config.size()) {
        return false;
    }
    else if (next.y < 0 || next.y >= config[next.x].size()) {
        return false;
    }
    else if (config[next.x][next.y] == '*') {
        return false;
    }
    else if (config[next.x][next.y] == 'b' || config[next.x][next.y] == 'B') {
        if (is_block) {
            return false;
        }
        else {
            return possibleMove(config, dir, next, true);
        }
    }
    else {
        return true;
    }
}

bool solved(field current) {
    //Pre:
    assert(true);
    //Post:
    //Checks if a field is solved
    for (int i = 0; i < current.size(); i++) {
        for (int j = 0; j < current[i].size(); j++) {
            if (current[i][j] == 'W' || current[i][j] == '.') {
                return false;
            }
        }
    }
    return true;
}

bool checkSize(field a, field b) {
    //Pre:
    assert(true);
    //Post:
    //Checks if the size of two fields is equal
    if (a.size() != b.size()) {
        return false;
    }
    else {
        for (int i = 0; i < a.size(); i++) {
            if (a[i].size() != b[i].size()) {
                return false;
            }
        }
    }
    return true;
}

bool check_duplicate(field a, field b) {
    //Pre:
    assert(true);
    //Post:
    //Checks if two fields are equal
    if (!checkSize(a, b)) {
        return false;
    }

    for (int i = 0; i < a.size(); i++) {
        for (int j = 0; j < a[i].size(); j++) {
            if (a[i][j] != b[i][j]) {
                return false;
            }
        }
    }
    return true;
}

bool is_duplicate(vector<field_parent> fieldList, field toAdd) {
    //Pre:
    assert(true);
    //Post:
    //Checks if field toAdd is already in fieldList
    for (int i = 0; i < fieldList.size(); i++) {
        if (check_duplicate(fieldList[i].thisfield, toAdd)) {
            return true;
        }
    }
    return false;
}

bool is_duplicate(vector<field> fieldList, field toAdd) {
    //Pre:
    assert(true);
    //Post:
    //Checks if field toAdd is already in fieldList
    for (int i = 0; i < fieldList.size(); i++) {
        if (check_duplicate(fieldList[i], toAdd)) {
            return true;
        }
    }
    return false;
}

bool is_duplicate(vector<field_parent> fieldList, string compare) {

    for (int i = 0; i < fieldList.size(); i++) {
        if (fieldList[i].val == compare) {
            return true;
        }
    }
    return false;
}

int breath_first(vector<field_parent> layer, int iteration) {
    //Pre:
    assert(iteration >= 0);
    //Post:
    //Searches breath first for a solution to all elements of layer, stops when it finds one
    //This is the recursive variant of breath_first
    cout << iteration << endl;
    vector<field_parent> next_iteration;

    for (int i = 0; i < layer.size(); i++) {
        if (solved(layer[i].thisfield)) {
            cout << layer[i].thisfield << endl;
            return layer[i].parent;
        }
        else {
            direction all[] = {North, East, South, West};
            position current_pos = get_position(layer[i].thisfield);
            for (int m = 0; m < 4; m++) {
                if (possibleMove(layer[i].thisfield, all[m], current_pos, false)) {
                    field_parent addthis;
                    addthis.thisfield = move_player(layer[i].thisfield, all[m], current_pos);
                    addthis.parent = i;
                    addthis.val = toval(addthis.thisfield);
                    if (!is_duplicate(next_iteration, addthis.val)) {
                        next_iteration.push_back(addthis);
                    }
                }
            }
        }
    }
    int retvalue = breath_first(next_iteration, iteration+1);
    cout << layer[retvalue].thisfield << endl;
    return layer[retvalue].parent;
}

vector<field> breath_first(vector<field_parent> q) {
    //Pre:
    assert(true);
    //Post:
    //Searches breath first for a solution to all elements of q, stops when it finds one
    //This is the queue variant of breath_first
    direction all[] = {North, East, South, West};
    for (int i = 0; i < q.size(); i++) {
        if (solved(q[i].thisfield)) {
            vector<field> retvalue;
            int j = i;
            while(j > 0) {
                retvalue.push_back(q[j].thisfield);
                j = q[j].parent;
            }
            retvalue.push_back(q[j].thisfield);
            return retvalue;
        }
        else {
            position current_pos = get_position(q[i].thisfield);
            for (int m = 0; m < 4; m++) {
                if (possibleMove(q[i].thisfield, all[m], current_pos, false)) {
                    field_parent addthis;
                    addthis.thisfield = move_player(q[i].thisfield, all[m], current_pos);
                    addthis.parent = i;
                    addthis.val = toval(addthis.thisfield);
                    if (!is_duplicate(q, addthis.val)) {
                        q.push_back(addthis);
                    }
                }
            }
        }
    }
}

void depth_first(vector<field> fields, vector<field>& best, int iteration, int& max_depth, double percent, double done) {
    //Pre:
    assert(iteration >= 0 && percent > 0 && done >= 0 && done <= 1 && max_depth >= 0);
    //Post:
    //Searches depth first for the best solution to the first element of fields
    if (solved(fields[fields.size()-1])) {
        if (iteration < best.size()-1 || best.size() == 0) {
            vector<field> newBest;
            for (int i = 0; i < fields.size(); i++) {
                newBest.push_back(fields[i]);
            }
            best = newBest;
            max_depth = iteration;
            cout << "Found new best solution at: " << iteration << endl;
        }
        return;
    }
    else if (iteration > max_depth) {
        return;
    }
    else {
        direction all[] = {North, East, South, West};
        position current_pos = get_position(fields[fields.size()-1]);
        for (int i = 0; i < 4; i++) {
            if (possibleMove(fields[fields.size()-1], all[i], current_pos, false)) {
                field next_field = move_player(fields[fields.size()-1], all[i], current_pos);
                if (!is_duplicate(fields, next_field)) {
                    fields.push_back(next_field);
                    depth_first(fields, best, iteration+1, max_depth, percent/4, done);
                    fields.pop_back();
                }
            }
            done = done + percent/4;
            cout << "Percent: " << done << endl;
        }
        return;
    }
}

int main()
{
    field inputField;
    cout << "Please input the name of the file: ";
    string filename;
    cin >> filename;
    ifstream infile(filename.c_str());
    if (infile.is_open()) {
        read_file(inputField, infile);
    }
    else {
        return -1;
    }

    cout << "Please enter how to search for a solution (0=breath first recursive, 1=breath first queue, 2=depth first): ";
    int solution;
    cin >> solution;

    field_parent start;
    start.thisfield = inputField;
    start.parent = -1;
    vector<field_parent> startvec;
    startvec.push_back(start);

    start.val = toval(inputField);

    if (solution == 0) {
        int retvalue = breath_first(startvec, 0);
    }
    else if (solution == 1) {
        vector<field> retvalue = breath_first(startvec);
        for (int i = retvalue.size()-1; i >= 0; i--) {
            cout << retvalue[i] << endl;
        }
    }
    else if (solution == 2) {
        vector<field> start_config;
        start_config.push_back(inputField);
        vector<field> best;
        double per = 1;
        double done = 0;
        cout << "Please enter the maximum depth: ";
        int depth;
        cin >> depth;
        depth_first(start_config, best, 0, depth, per, done);
        for (int i = 0; i < best.size(); i++) {
            cout << best[i] << endl;
        }
    }
    else {
        return -1;
    }

    return 0;
}
