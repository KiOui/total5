#include <iostream>
#include <cassert>

using namespace std;

bool match_pattern (string pattern, int i, int j, string source)
{
    //pre-condition:
    assert(pattern != "" && i >= 0 && j>= 0 && source != "");
    //post-condition: Compares the source to the pattern, if matches returns true.
    if (i == pattern.length())
    {
        return true;
    }
    else if (j == source.length())
    {
        return false;
    }
    else if(pattern[i] == source[j])
    {
        return match_pattern(pattern,i+1,j+1,source);
    }
    else if (pattern[i] == '.')
    {
        return match_pattern(pattern,i+1,j+1,source);
    }
    else if (pattern[i] == '*')
    {
        for (int q = j; q < source.length(); q++)
        {
            if (match_pattern(pattern, i+1, q, source))
            {
                return true;
            }
        }
        return false;
    }
    else
    {
        return pattern[i] == source[j] && match_pattern(pattern, i+1, j+1, source);
    }

}

int main()
{
    string pattern;
    string source;
    int i = 0;
    int j = 0;
    cout << "Pattern: ";
    getline(cin,pattern);
    cout << "Source: ";
    getline(cin,source);
    if (match_pattern(pattern, i,j, source))
    {
        cout << "This source matches the pattern" << endl;
    }
    else
    {
        cout << "This source does not match the pattern" << endl;
    }
    return 0;
}
