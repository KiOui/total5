#include <iostream>
#include <stdlib.h>
#include <math.h>

using namespace std;

double b;
double a;
double x;
double out;
int i;


void inclusion (double v, double e) {
    if (v >= 0) {
        i = 0;
        for (int z = 0; z*z <=v; z++) {
            a = z;
        }
        b = a + 1;
        if (a*a != v) {
            x = (a + b) /2;
            out = fabs((x*x)-v);
            while (out > e) {
                i++;
                if (x * x < v) {
                    a = x;
                }
                else {
                    b = x;
                }
                x = (a + b) / 2;
                out = fabs((x*x)-v);
            }
            cout << x << "\t" << i << endl;
        }
        else {
            cout << a << "\t" << i << endl;
        }
    }
    else {
        cout << "You can't take the square root of an negative integer!" << endl;
    }
}

void newtonraphson (double v, double e) {
    if (v >= 0) {
        if (v >= 1) {
            for (double z = 0; z*z <=v; z++) {
                x = z;
            }
        }
        else {
        x = 1;
        }
        i = 0;
        out = fabs(x*x-v);
        while (out > e) {
            i++;
            x = x - ((x * x) - v) / (2 * x);
            out = fabs(x*x-v);

        }
        cout << x << "\t" << i << endl;
    }
    else {
        cout << "You can't take the square root of an negative integer!" << endl;
    }
}

int main (){
    inclusion(30, 0.001);
    newtonraphson(30, 0.001);
    return 0;
}
