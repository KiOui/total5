#include <iostream>
#include <fstream>
#include <cassert>
#include <cstring>


using namespace std;

const int MAX_INPUT_LENGTH = 200;
string Commands[] = {"enter", "content", "stop", "count", "where", "context"};
ifstream file;
bool stop = false;
const int MAX_WORD_LENGTH = 60 ;
const int MAX_WORDS = 30000 ;
typedef char Word [MAX_WORD_LENGTH] ;
typedef Word Words [MAX_WORDS] ;
typedef int Freqs [MAX_WORDS] ;
Word word;
Words words;
int file_length;


string input_command ()
{
    assert(true);

    //post: return the first word entered (the command).
    string command;
    cin >> command;
    return command;
}

int valid_command(string command) {
    assert(true);

    //post: returns number of command and checks if command exists.
    for (int i = 0; i < 6; i++) {
        if (Commands[i] == command) {
            return i;
        }
    }
    return -1;
}

void get_input_array(char input [MAX_INPUT_LENGTH]) {
    assert(true);

    //post: returns the characters entered after the command.
    cin.getline(input, MAX_INPUT_LENGTH);
    for (int i = 0; i<MAX_INPUT_LENGTH;i++) {
        input[i] = input[i+1];
    }
}


void enter() {
    assert(true);

    //post: opens the entered file
    if (file.is_open()) {
        file.clear();
        file.close();
    }
    char inputArray [MAX_INPUT_LENGTH];
    get_input_array(inputArray);
    file.open(inputArray);
    int i = 0;
    file >> word;
    while(file)
    {
        strcpy(words[i],word);
        file >> word;
        i++;
    }
    file_length = i;
}

void content() {
    assert(true);

    //post: prints the file.
    for (int i=0;i<=file_length;i++) {
        cout << words[i] << " ";
    }
    cout << endl;
}

void stopCommand() {
    assert(true);

    //post: stops the program.
    stop = true;
}

void countCommand() {
    assert(true);

    //post: actually, it doesnt do anything.
    Words temp_words;
    char test_end;
    int counter = 0;
    int command_length = 0;
    for (int i = 0; i<1000 && test_end != '\n';i++) {
        cin >> temp_words[i];
        test_end = cin.get();
        command_length++;
    }

    for (int i = 0; i< MAX_WORDS;i++) {
      //  cout << words[i] << endl;
        if (temp_words[0] == words[i]) {
            cout << "2" << endl;
            bool a;
            for (int o = 0; o < command_length;o++) {
                if (temp_words[o] == words[i+o]) {
                    cout << "True" << endl;
                    a = true;
                }
                else {
                    cout << "False" << endl;
                    a = false;
                }
            }
            if (a) {
                counter++;
            }
        }
    }
    cout << counter << endl;
}

void execute_command(int ID) {
    switch (ID) {
        case 0: enter(); break;
        case 1: content(); break;
        case 2: stopCommand(); break;
        case 3: countCommand(); break;
        //case 4: where(); break;
        //case 5: context(); break;
        default: cout << "Error" << endl;
    }
}

int main()int i = 0;
    file >> word;
    while(file)
    {
        strcpy(words[i],word);
        file >> word;
        i++;
    }
    file_length = i;
{
    while (!stop) {
        string command = input_command();
        int commandID = valid_command(command);
        if (!(commandID == -1)) {
            execute_command(commandID);
        }
        else {
            cout << "Command not valid!" << endl;
        }
        cout << "Done!" << endl;
    }
    cout << "--";
    return 0;
}
