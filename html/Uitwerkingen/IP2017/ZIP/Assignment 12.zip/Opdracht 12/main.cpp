#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <cassert>

using namespace std;

struct Product {
    int price;
    string name;
};

struct Wishlist {
    int budget;
    vector<string> wishes;
};

struct Presents {
    int remainingBudget;
    vector<string> presents;
};

typedef vector<Product> Giftstore;

istream& operator>> (istream& in, Product& product) {
    in >> product.price;
    char c;
    in.get(c);
    getline(in, product.name);
    return in;
}

ostream& operator<< (ostream& out, const Product product) {
    out << product.price << " " << product.name;
    return out;
}

ostream& operator<< (ostream& out, Presents allPresents) {
    out << "Leftover budget: " << allPresents.remainingBudget << endl;
    for (int i = 0; i < allPresents.presents.size(); i++) {
        out << allPresents.presents[i] << endl;
    }
    return out;
}

ostream& operator<< (ostream& out, Wishlist wishlist) {
    out << "Budget: " << wishlist.budget << endl;
    for (int i = 0; i < wishlist.wishes.size(); i++) {
        out << wishlist.wishes[i] << endl;
    }
    return out;
}

ostream& operator<< (ostream& out, Giftstore gStore) {
    for (int i = 0; i < gStore.size(); i++) {
        out << gStore[i] << endl;
    }
    return out;
}



void readStore (Giftstore& gStore) {
    //Preconditie:
    assert(true);
    //Postconditie:
    //Gegevens uit giftstore.txt ingelezen naar gStore
    ifstream file ("giftstore.txt");
    cout << "Reading Giftstore.txt..." << endl;
    Product newProduct;
    while (file && file.is_open()) {
        file >> newProduct;
        gStore.push_back(newProduct);
    }
    gStore.pop_back();
	file.close();
}

void importWishlist(string wishlistName, Wishlist& newWishlist) {
    //Preconditie:
    assert(true);
    //Postconditie:
    //Wishlist geimporteerd naar newWishlist
    ifstream wishlistIn (wishlistName.c_str());
    cout << "Reading " << wishlistName << "..." << endl;
    string str;
    wishlistIn >> newWishlist.budget;
    getline(wishlistIn, str);
    vector<string> wishesDummy;
    while (wishlistIn && wishlistIn.is_open()) {
        getline(wishlistIn, str);
        wishesDummy.push_back(str);
    }
    newWishlist.wishes = wishesDummy;
}

void makeStore(Giftstore& store, Wishlist wishlist, Giftstore gStore) {
    //Preconditie:
    assert(true);
    //Postconditie:
    //Maakt een persoonlijke store van wishlist
    string str;
    for (int i = 0; i < wishlist.wishes.size(); i++) {
        str = wishlist.wishes[i];
        for (int o = 0; o < gStore.size(); o++) {
            cout << gStore[o].name << endl;
            if (str == gStore[o].name) {
                store.push_back(gStore[o]);
            }
        }
    }
}

void copyPresents(Presents from, Presents& to) {
    //Preconditie:
    assert(true);
    //Postconditie:
    //Kopieert alle elementen uit from naar to
    to.remainingBudget = from.remainingBudget;
    for (int i = 0; i < from.presents.size(); i++) {
        to.presents.push_back(from.presents[i]);
    }
}

void clearPresents(Presents& toClear) {
    //Preconditie:
    assert(true);
    //Postconditie:
    //Maakt toClear leeg
    toClear.remainingBudget = 0;
    toClear.presents.clear();
}

int gifts(Giftstore personalStore, int nextGift, Presents& allPresents) {
    //Preconditie:
    assert(nextGift >= 0);
    //Postconditie:
    //Maakt de meest optimale oplossing voor de input
    if (nextGift >= personalStore.size()) {
        return allPresents.remainingBudget;
    }
    else {
        if (personalStore[nextGift].price > allPresents.remainingBudget) {
            return gifts(personalStore, nextGift+1, allPresents);
        }
        else {
            Presents add;
            Presents noAdd;
            copyPresents(allPresents, add);
            copyPresents(allPresents, noAdd);

            add.presents.push_back(personalStore[nextGift].name);
            add.remainingBudget = add.remainingBudget - personalStore[nextGift].price;
            int presentAdded = gifts(personalStore, nextGift+1, add);
            int presentNotAdded = gifts(personalStore, nextGift+1, noAdd);

            if (presentAdded < presentNotAdded) {
                clearPresents(allPresents);
                copyPresents(add, allPresents);
                return allPresents.remainingBudget;
            }
            else {
                clearPresents(allPresents);
                copyPresents(noAdd, allPresents);
                return allPresents.remainingBudget;
            }

        }
    }
}

int main()
{
    Giftstore gStore;
    Wishlist best;
    readStore(gStore);
    cout << gStore << endl;
    cout << "---------------------------" << endl;
    string textFile;
    cout << "Please enter the name of the text file to import from: ";
    cin >> textFile;
    Wishlist currentWishlist;
    importWishlist(textFile, currentWishlist);
    Giftstore wishStore;
    makeStore(wishStore, currentWishlist, gStore);
    Presents allPresents;
    allPresents.remainingBudget = currentWishlist.budget;
    cout << gifts(wishStore, 0, allPresents) << endl;
    cout << "---------------------------" << endl;
    cout << allPresents << endl;
    return 0;
}
