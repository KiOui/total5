#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <cassert>

//Dit bestand is inclusief Bonus opdracht.

using namespace std;

struct Command
{
    string command;
    string parameter;
};

struct Length
{
	int minutes;							// #minutes (0..)
	int seconds;							// #seconds (0..59)
};

struct Track
{
	string artist;                          // name of artist
	string cd;                              // cd title
	int    year;                            // year of appearance (if known)
	int    track;							// track number
	string title;                           // track title
	string tags;                            // tags
	Length time;							// playing time
	string country;                         // main countr(y/ies) of artist
};

struct TrackDisplay
{
	bool showArtist;						// if true, show name of artist if true
	bool showAlbum;							// if true, show cd title
	bool showYear;							// if true, show year of appearance
	bool showTrack;							// if true, show track number
	bool showTitle;							// if true, show track title
	bool showTags;                          // if true, show tags
	bool showLength;						// if true, show playing time
	bool showCountry;                       // if true, show countr(y/ies) of artist
};

typedef vector<Track> MusicDB;              // the music database is stored as a vector of Tracks

bool match (string sub, string source)
{// Precondition:
    assert (true) ;
/*  Postcondition:
    Result is true only if sub is a literal (case sensitive) sub string of source.
*/
    return source.find(sub) != string::npos ;
}

ostream& operator<< (ostream& out, const Length length)
{// Precondition:
    assert (true) ;
/*  Postcondition:
    the value of length is shown via out in the format: minutes, ':', seconds (two digits)
*/
    if (length.seconds < 10) {
        out << length.minutes << ":0" << length.seconds;
    }
    else {
        out << length.minutes << ":" << length.seconds;
    }
    return out;
}

istream& operator>> (istream& in, Length& length)
{// Precondition:
    assert (true) ;
/*  Postcondition:
    the value of length has been read from in: first minutes, then ':', then seconds
*/
    char character;
    in >> length.minutes;
    in.get(character);
    if (!(character == ':')) {
        cout << "Error, time could not be read!" << endl;
    }
    in >> length.seconds;
    return in;
}

Length operator+ (const Length& a, const Length& b)
{// Precondition:
    assert (0 <= a.minutes && 0 <= a.seconds && a.seconds < 60 && 0 <= b.minutes && 0 <= b.seconds && b.seconds < 60) ;
/*  Postcondition:
    Result is the sum of a and b.
*/
    int minutes = 0;
    int seconds = a.seconds + b.seconds;
    Length length;
    if (seconds >= 60) {
        seconds = seconds - 60;
        minutes++;
    }
    minutes = minutes + a.minutes + b.minutes;
    length = {minutes, seconds};
    return length;
}

void show_track (Track track, TrackDisplay lt)
{// Precondition:
    assert (true) ;
/*  Postcondition:
    only the members of track are shown for which the corresponding member in lt is true.
*/
    if (lt.showArtist) {
        cout << track.artist << endl;
    }
    if (lt.showAlbum) {
        cout << track.cd << endl;
    }
    if (lt.showYear) {
        cout << track.year << endl;
    }
    if (lt.showTrack) {
        cout << track.track << endl;
    }
    if (lt.showTitle) {
        cout << track.title << endl;
    }
    if (lt.showTags) {
        cout << track.tags << endl;
    }
    if (lt.showLength) {
        cout << track.time << endl;
    }
    if (lt.showCountry) {
        cout << track.country << endl;
    }
}

istream& operator>> (istream& in, Track& track)
{// Precondition:
    assert (true) ;
/*  Postcondition:
    the content of the first 8 lines from in have been read and are stored in the corresponding members of track.
    The following (empty) line from in has also been read.
*/
    string str;
    string artist;
    getline(in, artist);
    if (artist == "") {
        track.artist = "%%%";
    }
    else {
        track.artist = artist;
        getline(in, track.cd);
        in >> track.year;
        getline(in, str);
        in >> track.track;
        getline(in, str);
        getline(in, track.title);
        getline(in, track.tags);
        in >> track.time;
        getline(in, str);
        getline(in, track.country);
        getline(in, str);
    }
}

int read_file(istream& in, MusicDB& mDB) {
    //Precondition:
    assert(true);
    //Post condition:
    /* Reads the file Nummers.txt and places them in the Track newTrack and then places
    that track in the mDB vector. The result is that the mDB vector contains tracks with all
    entries in the Nummers.txt file.
    */
    bool cont = true;
    Track newTrack;
    TrackDisplay display = {true,true,true,true,true,true,true,true};
    string str;
    //TrackDisplay display = {false,false,false,false,false,false,false,false};

    cout << "Starting file import..." << endl << endl;

    while (cont) {
        in >> newTrack;
        if (newTrack.artist == "%%%") {
            cont = false;
        }
        else {
            mDB.push_back(newTrack);
            show_track(mDB[mDB.size()-1], display);
            cout << "\n" << endl;
        }
    }
    cout << "\n\n-----------------------------------" << endl;
    cout << "File succesfully read!" << endl;
    cout << "Amount of entries read: " << mDB.size() <<  endl;
}

int match_tracks(MusicDB& tracks, string track, bool display) {
    //Precondition
    assert(tracks.size() > 0);
    //Post conditions
    /*This function returns the amount of times the string "track" was found
    in the musicDB "tracks"*/
    TrackDisplay displayTracks = {true,true,true,true,true,true,true,true};
    int counter = 0;
    for (int i = 0;i < tracks.size(); i++) {
        if (match(track, tracks[i].title)) {
            if (display) {
                show_track(tracks[i], displayTracks);
                cout << endl;
            }
            counter++;
        }
    }
    return counter;
}

int match_artists(MusicDB& tracks, string artist, bool display) {
    //Preconditions:
    assert(tracks.size() > 0);
    //Post conditions:
    /* This function returns the amount of times the string "artist" was found
    in the musicDB "tracks", it only counts artists found twice once.*/
    TrackDisplay displayTracks = {true,false,false,false,false,false,false,false};
    vector<string> savedArtists;
    for (int i = 0;i < tracks.size(); i++) {
        if (match(artist, tracks[i].artist)) {
            bool alreadySaved = false;
            for (int o = 0; o < savedArtists.size(); o++) {
                if (tracks[i].artist == savedArtists[o]) {
                    alreadySaved = true;
                }
            }
            if (!alreadySaved) {
                savedArtists.push_back(tracks[i].artist);
                if (display) {
                    show_track(tracks[i], displayTracks);
                    cout << endl;
                }
            }
        }
    }
    return savedArtists.size();
}

int match_cds(MusicDB& tracks, string artist, bool display) {
    //Preconditions:
    assert(tracks.size() > 0);
    //Post conditions:
    /* This function returns the amount of found CD titles given the string artist */
    TrackDisplay displayTracks = {true,true,true,false,false,false,false,false};
    vector<string> savedCDS;
    for (int i = 0;i < tracks.size(); i++) {
        if (match(artist, tracks[i].artist)) {
            bool alreadySaved = false;
            for (int o = 0;o < savedCDS.size(); o++) {
                if (tracks[i].cd == savedCDS[o]) {
                    alreadySaved = true;
                }
            }
            if (!alreadySaved) {
                savedCDS.push_back(tracks[i].cd);
                if (display) {
                    show_track(tracks[i], displayTracks);
                    cout << endl;
                }
            }
        }
    }
    return savedCDS.size();
}

int number_of_cds(MusicDB& tracks) {
    //Preconditions:
    assert(tracks.size() > 0);
    //Post conditions:
    /* Returns the amount of imported Cds in tracks */
    vector<string> savedCDS;
    bool alreadySaved = false;
    for (int i = 0; i < tracks.size(); i++) {
        alreadySaved = false;
        for (int o = 0; o < savedCDS.size(); o++) {
            if (tracks[i].cd == savedCDS[o]) {
                alreadySaved = true;
            }
        }
        if (!alreadySaved) {
            savedCDS.push_back(tracks[i].cd);
        }
    }
    return savedCDS.size();
}

Command basicIO() {
    //Preconditions:
    assert(true);
    //Post conditions:
    /* This function returns the command and parameter(s) the user enters*/
    string command;
    string parameter;
    char character;

    cout << "Execute command: ";
    cin >> command;
    if (command == "#cds" || command == "stop") {
        return {command, ""};
    }
    else {
        cin.get(character);
        getline(cin, parameter);

        cout << "Command: " << command << "." << endl;
        cout << "Parameter: " << parameter << "." << endl;
        return {command, parameter};
    }
}

int main()
{// Precondition:
    assert (true) ;
/*  Postcondition:
    the music database "Nummers.txt" has been read (if present and correctly formatted).
    The user has been able to query the database and has seen the results of these queries.
*/
    ifstream in;
    MusicDB musicDatabase;
    Command nextCommand;
    bool stop = false;
    int returnVariable;

    in.open("Nummers.txt");
    read_file(in, musicDatabase);

    while (!stop) {
        nextCommand = basicIO();
        if (nextCommand.command == "stop") {
            cout << "Terminating..." << endl;
            stop = true;
        }
        else if (nextCommand.command == "track") {
            cout << "Executing track with parameter: " << nextCommand.parameter << endl << endl;
            returnVariable = match_tracks(musicDatabase, nextCommand.parameter, true);
            cout << endl << endl << endl;
            cout << "Number of found tracks: " << returnVariable << endl;
        }
        else if (nextCommand.command == "artist") {
            cout << "Executing artist with parameter: " << nextCommand.parameter << endl << endl;
            returnVariable = match_artists(musicDatabase, nextCommand.parameter, true);
            cout << endl << endl << endl;
            cout << "Number of found artists: " << returnVariable << endl;
        }
        else if (nextCommand.command == "cds") {
            cout << "Executing cds with parameter: " << nextCommand.parameter << endl << endl;
            returnVariable = match_cds(musicDatabase, nextCommand.parameter, true);
            cout << endl << endl << endl;
            cout << "Number of found cds: " << returnVariable << endl;
        }
        else if (nextCommand.command == "#cds") {
            cout << "Executing #cds" << endl << endl;
            returnVariable = number_of_cds(musicDatabase);
            cout << endl << endl << endl;
            cout << "Total number of cds: " << returnVariable << endl;
        }
        else {
            cout << "Error: no such command." << endl;
        }
        cout << "-----------------------------------" << endl << endl << endl;
    }
    in.clear();
    in.close();
	return 0;
}
