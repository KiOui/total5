#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <cassert>


using namespace std;

struct Length
{
	int minutes;							// #minuten  (0..)
	int seconds;							// #seconden (0..59)
};
struct Track
{
	string artist;                          // naam van uitvoerende artiest
	string cd;                              // titel van cd
	int    year;                            // jaar van uitgave
	int    track;							// nummer van track
	string title;                           // titel van track
	string tags;                            // tags van track
	Length time;							// lengte van track
	string country;                         // land van artiest
};

typedef Track El ;
typedef vector<Track> MuziekDB;
MuziekDB liedjes;


//OPERATORS

bool operator< (const Length& a, const Length& b){
    if ((a.minutes * 60 + a.seconds) < (b.minutes * 60 + b.seconds)) {
        return true;
    }
    else {
        return false;
    }
}

bool operator== (const Length& a, const Length& b){
    return (a.minutes == b.minutes && a.seconds == b.seconds);
}

bool operator==(const Track& a, const Track& b)
{
    return (a.artist == b.artist && a.cd == b.cd && a.year == b.year && a.track == b.track);
}

bool operator<(const Track& a, const Track& b) {
    if (a.artist != b.artist){
        return a.artist < b.artist;
    }
    else if (a.cd != b.cd){
        return a.cd < b.cd;
    }
    else if (a.year != b.year){
        return a.year < b.year;
    }
    else if (a.track != b.track){
        return a.track < b.track;
    }
    return false;
}



/*
bool operator==(const Track& a, const Track& b)
{
    return (a.time == b.time && a.artist == b.artist && a.title == b.title && a.cd == b.cd);
}


bool operator<(const Track& a, const Track& b)
{
    if (!(a.time == b.time)) {
        return a.time < b.time;
    }
   if (a.artist != b.artist){
        return a.artist < b.artist;
    }
    else if (a.title != b.title){
        return a.title < b.title;
    }
    else if (a.cd != b.cd){
        return a.cd < b.cd;
    }
    return false;
}
*/


bool operator>(const Track& a, const Track& b)
{
	return b < a ;
}

bool operator<=(const Track& a, const Track& b)
{
	return !(b < a) ;
}

bool operator>=(const Track& a, const Track& b)
{
	return b <= a ;
}

istream& operator>> (istream& in, Length& lengte)
{// Preconditie:
    assert (true) ;
/*  Postconditie:
    de waarde van lengte is ingelezen uit in: eerst minuten, daarna ':', daarna seconden.
*/
    char colon ;
    in >> lengte.minutes >> colon >> lengte.seconds ;
    return in ;
}

ostream& operator<< (ostream& out, const Length lengte)
{
    out << lengte.minutes << ':' ;
    if (lengte.seconds < 10)
        out << '0' ;
    out << lengte.seconds ;
    return out ;
}

istream& operator>> (istream& in, Track& track)
{
    string str;
    string artist;
    getline(in, artist);
    if (artist == "") {
        track.artist = "%%%";
    }
    else {
        track.artist = artist;
        getline(in, track.cd);
        in >> track.year;
        getline(in, str);
        in >> track.track;bool operator==(const Track& a, const Track& b);
        getline(in, str);
        getline(in, track.title);
        getline(in, track.tags);
        in >> track.time;
        getline(in, str);
        getline(in, track.country);
        getline(in, str);
    }
    return in;
}

ostream& operator<< (ostream& out, const Track track)
{
    out << track.artist << " " << track.cd << " [" << track.track << "] (" << track.time << ")" ;
    return out ;
}

//INLEZEN
int lees_liedjes(istream& in, MuziekDB& mDB) {
    //Preconditions:
    assert(true);
    //Postconditions:
    //Reads in all Tracks from in to mDB.
    bool cont = true;
    Track newTrack;
    string str;

    while (cont) {
        in >> newTrack;
        if (newTrack.artist == "%%%") {
            cont = false;
        }
        else {
            mDB.push_back(newTrack);
        }
    }
    cout << "Tracks imported: " << mDB.size() << endl;
    return mDB.size();
}

int lees_bestand (string bestandnaam)
{
    //Preconditions:
    assert(true);
    //Postconditions:
    //Reads in the file bestandnaam to liedjes.
    ifstream nummersDBS (bestandnaam.c_str());
    if (!nummersDBS)
    {
        cout << "Kon '" << bestandnaam << "' niet openen." << endl;
        return -1;
    }
    cout << "Lees '" << bestandnaam << "' in." << endl;
	int aantal = lees_liedjes (nummersDBS, liedjes);
	nummersDBS.close();
	return aantal;
}

void toon_MuziekDB (MuziekDB liedjes, int aantalLiedjes)
{
    //Preconditions:
    int grootte = liedjes.size();
    assert(aantalLiedjes <= grootte);
    //Postconditions:
    //Prints elements below aantalLiedjes from liedjes to the console.
    for (int i = 0 ; i < aantalLiedjes; i++)
        cout << i+1 << ". " << liedjes[i] << endl ;
}

void swap (MuziekDB& mDB, int  i, int  j )
{
//	pre-condition:
	assert ( i >= 0 && j >= 0 ) ;	// ... and i < size of array
						            // ... and j < size of array
// Post-condition: array[i] = old array[j] and array[j] = old array[i]
	const El help = mDB [i];
	mDB [i] = mDB[j] ;
	mDB [j] = help;
}

//------------------------------------------------------------------
//------------------------------------------------------------------
//------------------------------------------------------------------

//Part 1:
void dnf (vector<El>& liedjes, int first, int last, int& red, int& blue) {
    //Preconditions:
    int grootte = liedjes.size();
    assert(first >= 0 && last < grootte);
    //Postconditions:
    //The vector is sorted so that all elements lower than the PIVOT are below the PIVOT and elements higher than the PIVOT are above the PIVOT.
    red = first - 1;
    blue = last + 1;
    int white = last + 1;
    const Track PIVOT = liedjes[first+(last-first)/2];
 //   cout << "Pivot: " << PIVOT << endl;
    while (red < white - 1) {
        const int NEXT = white - 1;
        if (liedjes[NEXT] < PIVOT) {
            red++;
            swap(liedjes, red, NEXT);
        }
        else if (liedjes[NEXT] == PIVOT) {
            white--;
        }
        else {
            white--;
            blue--;
            swap (liedjes, NEXT, blue);
        }
    }
}

//Part 2:
void dnf_adjusted (vector<El>& liedjes, int first, int last, int& red, int& blue) {
    //Preconditions:
    int grootte = liedjes.size();
    assert(first >= 0 && last < grootte);
    //Postconditions:
    //The vector is sorted so that all elements lower than the PIVOT are below the PIVOT and elements higher than the PIVOT are above the PIVOT.
    red = first - 1;
    blue = last + 1;
    int white = first - 1;
    const Track PIVOT = liedjes[first+(last-first)/2];
 //   cout << "Pivot: " << PIVOT << endl;
    while (blue > white + 1) {
        const int NEXT = white + 1;
        if (liedjes[NEXT] < PIVOT) {
            red++;
            white++;
            swap(liedjes, red, NEXT);
        }
        else if (liedjes[NEXT] == PIVOT) {
            white++;
        }
        else {
            blue--;
            swap (liedjes, NEXT, blue);
        }
    }
}

//Part 1&2:
void quicksort(vector<El>& liedjes, int first, int last, bool adjusted) {
    //Preconditions:
    int grootte = liedjes.size();
    assert(first >= 0 && last < grootte);
    //Postconditions:
    //The vector is sorted from element first to element last
    if (!(first >= last)) {
       int red;
       int blue;
       if (adjusted) {
            dnf_adjusted(liedjes, first, last, red, blue);

       }
       else {
            dnf(liedjes, first, last, red, blue);
       }
       quicksort(liedjes, first, red, adjusted);
       quicksort(liedjes, blue, last, adjusted);
    }
}

//Part 3:
/*
int largest(vector<El>& v, int low, int up) {
    //Pre:
    int grootte = v.size();
    assert(low <= up && low >= 0 && up < grootte);
    //Post:
    //Returns position of largest element in vector v.

    if (low >= up) {
        return low;
    }
    else {
        const int POS = largest(v, low+1, up);
        if (v[low] > v[POS]) {
            return low;
        }
        else {
            return POS;
        }
    }
}
*/

int largest(vector<El>& v, int low, int up) {
    //Pre:
    int grootte = v.size();
    assert(low <= up && low >= 0 && up < grootte);
    //Post:
    //Returns position of largest element in vector v.

    int largest = low;
    low++;
    while (low <= up) {
        if (v[largest] < v[low]) {
            largest = low;
        }
        low++;
    }
    return largest;
}
/*
void sort(vector<El>& v, int n) {
    //Pre:
    int grootte = v.size();
    assert(n <= grootte);
    //Post:
    //Sorteert de vector v vanaf element 0 tot element n.

    if (n > 1) {
        const int POS = largest(v, 0, n-1);
        swap(v, POS, n-1);
        sort(v, n-1);
    }
}
*/
void sort(vector<El>& v, int n) {
    //Pre:
    int grootte = v.size();
    assert(n <= grootte);
    //Post:
    //Sorteert de vector v vanaf element 0 tot element n.

    while (n > 1) {
        const int POS = largest(v, 0, n-1);
        swap(v, POS, n-1);
        n--;
    }
}

//------------------------------------------------------------------
//------------------------------------------------------------------
//------------------------------------------------------------------

bool test_sorted(vector<El> liedjes, int first, int last) {
    //Preconditions:
    assert(first < last);
    //Postconditions:
    //Returns true when vector is sorted, returns false otherwise.
    for (int i = first; i < last; i++) {
        if (!(liedjes[i] <= liedjes[i+1])) {
            return false;
        }
    }
    return true;
}

int main()
{
    int mDBSize = lees_bestand("Nummers.txt");
    int lastElement = mDBSize - 1;

    bool adjusted;
    cout << "Would you like to use dnf or dnf_adjusted? (0=dnf, 1=dnf_adjusted)";
    cin >> adjusted;
    if (adjusted) {
        cout << "Using dnf_adjusted..." << endl;
    }
    else {
        cout << "Using dnf..." << endl;
    }
    quicksort(liedjes, 0, lastElement, adjusted);

    //sort(liedjes, mDBSize);
    toon_MuziekDB(liedjes, mDBSize);
    if (test_sorted(liedjes, 0, lastElement)) {
        cout << "Liedjes DB is gesorteerd!" << endl;
    }
    else {
        cout << "Liedjes DB is niet gesorteerd!" << endl;
    }
    return 0;
}
