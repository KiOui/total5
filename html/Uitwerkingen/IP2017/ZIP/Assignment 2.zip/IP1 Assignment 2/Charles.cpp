#include "Robot.h"
/*
	Karel is a framework for manipulating with Karel the robot.
	Karel is a subclass of ROBOT from the library Robot.
	Last Modified:	September 16 2006, by Pieter Koopman, RU Nijmegen
	With some additions: September 12 2007, by Ger Paulussen & Peter Achten
	More additions: August 21 2013, by Peter Achten
*/


// =========================================================================

// make_church creates a Church-like shape of walls
void make_church ()
{
    const int lane   = 2 + rand () % (WereldHoogte / 5) ;
    const int street = 2 + rand () % (WereldBreedte / 5) ;
    const int width  = 3 + rand () % (WereldBreedte / 2) ;
    const int height = 2 + rand () % (WereldHoogte / 3) ;
    place_rectangle (street,lane,width,height) ;
    place_rectangle (street + 2,lane + height, 2 + width / 3, 2 + height / 3) ;
    place_walls (street + 3 + width / 6,lane + height + height / 3 + 3,4,false) ;
    place_walls (street + 2 + width / 6,lane + height + height / 3 + 5,2,true) ;
    create_ball (street, WereldHoogte - 2) ;
}


// here starts the part with code to be completed by the students

// give one or more comment lines about what will happen in this function

void face_north() { //Let charles face north
    while (!north()) {
        turn_left();
    }
}

void straight_path () { //Let charles safely take a step
    while (on_ball() && !in_front_of_wall()) {
        step();
    }
}

void return_to_search () { //Let charles return to the searching point
    if (!on_ball()) {
        turn_right();
        turn_right();
        step();
    }
}

void test_for_ball() { //Tests both options (left and right) for a ball
    turn_left();
    if (!in_front_of_wall()) { //test left
        step();
        if (!on_ball()) { //if no ball on left, test right
            return_to_search();
            if (!in_front_of_wall()) { //test right
                step();
                if (!on_ball()) { //if also no ball on right, get back to starting position and get the ball so that the main function (while loop) stops.
                    turn_right();
                    turn_right();
                    step();
                    face_north();
                    turn_right();
                    get_ball();
                }
            }
            else { //if there is a wall at both ends, execute this
                face_north();
                turn_right();
                get_ball();
            }
        }
    }
    else { //same for this function (all the above)
        turn_left();
        turn_left();
        if (!in_front_of_wall()) {
            step();
            if (!on_ball()) {
                turn_right();
                turn_right();
                step();
                face_north();
                turn_right();
                get_ball();
            }
        }
        else {
            get_ball();
        }
    }
}

void search_next_path() { //get back to stating position and search the ball
    return_to_search();
    test_for_ball();
}

void follow_path ()
{
    while (on_ball()) { //When charles is at the end of the path, he gets the ball so this function stops
        straight_path();
        search_next_path();
    }
    put_ball(); //puts the ball back
}

// give one or more comment lines about what will happen in this function
void hansl_and_gretl ()
{
	make_path_with_balls() ;
	follow_path ();
}

// give one or more comment lines about what will happen in this function
// note that you are allowed to add formal parameters to fill_cave_with_balls if that is necessary for your solution

void walk_to_end() { //for walking back
    while(!in_front_of_wall()) {
        step();
    }
}

void finish_row() { //for making a row with balls
    while (!in_front_of_wall()) {
        put_ball();
        step();
    }
    put_ball();
}

void block() { //for making a block of balls so that charles doesn't have to return to the starting position each time he finishes a row
    turn_right();
    finish_row();
    turn_left();
    if (!in_front_of_wall()) {
        step();
        turn_right();
        if (in_front_of_wall()) {
            turn_left();
            turn_left();
            finish_row();
            turn_right();
            step();
        }
        else {
            turn_right();
            step();
            turn_right();
            walk_to_end();
            turn_right();
            step();
        }
    }
    else {
        turn_left();
        walk_to_end();
        turn_right();
        step();
    }


}

void fill_cave_with_balls ()
{
    step();
    while (!in_front_of_wall()) {
        block();
    }
    turn_right();
    walk_to_end();
    turn_right();
}

// give one or more comment lines about what will happen in this function
void cave ()
{
	// if necessary for your solution, you are allowed to give actual parameters to fill_cave_with_balls
	fill_cave_with_balls () ;
	fill_cave_with_balls () ;
}

// give one or more comment lines about what will happen in this function
void start_cave ()
{
    make_cave () ;
    cave () ;
}

void search_next_wall() { //searches for the next spot for charles tour around the church
    turn_left();
    if (!in_front_of_wall()) {
        step();
        turn_right();
        if (!in_front_of_wall()) {
            step();
            turn_right();
        }
    }
}

void to_church() { //walks charles to the church
    while (!on_ball()) {
        step();
    }
    turn_right();
    while (!in_front_of_wall()) {
        step();
    }
    put_ball();
    while (on_ball()) {
        search_next_wall();
    }
}

void around_church() {//charles puts a ball at the beginning of his tour around the church, when he is back at the ball, he is done.
    while (!on_ball()) {
        search_next_wall();
    }
    face_north();
    get_ball();
    walk_to_end();
    turn_left();
    walk_to_end();
    turn_right();
    turn_right();
}

// give one or more comment lines about what will happen in this function
void rondje_om_de_kerk ()
{
    make_church () ;
    // give your own code completion
    to_church();
    around_church();
}

// For testing purposes, you can define your own function here:
void test ()
{
    // enter your Charles code here
}

// end of part with code to be completed by students
// =========================================================================


void quick  () { rest(    1); };
void normal () { rest(dInit); };
void slow   () { rest(  250); };
void very_slow  () { rest( 1000); };

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
    Menu charles_menu ((char*)"Charles") ;
    charles_menu.add ((char*)"Clean", reset)
                .add ((char*)"Stop",  stop) ;

	Menu a1_menu ((char*)"Assignment 2");
	a1_menu.add ((char*)"Hansl and Gretl", hansl_and_gretl )
		   .add ((char*)"Cave", start_cave )
		   .add ((char*)"Bonus: rondje om de kerk...", rondje_om_de_kerk )
	       .add ((char*)"Test a function",test);

	Menu sn_menu ((char*)"Velocity");
	sn_menu.add ((char*)"Quick", quick)
		   .add ((char*)"Normal",normal)
		   .add ((char*)"Slow",slow)
		   .add ((char*)"Very slow",very_slow);

	try
	{
		karelsWereld().Run (charles_menu,WINARGS(hInstance, hPrevInstance, szCmdLine, iCmdShow));
	}
	catch (IllegaleActie dezeIllegaleActie )
	{
		dezeIllegaleActie.report ();
	}
	catch (...)
	{
		makeAlert ("Something went terribly wrong!");
	}

	return 0;
}
