#include <iostream>
#include <vector>
#include <stdlib.h>
#include <assert.h>

using namespace std;

ostream& operator<< (ostream& out, vector<int> heap) {
    int length = heap.size();
    for (int i = 0; i < length; i++) {
        out << heap[i] << ", ";
    }
    return out;
}

int push_up(vector<int>& heap, int x) {
    assert(heap.size()>0 && x>0);

    int help = heap[x];
    heap[x] = heap[(x-1)/2];
    heap[(x-1)/2] = help;
    x = (x-1)/2;
    return x;
    /* de functie wisselt een child node met zijn parent node
    */
}

void build_heap (vector<int>& heap) {
    assert(heap.size()>0);

    int length = heap.size();
    for (int i = 0; i < length; i++) {
        int index = i;
        while (heap[index] > heap[(index-1)/2] && index != 0) {
            index = push_up(heap, index);
        }
    }
    /*deze functie controleert of de meegegeven vector gesorteerd is, en maakt vervolgens een heap van die vector
    */
}

void randomHeap(vector<int>& heap) {
    assert(heap.size()==0);

    cout << "Vul een seed waarde in voor een random vector: ";
    int randValue;
    cin >> randValue;
    srand(randValue);
    int heapLength = 20;
    for (int i = 0; i < heapLength; i++) {
        heap.push_back(rand()%100);
    }
    /*heap.push_back(5);
    heap.push_back(30);
    heap.push_back(16);
    heap.push_back(-15);
    heap.push_back(8);
    heap.push_back(14);
    heap.push_back(5);*/
    /*deze functie maakt een vector en vult deze met willekeurige integers
    */
}

bool checkHeap(vector<int> heap) {
    assert(heap.size()>0);

    int length = heap.size();
    for (int i = 0; i < length && 2*i + 1 < length; i++) {
        if (heap[i] < heap[2*i + 1]) {
            return false;
        }
    }
    return true;
    /*deze functie returnt true als de input een heap is
    */
}

void swap_heap(vector<int>& heap, int i, int o) {
    assert(i>=0 && o>=0 && i<heap.size() && o<heap.size());

    int help = heap[o];
    heap[o] = heap[i];
    heap [i] = help;
    /*deze functie wisselt elementen i en o van plaats in de heap
    */
}

void push_down(vector<int>& heap, int length) {
    assert(heap.size()>0);

    int i = 0;
    bool cont = true;
    while (cont) {
        if (2*i+1 < length) {
            if (heap[i] < heap[2*i+1] || heap[i] < heap[2*i+2]) {
                if (heap[2*i+1] >= heap[2*i+2]) {
                    swap_heap(heap, i, 2*i+1);
                    i = 2*i+1;
                }
                else {
                    swap_heap(heap, i, 2*i+2);
                    i = 2*i+2;
                }
            }
            else {
                cont = false;
            }
        }
        else if (2*i+1 == length) {
            if (heap[i] < heap[2*i+1]) {
                swap_heap(heap, i, 2*i+1);
                i = 2*i+1;
            }
            else {
                cont = false;
            }
        }
        else {
            cont = false;
        }
        cout << heap << endl;
    }
    /*deze functie zet een parent node op de goede plek onder een child node
    */
}

void pick_heap(vector<int>& heap) {
    assert(heap.size()>0);

    int length = heap.size();
    while (length != 0) {
        swap_heap(heap, 0, length-1);
        cout << heap << endl;
        length--;
        push_down(heap, length-1);
    }
    /*deze functie sorteert een ongesorteerde heap
    */
}

bool checkVector(vector<int> heap) {
    assert(true);

    int length = heap.size();
    for (int i = 0; i < length-1; i++) {
        if (heap[i] > heap[i+1]) {
            return false;
        }
    }
    return true;
    /*deze functie controleert of de meegegeven vector gesorteerd is.
    */
}

int main()
{
    vector<int> Heap;
    randomHeap(Heap);
    cout << Heap << endl;
    build_heap(Heap);
    cout << Heap << endl;
    cout << "------------------------------" << endl;
    if (checkHeap(Heap)) {
        cout << "Heap gemaakt!" << endl;
    }
    else {
        cout << "Heap maken mislukt!" << endl;
        return -1;
    }
    cout << endl;
    pick_heap(Heap);
    cout << "------------------------------" << endl;
    if (checkVector(Heap)) {
        cout << "Vector gesorteerd!" << endl;
    }
    else {
        cout << "Vector sorteren mislukt!" << endl;
        return -1;
    }
    cout << endl;
    return 0;
}

//Part 1
/*

Function a:
Complexity: O(1)
De tijd dat de functie doet over het uitvoeren hangt niet af van de input die gegeven wordt.

Function b:
Complexity: O(sqrt(n))
De tijd dat de functie doet over het uitvoeren van de functie wordt bepaald door x, de functie checkt
alle waarden van divisor tot en met de wortel van input x.
*/

//Part 2
/*
a.
Phase 1:
        5
       /  \
    30      16
   /  \     /  \
-15    8   14   5

        30
       /  \
    5      16
   /  \     /  \
-15    8   14   5

        30
       /  \
    8      16
   /  \     /  \
-15    5   14   5

Phase 2:
Current array: {30, 8, 16, -15, 5, 14, 5}
1. {5, 8, 16, -15, 5, 14, 30}
2. {16, 8, 5, -15, 5, 14, 30}
3. {16, 8, 14, -15, 5, 5, 30}
4. {5, 8, 14, -15, 5, 16, 30}
5. {14, 8, 5, -15, 5, 16, 30}
6. {5, 8, 5, -15, 14, 16, 30}
7. {8, 5, 5, -15, 14, 16, 30}
8. {-15, 5, 5, 8, 14, 16, 30}

b.
push_up: O(2log(n))
Deze functie moet maximaal een element 2log(n) plaatsen omhoog zetten in de heap

build_heap: O(n)
Deze functie controleerd per element of dat element goed staat dus n operaties bij een vector van n elementen.

push_down: O(2log(n))
Deze functie moet maximaal een element 2log(n) plaatsen naar beneden zetten.

pick_heap: O(n)
De functie zet een voor een alle elementen aan het einde van de niet gesorteerde vector
*/
